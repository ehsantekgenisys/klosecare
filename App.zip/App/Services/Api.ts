import axios, { AxiosPromise, AxiosRequestConfig } from 'axios';
import AppConfig from 'Config/AppConfig';
import { isNil } from 'ramda';
import { UserCredentials } from 'react-native-keychain';
import AuthenticationManager from 'Lib/Keychain/AuthenticationManager';

/**
 * Assigns headers (Authorization) to axios config
 *
 * @method assignHeaders
 *
 * @param {AxiosRequestConfig} config
 *
 * @returns {Promise<AxiosRequestConfig>}
 */
export const assignHeaders = (
  config: AxiosRequestConfig,
): Promise<AxiosRequestConfig> => {
  const manager = new AuthenticationManager();

  return manager
    .get()
    .then((credentials: UserCredentials | null) =>
      // If there is no keychain entry for token
      // Then it's safe to assume that we're hitting an unprotected endpoint.
      isNil(credentials)
        ? config
        : Object.assign({}, config, {
            headers: {
              // credentials.password -> token
              Authorization: `token ${credentials.password}`,
            },
          }),
    )
    .catch(() => config);
};

/**
 * Wraps axios (http-client
 *
 * @param {AxiosRequestConfig}
 *
 * @returns {AxiosPromise}
 */
export default (config: AxiosRequestConfig): AxiosPromise => {
  const updatedConfig = Object.assign(
    { 'Content-Type': 'application/json' },
    config,
    {
      url: `${AppConfig.BASE_URL}${config.url}`,
    },
  );

  if (
    updatedConfig.url.includes('api/mobile/v1/user') ||
    updatedConfig.url.includes('api-token-auth')
  ) {
    // TODO (laumair): api module should not know about any urls and this should be handled outside of this module
    return axios(updatedConfig);
  }
  return assignHeaders(updatedConfig).then(
    (configWithHeaders: AxiosRequestConfig) => axios(configWithHeaders),
  );
};
