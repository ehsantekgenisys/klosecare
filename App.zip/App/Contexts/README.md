## App Context

This context acts as a redux store for our `App`. This will contain the global state of our app.

- We define `INITIAL_STATE` for our app.
- We define `ACTIONS` that will be dispatched for the app.
- We have a `REDUCER` that changes our state based on the action dispatched.

## Props defined in Context

- `isConnected` - This will determine if user is connected to the internet or not.
- `appState` - This will determine the state of the app. If the app is `active`, `inactive` and `background`
- `didMountDeps` - This props takes an object whose properties we will want to update.
  `For example:`
  When the user has completed the report upload flow in our app and paid the ammount successfully, when he/she navigates to the `Reports.tsx` component,
  reports list should contain the completed report in the list. But it doesn't because we get the reports using `useApiCallOnDidMount` hook and it gets called only once.
  To control, when we want to refetch the data from `useApiCallOnDidMount` hook, we will add a `reports` property inside `didMountDeps` and update it when the payment is successful like this:
- `dialog` - Dialog contains two props i.e. `show` and `content`. `Show` will determine if the dialog should be shown and `content` will determine the content of the dialog that needs to be shown in the dialog box
- `transparentStatusBar` - Determines if the status bar color should be transparent or not. If it's true then status bar will have `dark-content` and `transparent` background otherwise it will have `light-content` and `blue` background.

  ```javascript
  const appCtx = useContext(AppContext);

  /** Update the reports in didMountDeps */
  appCtx.dispatch({ type: 'UPDATE_DID_MOUNT_DEPS', update: 'reports' });
  ```

  In the initialization of `useApiCallOnDidMount` hook in `Reports.tsx` component we also pass the `deps` that it depends on. In those deps we will pass in the `didMountDeps.reports` from app context so whenever this prop changes, reports will be refetched.
  In this case, `useApiCallOnDidMount` hook is initialized in the following way.

  ```javascript
  const appCtx = useContext(AppContext);
  const [reports, loading] = useApiCallOnDidMount(
    Urls.reports.reports,
    appCtx.didMountDeps.reports,
  );
  ```

### How to use

We use the hook `useReducer` to get `reducer` and `dispatch` from our context.
We wrap root of our app **(App.tsx)** with `AppContext.Provider` and pass in the value i.e. `app state and dispatch`

All components that need to access the context state or want to dispatch some action related to `app` will import this context using `useContext` hook.

```javascript
const appCtx = useContext(AppContext);
```

To dispatch an action, simply access dispatch from `appCtx` and dispatch required action like this.
`appCtx.dispatch({type: 'SOME_ACTION_DEFINED_IN_YOUR_CONTEXT', payload: <any>})`

**App Context is typed using typescript, so whereever you use app context it will give you required intellisense.**
