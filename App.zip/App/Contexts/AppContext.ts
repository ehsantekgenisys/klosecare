import React, { Dispatch } from 'react';
import { AppStateStatus } from 'react-native';

export const RESET_STATE = 'RESET_STATE';
export const CHANGE_CONNECTION = 'CHANGE_CONNECTION';
export const CHANGE_APP_STATE = 'CHANGE_APP_STATE';
export const UPDATE_DID_MOUNT_DEPS = 'UPDATE_DID_MOUNT_DEPS';
export const SET_LAST_LOGGED_EMAIL = 'SET_LAST_LOGGED_EMAIL';
export const SHOW_DIALOG = 'SHOW_DIALOG';
export const SET_STATUS_BAR_TRANSPARENCY = 'SET_STATUS_BAR_TRANSPARENCY';

/** Dialog content type */
type DialogContentType = 'report' | 'medication' | 'exercise' | 'calories';

export type AppActions =
  | { type: 'RESET_STATE' }
  | { type: 'CHANGE_CONNECTION'; connected: boolean }
  | { type: 'CHANGE_APP_STATE'; appState: AppStateStatus }
  | { type: 'UPDATE_DID_MOUNT_DEPS'; update: string }
  | { type: 'SET_LAST_LOGGED_EMAIL'; email: string }
  | { type: 'SHOW_DIALOG'; show: boolean; content: DialogContentType }
  | { type: 'SET_STATUS_BAR_TRANSPARENCY'; transparent: boolean };

/** Generates a unique id every time it's called */
function* generateUniqueId() {
  let uniqueId = 0;
  while (true) {
    yield uniqueId++;
  }
}

const uniqueIdForReportsGenerator = generateUniqueId();

export interface IAppState {
  lastLoggedEmail: string;
  isConnected: boolean;
  appState: AppStateStatus | string;
  /** We will update this prop whenever we want to re-call the useApiCallOnDidMount hook */
  didMountDeps: {
    reports: number | void;
  };
  dialog: {
    show: boolean;
    content: string;
  };
  transparentStatusBar: boolean;
  dispatch?: Dispatch<AppActions>;
}

export const INITIAL_APP_STATE = {
  lastLoggedEmail: '',
  isConnected: true,
  appState: 'active',
  didMountDeps: {
    reports: uniqueIdForReportsGenerator.next().value,
  },
  dialog: {
    show: false,
    content: 'report',
  },
  transparentStatusBar: false,
  dispatch: () => {},
};

export const appReducer = (state: IAppState, action: AppActions): IAppState => {
  switch (action.type) {
    case CHANGE_CONNECTION:
      return { ...state, isConnected: action.connected };
    case CHANGE_APP_STATE:
      return { ...state, appState: action.appState };
    case UPDATE_DID_MOUNT_DEPS:
      /** Updates a new value in didMountDeps - This will cause the useApiCallOnDidMount to be re-called because this is mentioned in it's deps */
      return {
        ...state,
        didMountDeps: {
          ...state.didMountDeps,
          [action.update]: uniqueIdForReportsGenerator.next().value,
        },
      };
    case SET_LAST_LOGGED_EMAIL:
      return {
        ...state,
        lastLoggedEmail: action.email,
      };
    case SHOW_DIALOG:
      return {
        ...state,
        dialog: {
          show: action.show,
          content: action.content,
        },
      };
    case SET_STATUS_BAR_TRANSPARENCY:
      return {
        ...state,
        transparentStatusBar: action.transparent,
      };
    case RESET_STATE:
      return INITIAL_APP_STATE;
    default:
      return INITIAL_APP_STATE;
  }
};

export const AppContext = React.createContext<IAppState>(INITIAL_APP_STATE);
