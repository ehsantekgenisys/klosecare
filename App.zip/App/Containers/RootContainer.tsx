import React, { useEffect, useContext, Fragment } from 'react';
import {
  AppState,
  View,
  StatusBar,
  AppStateStatus,
  SafeAreaView,
} from 'react-native';
import AppNavigator from 'Navigation/AppNavigation';
import NetInfo, { NetInfoState } from '@react-native-community/netinfo';
import Orientation from 'react-native-orientation-locker';
import AppDialog from 'Components/Common/AppDialog';
import { AppContext } from 'Contexts/AppContext';
import { Colors } from 'Themes';
import ErrorBoundary from 'Components/General/ErrorBoundry';

function RootContainer(props: {}) {
  const appCtx = useContext(AppContext);

  useEffect(() => {
    /** Locks app in portrait mode */
    Orientation.lockToPortrait();

    /** Listen to the connection change and update it in App context */
    const unsubscribeNetInfo = NetInfo.addEventListener(
      (state: NetInfoState) => {
        appCtx.dispatch({
          type: 'CHANGE_CONNECTION',
          connected: state.isConnected,
        });
      },
    );

    /**
     * App state change callback - Called when state of the app changes.
     * Dismiss upload report dialog box on app state change
     *
     * @method handleAppStateChange
     *
     * @param {AppStateStatus} state
     *
     * @returns {void}
     */
    function handleAppStateChange(state: AppStateStatus) {
      appCtx.dispatch({ type: 'CHANGE_APP_STATE', appState: state });
      appCtx.dispatch({
        type: 'SHOW_DIALOG',
        show: false,
        content: 'report',
      });
    }

    /** Listen to the state of app i.e. `active`, `inactive`, `background` */
    AppState.addEventListener('change', handleAppStateChange);

    /** Clean up all event listeners */
    return () => {
      unsubscribeNetInfo();
      AppState.removeEventListener('change', handleAppStateChange);
    };
  }, []);

  return (
    <Fragment>
      <SafeAreaView
        style={{
          flex: 0,
          backgroundColor: appCtx.transparentStatusBar
            ? Colors.transparent
            : Colors.statusBarColor,
        }}
      />
      <ErrorBoundary>
        <View style={{ flex: 1 }}>
          <StatusBar
            barStyle={
              appCtx.transparentStatusBar ? 'dark-content' : 'light-content'
            }
          />
          <AppNavigator />
          <AppDialog />
        </View>
      </ErrorBoundary>
    </Fragment>
  );
}

export default RootContainer;
