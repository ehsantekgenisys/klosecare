import 'Config';
import DebugConfig from 'Config/DebugConfig';
import React, { useReducer } from 'react';
import RootContainer from 'Containers/RootContainer';
import {
  ReportContext,
  INITIAL_REPORT_STATE,
  reportReducer,
} from 'Containers/Reports/Context';
import { AppContext, INITIAL_APP_STATE, appReducer } from 'Contexts/AppContext';

function App(props) {
  const [app, appDispatcher] = useReducer(appReducer, INITIAL_APP_STATE);
  const [reports, dispatch] = useReducer(reportReducer, INITIAL_REPORT_STATE);

  return (
    <AppContext.Provider
      value={{
        ...app,
        dispatch: appDispatcher,
      }}
    >
      <ReportContext.Provider
        value={{
          ...reports,
          dispatch,
        }}
      >
        <RootContainer />
      </ReportContext.Provider>
    </AppContext.Provider>
  );
}

// allow reactotron overlay for fast design in dev mode
export default DebugConfig.useReactotron ? console.tron.overlay(App) : App;
