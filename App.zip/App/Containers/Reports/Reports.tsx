import React, { useState, useContext, useEffect } from 'react';
import {
  View,
  TouchableOpacity,
  Image,
  ImageBackground,
  TouchableWithoutFeedback,
  LayoutAnimation,
  RefreshControl,
} from 'react-native';
import {
  NavigationScreenProp,
  NavigationState,
  ScrollView,
} from 'react-navigation';
import Async from 'Components/Common/Async';
import TopSecionIOS from 'Components/Common/TopSectionIOS';
import { reportsStyles } from 'Containers/Reports/Styles';
import { Colors, Images } from 'Themes';
import Icon from 'Themes/Icon';
import { Button } from 'Components/Common/Button';
import { ButtonGroup } from 'react-native-elements';
import { useApiCallOnDidMount } from 'CustomHooks';
import { length, filter, map, isEmpty, sort, descend, prop } from 'ramda';
import { NormalText } from 'Components/Common/NormalText';
import { LargeText } from 'Components/Common/LargeText';
import { IReportResponse } from 'Types';
import { formatDate, showAlert, showNotification } from 'Lib/Utils';
import Urls from 'Constants/Urls';
import Connectivity from 'Components/Common/Connectivity';
import { AppContext } from 'Contexts/AppContext';
import { ReportContext } from 'Containers/Reports/Context';
import DocumentPicker from 'react-native-document-picker';
import Api from 'Services/Api';

interface IReportsProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function Reports(props: IReportsProps) {
  const appCtx = useContext(AppContext);
  const reportCtx = useContext(ReportContext);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [reportResponse, loading, error, success] = useApiCallOnDidMount(
    Urls.reports.reports,
    appCtx.didMountDeps.reports,
  );

  const [reports, setReports] = useState([]);

  /**
   *  Fetching reports on did mount and setting
   *  in state
   */
  useEffect(() => {
    if (success) {
      setReports(reportResponse);
    }
  }, [success]);

  const [selectedButtonIndex, updateSelectedButtonIndex] = useState(0);

  /**
   *  onRefresh will be called when the
   *  user will refresh the report screen
   *  by pulling scroll view downwards
   */
  const onRefresh = React.useCallback(() => {
    setIsRefreshing(true);
    Api({
      method: 'GET',
      url: Urls.reports.reports,
    })
      .then((result) => {
        setReports(result.data);
        setIsRefreshing(false);
      })
      .catch(() => {
        showNotification('Failed to fetch latest reports');
        setIsRefreshing(false);
      });
  }, []);
  /**
   * Picks a document from storage to upload. Gets called if
   * @param uploadReport or
   * @param reuploading
   * changes in the report context
   */
  useEffect(() => {
    if (reportCtx.uploadInfo.uploadReport) {
      DocumentPicker.pick({
        type: [DocumentPicker.types.pdf],
      })
        .then((fileMeta) => {
          reportCtx.dispatch({ type: 'UPLOAD_REPORT', upload: false });
          appCtx.dispatch({
            type: 'SHOW_DIALOG',
            show: false,
            content: 'report',
          });
          /** Showing loader inside the button */
          const fileData = {
            uri: fileMeta.uri,
            type: fileMeta.type,
            name: fileMeta.name,
          };

          /** From data to upload file at the backend */
          const request = new FormData();
          request.append('file', fileData);

          reportCtx.dispatch({
            type: 'SET_REPORT_FORM_DATA',
            data: { request, reportName: fileData.name },
          });

          if (!reportCtx.uploadInfo.reuploading) {
            props.navigation.navigate('UploadedReport');
          } else {
            reportCtx.dispatch({ type: 'SET_REUPLOAD_REPORT' });
          }

          reportCtx.dispatch({ type: 'SET_REUPLOADING', reuploading: false });
        })
        .catch((err) => {
          reportCtx.dispatch({ type: 'UPLOAD_REPORT', upload: false });
          appCtx.dispatch({
            type: 'SHOW_DIALOG',
            show: false,
            content: 'report',
          });
          if (DocumentPicker.isCancel(err)) {
          } else {
            // console.tron.warn(err);
          }
        });
    }
  }, [reportCtx.uploadInfo.uploadReport, reportCtx.uploadInfo.reuploading]);

  /** If reports fetching fails, allow user to refetch them again */
  useEffect(() => {
    if (error) {
      showAlert(
        'Fetching error!',
        'Do you want to fetch reports again?',
        () => {
          appCtx.dispatch({ type: 'UPDATE_DID_MOUNT_DEPS', update: 'reports' });
        },
        () => {},
        'Fetch',
        'Cancel',
      );
    }
  }, [error]);

  /**
   * Updates index of selected button and dismisses the report
   * upload dialog box if visible
   *
   * @method updateButtonIndex
   *
   * @param {number} index
   *
   * @returns {void}
   */
  function updateButtonIndex(index: number) {
    dismissDialog();
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    updateSelectedButtonIndex(index);
  }

  /**
   * Dispatches action to show dialog box for report upload
   *
   * @method uploadReportAlert
   *
   * @returns {void}
   */
  function uploadReportAlert() {
    appCtx.dispatch({
      type: 'SHOW_DIALOG',
      show: true,
      content: 'report',
    });
  }

  /**
   * Navigates to Report Response detail screen and dismisses the report
   * upload dialog box if visible
   *
   * @method onReportSelect
   *
   * @param report
   *
   * @returns {void}
   */
  function onReportSelect(report) {
    dismissDialog();
    props.navigation.navigate('ReportSummary', {
      report,
      transition: 'zoomIn',
    });
  }

  /**
   * Dismisses the dialog box for report upload
   *
   * @method dismissDialog
   *
   * @returns {void}
   */
  function dismissDialog() {
    appCtx.dispatch({
      type: 'SHOW_DIALOG',
      show: false,
      content: 'report',
    });
  }

  /**
   * Renders empty status on screen
   *
   * @method renderEmptyStatus
   *
   * @param {string} message
   * @param {string} buttonText
   *
   * @returns {void}
   */
  function renderEmptyStatus(message: string, buttonText: string) {
    return (
      <View style={{ alignItems: 'center', marginTop: 100 }}>
        <Icon name='doctor' size={100} color={'white'} />
        <NormalText
          text={message}
          lineHeight={25}
          letterSpacing={0.35}
          color={Colors.white}
          marginTop={20}
        />
        <Button
          isLink={true}
          textColor={Colors.white}
          buttonText={buttonText}
          onPress={uploadReportAlert}
          decoration={true}
        />
      </View>
    );
  }

  /**
   * Renders report item in the list
   *
   * @method renderReport
   *
   * @param report
   *
   * @returns {void}
   */
  function renderReport(report: IReportResponse) {
    return (
      <TouchableOpacity
        onPress={() => onReportSelect(report)}
        style={reportsStyles.reportContainer}
      >
        <View style={reportsStyles.reportLeftContainer}>
          <View style={reportsStyles.avatarOutlineContainer}>
            <View style={reportsStyles.avatarContainer}>
              <Image
                style={reportsStyles.imageBg}
                source={{
                  uri: report.doctor
                    ? report.doctor.picture
                    : 'http://budotrader.pl/wp-content/uploads/2018/12/placeholder-image-sq-2.png',
                }}
              />
            </View>
          </View>
          <View>
            <LargeText text={'Pending review'} marginBottom={3} />
            <View style={{ flexDirection: 'row' }}>
              <NormalText
                text={`Submitted: ${formatDate(report.created_at)}`}
                color={Colors.reportText}
              />
            </View>
          </View>
        </View>
        <Icon
          name={'arrow-right'}
          size={15}
          color={Colors.activeBlue}
          style={reportsStyles.iconStyle}
        />
      </TouchableOpacity>
    );
  }

  return (
    <Connectivity>
      <Async displayChildren={loading}>
        <ImageBackground
          source={Images.app_background}
          style={reportsStyles.imageBg}
        >
          <TouchableWithoutFeedback onPress={dismissDialog}>
            <View style={reportsStyles.container}>
              <TopSecionIOS
                headerText={'Reports'}
                isIcon={true}
                onPress={uploadReportAlert}
                iconName={'add'}
                containerStyle={{ marginBottom: 5 }}
              />
              {isEmpty(reports) ? (
                renderEmptyStatus(
                  'No report submitted yet',
                  'Add your first report',
                )
              ) : (
                <React.Fragment>
                  <View style={reportsStyles.buttonGroupWrapper}>
                    <ButtonGroup
                      onPress={updateButtonIndex}
                      selectedIndex={selectedButtonIndex}
                      buttons={['Pending', 'Completed']}
                      containerStyle={reportsStyles.buttonGroupContainer}
                      textStyle={reportsStyles.buttonText}
                      selectedButtonStyle={{
                        backgroundColor: Colors.black,
                        borderWidth: 2,
                        borderRadius: 18,
                      }}
                      buttonStyle={{
                        opacity: 0.61,
                      }}
                      innerBorderStyle={{
                        color: Colors.transparent,
                      }}
                    />
                  </View>

                  <ScrollView
                    style={reportsStyles.reportsWrapper}
                    contentInset={{ bottom: 50 }}
                    refreshControl={
                      <RefreshControl
                        refreshing={isRefreshing}
                        onRefresh={onRefresh}
                        tintColor='#fff'
                      />
                    }
                  >
                    {selectedButtonIndex === 0
                      ? length(
                          filter(
                            (report: IReportResponse) => !report.is_completed,
                            reports,
                          ),
                        ) > 0
                        ? map(
                            (report: IReportResponse) => renderReport(report),
                            filter(
                              (report: IReportResponse) => !report.is_completed,
                              sort(descend(prop('id')), reports),
                            ),
                          )
                        : renderEmptyStatus(
                            'No Pending Reports',
                            'Add New Report',
                          )
                      : length(
                          filter(
                            (report: IReportResponse) => report.is_completed,
                            reports,
                          ),
                        ) > 0
                      ? map(
                          (report: IReportResponse) => renderReport(report),
                          filter(
                            (report: IReportResponse) => report.is_completed,
                            sort(descend(prop('id')), reports),
                          ),
                        )
                      : renderEmptyStatus(
                          'No Completed Reports',
                          'Add New Report',
                        )}
                  </ScrollView>
                </React.Fragment>
              )}
            </View>
          </TouchableWithoutFeedback>
        </ImageBackground>
      </Async>
    </Connectivity>
  );
}

Reports.navigationOptions = ({ navigation }) => ({
  header: null,
});

export default Reports;
