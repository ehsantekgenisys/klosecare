import React, { Dispatch } from 'react';
import { IPurpose } from 'Types';

export const SELECT_DOCTOR = 'SELECT_DOCTOR';
export const SET_PURPOSES = 'SET_PURPOSES';
export const SET_COMMENTS = 'SET_COMMENTS';
export const SET_FILE_META_DATA = 'SET_FILE_META_DATA';
export const SET_EDITING_MODE = 'SET_EDITING_MODE';
export const RESET_STATE = 'RESET_STATE';
export const UPLOAD_REPORT = 'UPLOAD_REPORT';
export const SET_REPORT_FORM_DATA = 'SET_REPORT_FORM_DATA';
export const SET_REUPLOADING = 'SET_REUPLOADING';
export const SET_REUPLOAD_REPORT = 'SET_REUPLOAD_REPORT';
export const SET_CALORIES = 'SET_CALORIES';
export const SET_EXERCISE_HOURS = 'SET_EXERCISE_HOURS';
export const SET_OTHER_MEDICATION = 'SET_OTHER_MEDICATION';
export const SET_INSULIN_MEDICATION = 'SET_INSULIN_MEDICATION';
export const SET_DIET = 'SET_DIET';
export const SET_IS_UPLOADING = 'SET_IS_UPLOADING';

export interface IReportMeta {
  id: number;
  created_at: string;
  file: { url: string; size: number; name: string };
}

export interface IMedicine {
  id: number;
  name: string;
  dose: string;
  frequency: string;
}

export interface IExercise {
  id: number;
  name: string;
  hours: string;
  frequency: string;
}

export interface ICalories {
  id: number;
  name: string;
}

export type ReportActions =
  | { type: 'SET_REUPLOAD_REPORT' }
  | { type: 'SET_OTHER_MEDICATION'; other: IMedicine[] }
  | { type: 'SET_INSULIN_MEDICATION'; insulin: IMedicine[] }
  | { type: 'SET_IS_UPLOADING'; isUploading: boolean }
  | { type: 'SET_REUPLOADING'; reuploading: boolean }
  | {
      type: 'SET_REPORT_FORM_DATA';
      data: { request: FormData; reportName: string };
    }
  | { type: 'UPLOAD_REPORT'; upload: boolean }
  | { type: 'SELECT_DOCTOR'; doctor: { id: number; name: string } | null }
  | { type: 'SET_PURPOSES'; purposes: IPurpose[] }
  | { type: 'SET_COMMENTS'; comments: string | null }
  | { type: 'SET_FILE_META_DATA'; fileMeta: IReportMeta }
  | {
      type: 'SET_EDITING_MODE';
      editMode:
        | { editing: boolean }
        | { isReuploading: boolean }
        | { editing: boolean; isReuploading: boolean };
    }
  | { type: 'RESET_STATE' }
  | {
      type: 'SET_DIET';
      diet: ICalories[];
      estimatedCalories?: number;
    }
  | {
      type: 'SET_EXERCISE_HOURS';
      exercise: IExercise[];
    };

export interface IReportState {
  editMode: {
    editing: boolean;
    isReuploading: boolean;
  };
  /** Null value of doctor means that the user has not selected a specific doctor and has opt-in to choose random doctor */
  doctor: {
    id: number;
    name: string;
  } | null;
  purposes: IPurpose[];
  comments: string | null;
  uploadInfo: {
    fileMeta: IReportMeta;
    showUploadReportDialog: boolean;
    uploadReport: boolean;
    reportFormData: FormData;
    uploadedReportName: string;
    reuploading: boolean;
    reuploadReport: boolean;
    isUploading: boolean;
  };
  reportThumbnail: string;
  medication: {
    medicine: {
      insulin: IMedicine[];
      other: IMedicine[];
    };
    exercise: IExercise[];
    diet: ICalories[];
    estimatedCalories?: number;
  };
  dispatch?: Dispatch<ReportActions>;
}

export const INITIAL_REPORT_STATE = {
  editMode: {
    editing: false,
    isReuploading: false,
  },
  doctor: null,
  purposes: [],
  comments: '',
  uploadInfo: {
    fileMeta: {
      id: 0,
      created_at: '',
      file: {
        url: '',
        size: 0,
        name: '',
      },
    },
    showUploadReportDialog: false,
    uploadReport: false,
    reportFormData: new FormData(),
    uploadedReportName: 'report',
    reuploading: false,
    reuploadReport: false,
    isUploading: false,
  },
  medication: {
    medicine: {
      insulin: [],
      other: [],
    },
    exercise: [],
    diet: [],
    estimatedCalories: 0,
  },
  reportThumbnail:
    'http://budotrader.pl/wp-content/uploads/2018/12/placeholder-image-sq-2.png',
  dispatch: () => {},
  isUploading: false,
};

export const reportReducer = (
  state: IReportState,
  action: ReportActions,
): IReportState => {
  switch (action.type) {
    case SELECT_DOCTOR:
      return { ...state, doctor: action.doctor };
    case SET_PURPOSES:
      return { ...state, purposes: action.purposes };
    case SET_COMMENTS:
      return { ...state, comments: action.comments };
    case SET_FILE_META_DATA:
      return {
        ...state,
        uploadInfo: { ...state.uploadInfo, fileMeta: action.fileMeta },
      };
    case SET_EDITING_MODE:
      return { ...state, editMode: { ...state.editMode, ...action.editMode } };
    case UPLOAD_REPORT:
      return {
        ...state,
        uploadInfo: {
          ...state.uploadInfo,
          showUploadReportDialog: false,
          uploadReport: action.upload,
        },
      };
    case SET_REPORT_FORM_DATA:
      return {
        ...state,
        uploadInfo: {
          ...state.uploadInfo,
          reportFormData: action.data.request,
          uploadedReportName: action.data.reportName,
        },
      };
    case SET_IS_UPLOADING:
      return {
        ...state,
        uploadInfo: {
          ...state.uploadInfo,
          isUploading: action.isUploading,
        },
      };
    case SET_REUPLOADING:
      return {
        ...state,
        uploadInfo: {
          ...state.uploadInfo,
          reuploading: action.reuploading,
        },
      };
    case SET_REUPLOAD_REPORT:
      return {
        ...state,
        uploadInfo: {
          ...state.uploadInfo,
          reuploadReport: !state.uploadInfo.reuploadReport,
        },
      };
    case SET_OTHER_MEDICATION:
      return {
        ...state,
        medication: {
          ...state.medication,
          medicine: {
            ...state.medication.medicine,
            other: action.other,
          },
        },
      };
    case SET_INSULIN_MEDICATION:
      return {
        ...state,
        medication: {
          ...state.medication,
          medicine: {
            ...state.medication.medicine,
            insulin: action.insulin,
          },
        },
      };
    case SET_DIET:
      return {
        ...state,
        medication: {
          ...state.medication,
          diet: action.diet,
          estimatedCalories: action.estimatedCalories,
        },
      };
    case SET_EXERCISE_HOURS:
      return {
        ...state,
        medication: {
          ...state.medication,
          exercise: action.exercise,
        },
      };
    case RESET_STATE:
      return {
        ...INITIAL_REPORT_STATE,
        uploadInfo: {
          ...INITIAL_REPORT_STATE.uploadInfo,
          reuploadReport: state.uploadInfo.reuploadReport,
        },
      };
    default:
      return INITIAL_REPORT_STATE;
  }
};

export const ReportContext = React.createContext<IReportState>(
  INITIAL_REPORT_STATE,
);
