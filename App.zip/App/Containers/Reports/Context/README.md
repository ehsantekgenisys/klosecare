## Report Context

This context acts as a redux store for our `Reports` module.

- We define `INITIAL_STATE` for our reports.
- We define `ACTIONS` that will be dispatched for the reports.
- We have a `REDUCER` that changes our state based on the action dispatched.

## Props defined in Context

- `editMode` - Determines if the user is editing report meta data
- `doctor` - Determines doctor id and doctor name
- `purposes` - Purposes selected for the report
- `comments` - Comments added by user during report upload flow
- `reportThumbnail` - Contains the report thumbnail url
- `fileMeta` - Contains fileMeta i.e. `id`, `created_at`, `url`, `size` and `name`
- `uploadReport` - Determines if the app should access files from phone to upload or not.
- `reportFormData` - Contains the report form data for uploading the report to backend.
- `uploadedReportName` - Contains report name of selected report
- `reuploading` - Determines if the user is reuploading the report
- `reuploadReport` - Determines if api call for upload report should be called again

### How to use

We use the hook `useReducer` to get `reducer` and `dispatch` from our context.
We wrap root of our app **(App.tsx)** with `ReportContext.Provider` and pass in the value i.e. `report state and dispatch`

All components that need to access the context state or want to dispatch some action related to `reports` will import this context using `useContext` hook.

```javascript
const reportCtx = useContext(ReportContext);
```

To dispatch an action, simply access dispatch from `reportCtx` and dispatch required action like this.
`reportCtx.dispatch({type: 'SOME_ACTION_DEFINED_IN_YOUR_CONTEXT', payload: <any>})`

**Report Context is typed using typescript, so whereever you use report context it will give you required intellisense.**
