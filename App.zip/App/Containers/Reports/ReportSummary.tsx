import React, { useEffect, useState, useContext } from 'react';
import { View, Text, ImageBackground } from 'react-native';
import {
  NavigationScreenProp,
  NavigationState,
  ScrollView,
  NavigationActions,
} from 'react-navigation';
import {
  reportSummaryStyles,
  commonReportStyles,
  reviewAndPayStyles,
} from 'Containers/Reports/Styles';
import { Colors, Images, Fonts } from 'Themes';
import { NormalText } from 'Components/Common/NormalText';
import { LargeText } from 'Components/Common/LargeText';
import { IReportResponse, IPurpose } from 'Types';
import { formatDate, showAlert, wrapString } from 'Lib/Utils';
import { useApi } from 'CustomHooks';
import Urls from 'Constants/Urls';
import Async from 'Components/Common/Async';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { AppContext } from 'Contexts/AppContext';
import Api from 'Services/Api';
import Icon from 'Themes/Icon';

interface IReportSummaryProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function ReportSummary(props: IReportSummaryProps) {
  const appCtx = useContext(AppContext);

  /** Getting report details from navigation parameters and setting in @param report using @method setReport */
  const [report, setReport] = useState<IReportResponse>(null);
  const [cancelReport, , cancelReportLoading, , cancellationSuccess] = useApi(
    props.navigation,
    false,
    // 'Reports',
  );

  /** Checks if the report with the id is available in database. If not redirect to reports page */
  useEffect(() => {
    if (appCtx.appState === 'active') {
      const report = props.navigation.getParam('report');
      Api({
        method: 'GET',
        url: Urls.reports.reportMeta(report.id ? report.id : 0),
      })
        .then(() => {})
        .catch(() => {
          props.navigation.reset(
            [NavigationActions.navigate({ routeName: 'Reports' })],
            0,
          );
        });
    }
  }, [appCtx.appState]);

  /** Gets the param of report from nav params and saves the data in state */
  useEffect(() => {
    setReport(props.navigation.getParam('report'));
  }, []);

  /**
   * If cancellation is successful, then refetch the reports as a result of delete
   * by dispatching UPDATE_DID_MOUNT_DEPS for reports
   */
  useEffect(() => {
    if (cancellationSuccess) {
      props.navigation.reset(
        [NavigationActions.navigate({ routeName: 'Reports' })],
        0,
      );
    }
  }, [cancellationSuccess]);

  /**
   * Cancels the report
   *
   * @method onCancelReport
   *
   * @returns {void}
   */
  function confirmCancelReport() {
    cancelReport(
      'DELETE',
      Urls.reports.deleteReport(report.id),
      false,
      true,
      false,
      false,
      'Report cancelled successfully and payment has been reimbursed',
    );
  }

  /**
   * Navigate to health summary screen and sets the readOnly prop true,
   * so the use can't edit any information on health summary screen.
   *
   * @method navigateToReadOnlyHealthSummary
   *
   * @returns {void}
   */
  function navigateToReadOnlyHealthSummary() {
    props.navigation.navigate('HealthSummary', {
      transition: 'zoomIn',
      readOnly: true,
      medication: {
        medicine: {
          insulin: report.medicine.insulin,
          other: report.medicine.other,
        },
        exercise: report.exercise,
        diet: report.diet,
        estimatedCalories: report.estimated_calories,
      },
    });
  }

  function showPdfView() {
    props.navigation.navigate('PdfView', {
      source: { uri: report.file.url, cache: true },
      transition: 'zoomIn',
    });
  }

  if (!report) {
    return (
      <Async displayChildren={cancelReportLoading}>
        <ImageBackground
          source={Images.app_background}
          style={commonReportStyles.bgStyle}
        />
      </Async>
    );
  }

  return (
    <Async displayChildren={cancelReportLoading}>
      <ImageBackground
        source={Images.app_background}
        style={commonReportStyles.bgStyle}
      >
        <ScrollView
          contentInset={{ bottom: 100 }}
          style={reviewAndPayStyles.container}
        >
          {/* Report Status */}
          <View style={reviewAndPayStyles.sectionContainer}>
            <Text style={reviewAndPayStyles.sectionHeading}>Status</Text>
            <View style={reportSummaryStyles.reportStatusContainer}>
              <LargeText text={'Currently: '} />
              <NormalText
                text={report.is_completed ? 'Completed' : 'Pending'}
                fontFamily={Fonts.type.medium}
              />
            </View>
            <View style={reportSummaryStyles.reportStatusContainer}>
              <LargeText text={'Date Submitted: '} />
              <NormalText
                text={formatDate(report.created_at)}
                fontFamily={Fonts.type.medium}
              />
            </View>
            {report.can_cancel ? (
              <View style={reportSummaryStyles.cancelReportView}>
                <TouchableOpacity
                  onPress={() =>
                    showAlert(
                      'Cancel Report ?',
                      'This will delete your report and re-imburse your payment. Are you sure you want to proceed?',
                      confirmCancelReport,
                      () => {},
                      'OK',
                      'Cancel',
                    )
                  }
                >
                  <Text style={reportSummaryStyles.cancelReportText}>
                    Cancel Report
                  </Text>
                </TouchableOpacity>
                <Text style={reportSummaryStyles.cancelTimeText}>
                  With in 1 hour
                </Text>
              </View>
            ) : null}
          </View>

          {/* Report Info */}
          <TouchableOpacity
            onPress={showPdfView}
            style={[
              reviewAndPayStyles.sectionContainer,
              {
                flexDirection: 'row',
                justifyContent: 'space-between',
              },
            ]}
          >
            <View>
              <Text style={reviewAndPayStyles.sectionHeading}>Report</Text>
              <View style={[reviewAndPayStyles.reportViewContainer]}>
                <View>
                  <LargeText text={wrapString(report.file.name, 10)} />
                  <Text style={reviewAndPayStyles.reportDateText}>
                    {formatDate(report.created_at)}
                  </Text>
                </View>
              </View>
            </View>
            <Icon
              style={{ alignSelf: 'center' }}
              name='arrow-right'
              color={Colors.darkSkyBlue}
              size={20}
            />
          </TouchableOpacity>

          {/* Health Summary Info */}
          <TouchableOpacity
            onPress={navigateToReadOnlyHealthSummary}
            style={[
              reviewAndPayStyles.sectionContainer,
              {
                flexDirection: 'row',
                justifyContent: 'space-between',
              },
            ]}
          >
            <View>
              <Text style={reviewAndPayStyles.sectionHeading}>
                Health Summary
              </Text>
              <NormalText
                text={`Check your medication, exercise and calories in detail`}
                color={Colors.reportText}
                marginTop={5}
                marginBottom={5}
              />
            </View>
            <Icon
              style={{ alignSelf: 'center' }}
              name='arrow-right'
              color={Colors.darkSkyBlue}
              size={20}
            />
          </TouchableOpacity>

          {/* Assigned Doctor Info */}
          <View style={reviewAndPayStyles.sectionContainer}>
            <Text style={reviewAndPayStyles.sectionHeading}>Doctor</Text>
            <NormalText
              text={
                Boolean(report.doctor)
                  ? `${report.doctor.user.first_name} ${report.doctor.user.last_name}`
                  : 'All Available Doctors'
              }
              color={Colors.reportText}
              marginTop={5}
              marginBottom={5}
            />
          </View>

          {/* Selected purpose of consultation info */}
          <View style={reviewAndPayStyles.sectionContainer}>
            <Text style={reviewAndPayStyles.sectionHeading}>Purpose</Text>
            {report.purposes.map((purpose: IPurpose) => (
              <NormalText
                key={purpose.id}
                text={purpose.purpose}
                color={Colors.reportText}
                marginTop={5}
                marginBottom={5}
              />
            ))}
          </View>

          {/* Comments added for report */}
          <View style={reviewAndPayStyles.sectionContainer}>
            <Text style={reviewAndPayStyles.sectionHeading}>Comments</Text>
            <NormalText
              text={
                Boolean(report.comments) ? report.comments : 'No comments added'
              }
              color={
                Boolean(report.comments) ? Colors.reportText : Colors.error
              }
              marginTop={5}
              marginBottom={5}
            />
          </View>

          {/* Report Fee */}
          <View style={reviewAndPayStyles.sectionContainer}>
            <Text style={reviewAndPayStyles.sectionHeading}>Fee</Text>
            <NormalText
              text={'$50 for report review'}
              color={Colors.reportText}
              marginTop={5}
              marginBottom={5}
            />
          </View>
        </ScrollView>
      </ImageBackground>
    </Async>
  );
}

ReportSummary.navigationOptions = ({ navigation }) => ({
  title: 'Report Summary',
});

export default ReportSummary;
