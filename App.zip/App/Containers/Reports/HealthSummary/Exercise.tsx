import React, { useState, useContext } from 'react';
import {
  View,
  TouchableOpacity,
  ImageBackground,
  ScrollView,
  TextInput,
  Text,
  KeyboardAvoidingView,
  Keyboard,
} from 'react-native';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { Colors, Images, Fonts } from 'Themes';
import {
  commonReportStyles,
  medicationStyles,
} from 'Containers/Reports/Styles';

import { NormalText } from 'Components/Common/NormalText';
import { ReportContext } from 'Containers/Reports/Context';
import { LargeText } from 'Components/Common/LargeText';
import { useSetNavParamsDidMount } from 'CustomHooks';
import Icon from 'Themes/Icon';
import {
  showNotification,
  allTruthyProps,
  optionalMedicationIsValid,
  optionalMedicationToSave,
} from 'Lib/Utils';
import { last, not } from 'ramda';
/** Generates a unique id every time it's called */
function* generateUniqueId() {
  let uniqueId = 1;
  while (true) {
    yield uniqueId++;
  }
}

const uniqueIdGenerator = generateUniqueId();
interface IExercise {
  navigation: NavigationScreenProp<NavigationState>;
}

function Exercise(props: IExercise) {
  const reportCtx = useContext(ReportContext);

  const [exercise, setExercise] = useState(
    reportCtx.medication.exercise.length
      ? reportCtx.medication.exercise
      : [
          {
            id: uniqueIdGenerator.next().value,
            name: '',
            hours: '',
            frequency: '',
          },
        ],
  );

  useSetNavParamsDidMount({ saveExcericse }, props.navigation, [exercise]);

  /** Checks the validity of medication data and saves it in the report context accordingly */
  function saveExcericse() {
    Keyboard.dismiss();
    const allValidInputsForExercise = optionalMedicationIsValid(exercise, [
      'name',
      'hours',
      'frequency',
    ]);

    if (allValidInputsForExercise) {
      const exerciseToSave = optionalMedicationToSave(exercise);
      reportCtx.dispatch({
        type: 'SET_EXERCISE_HOURS',
        exercise: exerciseToSave,
      });

      if (exerciseToSave.length) {
        showNotification('Exercise saved successfully', 1500);
      }
      props.navigation.goBack();
    } else if (not(allValidInputsForExercise)) {
      showNotification('Please complete exercise information to proceed', 2000);
    }
  }

  /** Updates exercise input values */
  function updateExerciseValues(prop: string, val: string, id: number) {
    setExercise((prevValues) => {
      return prevValues.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            [prop]: val,
          };
        }
        return item;
      });
    });
  }

  /** Removes a new row in exercise section */
  function removeExerciseRow(id: number) {
    setExercise((prevValues) => prevValues.filter((item) => item.id !== id));
  }

  /** Adds a new row in exercise section */
  function addExerciseRow() {
    const latestRow = last(exercise);
    const isValidLatestRow = allTruthyProps(latestRow);

    if (isValidLatestRow) {
      setExercise((prevValues) => [
        ...prevValues,
        {
          id: uniqueIdGenerator.next().value,
          name: '',
          hours: '',
          frequency: '',
        },
      ]);
    } else {
      showNotification('Fill all fields of the previous field first', 1500);
    }
  }

  return (
    <ImageBackground
      source={Images['app_background']}
      style={commonReportStyles.bgStyle}
    >
      <KeyboardAvoidingView
        style={medicationStyles.container}
        behavior={'padding'}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentInset={{ bottom: 100 }}
        >
          <View style={medicationStyles.formTopSection}>
            <Text style={medicationStyles.formTopSectionHeader}>
              {'Workout routine'}
            </Text>
            <TouchableOpacity
              style={medicationStyles.addIconStyles}
              onPress={addExerciseRow}
            >
              <Icon name='add' size={14} color={Colors.darkSkyBlue} />
            </TouchableOpacity>
          </View>

          <View style={medicationStyles.infoSectionContainer}>
            <View style={medicationStyles.sectionHeadersView}>
              <NormalText
                minWidth={105}
                text={'Exercise'}
                color={Colors.white}
              />
              <NormalText
                minWidth={105}
                text={'Days/week'}
                color={Colors.white}
              />
              <NormalText
                minWidth={105}
                text={'Duration'}
                color={Colors.white}
              />
            </View>
            {exercise.map((val, index) => (
              <View key={index} style={medicationStyles.sectionRowView}>
                <TextInput
                  style={medicationStyles.inputStyles}
                  placeholderTextColor={Colors.placeholder}
                  onChangeText={(text) =>
                    updateExerciseValues('name', text, val.id)
                  }
                  maxLength={30}
                  value={val.name}
                  placeholder={'Name'}
                />
                <TextInput
                  style={medicationStyles.inputStyles}
                  placeholderTextColor={Colors.placeholder}
                  onChangeText={(text) =>
                    updateExerciseValues('hours', text, val.id)
                  }
                  maxLength={10}
                  value={val.hours}
                  placeholder={'Daily/weekly'}
                />
                <TextInput
                  style={medicationStyles.inputStyles}
                  placeholderTextColor={Colors.placeholder}
                  onChangeText={(text) =>
                    updateExerciseValues('frequency', text, val.id)
                  }
                  maxLength={10}
                  value={val.frequency}
                  placeholder={'hrs mins etc'}
                />
                {exercise.length > 1 || index > 0 ? (
                  <TouchableOpacity
                    style={medicationStyles.removeRowButton}
                    onPress={() => removeExerciseRow(val.id)}
                    disabled={exercise.length === 1}
                  >
                    <Icon name='remove' size={25} color={Colors.white} />
                  </TouchableOpacity>
                ) : null}
              </View>
            ))}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ImageBackground>
  );
}

Exercise.navigationOptions = ({ navigation }) => ({
  title: 'Exercise',
  headerRight: (
    <TouchableOpacity
      onPress={navigation.getParam('saveExcericse')}
      style={commonReportStyles.headerRightButton}
    >
      {/* If the user is editing info show done  */}
      <LargeText
        text={'Confirm'}
        fontFamily={Fonts.type.regular}
        letterSpacing={0.37}
        color={Colors.white}
      />
    </TouchableOpacity>
  ),
});

export default Exercise;
