import React, { useState, useContext, Fragment, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ImageBackground,
  ScrollView,
  TouchableWithoutFeedback,
  Alert,
} from 'react-native';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { Colors, Images, Fonts } from 'Themes';
import {
  commonReportStyles,
  healthSummaryStyles,
} from 'Containers/Reports/Styles';
import Icon from 'Themes/Icon';
import { ReportContext } from 'Containers/Reports/Context';
import { NormalText } from 'Components/Common/NormalText';
import { LargeText } from 'Components/Common/LargeText';
import { useSetNavParamsDidMount } from 'CustomHooks';
import { not, concat, isEmpty } from 'ramda';

const medicationText = `Please state the medication that you are taking currently (including insulin, its frequency and dosage).`;
const exerciseText = `Add your, daily weekly exercise schedule `;
const dietText = `Add your daily, weekly diet plan based on your calories consumption`;

interface IHealthSummary {
  navigation: NavigationScreenProp<NavigationState>;
}

function HealthSummary(props: IHealthSummary) {
  const reportCtx = useContext(ReportContext);

  const [medicationEmpty, setMedicationEmpty] = useState(false);
  const [dietEmpty, setDietEmpty] = useState(false);
  const [readOnly, setReadOnly] = useState(false);
  const [readOnlyMedication, setReadOnlyMedication] = useState({});

  useSetNavParamsDidMount(
    {
      onNext: navigateToReviewAndPay,
      editing: reportCtx.editMode.editing,
      readOnly,
    },
    props.navigation,
    [
      reportCtx.medication.diet,
      reportCtx.medication.medicine.insulin,
      reportCtx.editMode.editing,
      readOnly,
    ],
  );

  useEffect(() => {
    setReadOnly(Boolean(props.navigation.getParam('readOnly')));
    setReadOnlyMedication(props.navigation.getParam('medication'));
  }, []);

  /** Navigates to Diet screen */
  function navigateTo(screenName: string) {
    setMedicationEmpty(false);
    setDietEmpty(false);
    props.navigation.navigate(screenName, { transition: 'fromBottom' });
  }

  /** Navigates to review and pay if medication and diet are not empty */
  function navigateToReviewAndPay() {
    if (
      not(reportCtx.medication.medicine.insulin.length) ||
      not(reportCtx.medication.diet.length)
    ) {
      Alert.alert('Medication and Diet Info are required');
    }
    if (
      not(reportCtx.medication.medicine.insulin.length) &&
      not(reportCtx.medication.diet.length)
    ) {
      setMedicationEmpty(true);
      setDietEmpty(true);
    } else if (not(reportCtx.medication.medicine.insulin.length)) {
      setMedicationEmpty(true);
    } else if (not(reportCtx.medication.diet.length)) {
      setDietEmpty(true);
    } else {
      props.navigation.navigate('ReviewAndPay');
    }
  }

  /** Resets medication and diet state to false */
  function resetEmptyState() {
    setMedicationEmpty(false);
    setDietEmpty(false);
  }

  /**
   * Renders medication detail pills
   *
   * @method renderMedicationInfo
   *
   * @param {string} name
   * @param {string} units
   * @param {string} freq
   *
   * @returns {JSX.Element}
   */
  function renderMedicationInfo(name: string, units: string, freq: string) {
    return (
      <View key={name} style={healthSummaryStyles.medicineIntakeInfoContainer}>
        <View style={healthSummaryStyles.renderItemView}>
          <Text style={healthSummaryStyles.renderItemText}>{name}</Text>
        </View>
        <View style={healthSummaryStyles.renderItemView}>
          <Text
            style={[
              healthSummaryStyles.renderItemText,
              { color: Colors.medicineDose },
            ]}
          >
            {units}
          </Text>
        </View>
        <View style={healthSummaryStyles.renderItemView}>
          <Text
            style={[
              healthSummaryStyles.renderItemText,
              { color: Colors.medicineFrequency },
            ]}
          >
            {freq}
          </Text>
        </View>
      </View>
    );
  }

  /**
   * Renders diet detail pills
   *
   * @method renderDietInfo
   *
   * @param {id: number, name: string} diet
   *
   * @returns {JSX.Element}
   */
  function renderDietInfo(diet: { id: number; name: string }) {
    return (
      <View
        key={diet.id}
        style={{
          marginBottom: 7,
          width: '100%',
        }}
      >
        <Text
          style={[
            healthSummaryStyles.renderItemText,
            { fontSize: 17, color: Colors.lightGray },
          ]}
        >
          {diet.name}
        </Text>
      </View>
    );
  }

  /**
   * Renders table header with table header values
   *
   * @method renderTableHeader
   *
   * @param {string} h1
   * @param {string} h2
   * @param {string} h3
   *
   * @returns {JSX.Element}
   */
  function renderTableHeader(h1: string, h2: string, h3: string) {
    return (
      <View
        style={[
          healthSummaryStyles.medicineIntakeInfoContainer,
          { marginBottom: 7 },
        ]}
      >
        <Text style={healthSummaryStyles.medicationSectionTableHeaderText}>
          {h1}
        </Text>
        <Text style={healthSummaryStyles.medicationSectionTableHeaderText}>
          {h2}
        </Text>
        <Text style={healthSummaryStyles.medicationSectionTableHeaderText}>
          {h3}
        </Text>
      </View>
    );
  }

  /** Renders medication section of health summary */
  function renderMedicationSection() {
    const medicationAdded =
      reportCtx.medication.medicine.insulin.length ||
      reportCtx.medication.medicine.other.length;
    return (
      <View
        style={[
          healthSummaryStyles.sectionContainer,
          {
            borderColor: medicationEmpty ? Colors.error : Colors.transparent,
          },
        ]}
      >
        <View style={healthSummaryStyles.sectionHeadingContainer}>
          <Text style={healthSummaryStyles.sectionHeading}>
            Medication {readOnly ? '' : '*'}
          </Text>
          {readOnly ? null : medicationAdded ? (
            <TouchableOpacity
              onPress={() => navigateTo('Medication')}
              style={healthSummaryStyles.sectionAddEditContainer}
            >
              <Icon name='edit' size={22} color={Colors.darkSkyBlue} />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={() => navigateTo('Medication')}
              style={healthSummaryStyles.sectionAddEditContainer}
            >
              <View style={healthSummaryStyles.sectionAddButtonBg}>
                <Icon name='add' size={14} color={Colors.darkSkyBlue} />
              </View>
            </TouchableOpacity>
          )}
        </View>
        {readOnly && not(isEmpty(readOnlyMedication)) ? (
          <Fragment>
            {renderTableHeader('Name', 'Dose', 'Frequency')}
            {concat(
              readOnlyMedication.medicine.insulin,
              readOnlyMedication.medicine.other,
            ).map((insulinItem) =>
              renderMedicationInfo(
                insulinItem.name,
                insulinItem.dose,
                insulinItem.frequency,
              ),
            )}
          </Fragment>
        ) : medicationAdded ? (
          <Fragment>
            {renderTableHeader('Name', 'Dose', 'Frequency')}
            {concat(
              reportCtx.medication.medicine.insulin,
              reportCtx.medication.medicine.other,
            ).map((insulinItem) =>
              renderMedicationInfo(
                insulinItem.name,
                insulinItem.dose,
                insulinItem.frequency,
              ),
            )}
          </Fragment>
        ) : (
          <NormalText text={medicationText} lineHeight={21} />
        )}
      </View>
    );
  }

  /** Renders exercise section of health summary */
  function renderExerciseSection() {
    const exerciseAdded = reportCtx.medication.exercise.length;
    if (
      readOnly &&
      not(isEmpty(readOnlyMedication)) &&
      not(readOnlyMedication.exercise.length)
    ) {
      return null;
    }

    return (
      <View style={healthSummaryStyles.sectionContainer}>
        <View style={healthSummaryStyles.sectionHeadingContainer}>
          <Text style={healthSummaryStyles.sectionHeading}>Exercise</Text>
          {readOnly ? null : exerciseAdded ? (
            <TouchableOpacity
              onPress={() => navigateTo('Exercise')}
              style={healthSummaryStyles.sectionAddEditContainer}
            >
              <Icon name='edit' size={22} color={Colors.darkSkyBlue} />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={() => navigateTo('Exercise')}
              style={healthSummaryStyles.sectionAddEditContainer}
            >
              <View style={healthSummaryStyles.sectionAddButtonBg}>
                <Icon name='add' size={14} color={Colors.darkSkyBlue} />
              </View>
            </TouchableOpacity>
          )}
        </View>

        {readOnly && not(isEmpty(readOnlyMedication)) ? (
          <Fragment>
            {renderTableHeader('Type', 'Duration', 'Days per week')}
            {readOnlyMedication.exercise.map((exer) =>
              renderMedicationInfo(
                exer.type,
                exer.duration,
                exer.days_per_week,
              ),
            )}
          </Fragment>
        ) : reportCtx.medication.exercise.length ? (
          <Fragment>
            {renderTableHeader('Type', 'Duration', 'Days per week')}
            {reportCtx.medication.exercise.map((exer) =>
              renderMedicationInfo(exer.name, exer.hours, exer.frequency),
            )}
          </Fragment>
        ) : (
          <NormalText text={exerciseText} lineHeight={21} />
        )}
      </View>
    );
  }

  /** Renders diet section of health summary */
  function renderDietSection() {
    return (
      <View
        style={[
          healthSummaryStyles.sectionContainer,
          {
            borderColor: dietEmpty ? Colors.error : Colors.transparent,
          },
        ]}
      >
        {/* Show edit or add icon based on if user has added any diet or not */}
        <View style={healthSummaryStyles.sectionHeadingContainer}>
          <Text style={healthSummaryStyles.sectionHeading}>
            Diet {readOnly ? '' : '*'}
          </Text>

          {readOnly ? null : reportCtx.medication.diet.length ? (
            <TouchableOpacity
              onPress={() => navigateTo('Diet')}
              style={healthSummaryStyles.sectionAddEditContainer}
            >
              <Icon name='edit' size={22} color={Colors.darkSkyBlue} />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={() => navigateTo('Diet')}
              style={healthSummaryStyles.sectionAddEditContainer}
            >
              <View style={healthSummaryStyles.sectionAddButtonBg}>
                <Icon name='add' size={14} color={Colors.darkSkyBlue} />
              </View>
            </TouchableOpacity>
          )}
        </View>

        {readOnly && not(isEmpty(readOnlyMedication)) ? (
          <Fragment>
            {readOnlyMedication.estimatedCalories ? (
              <View style={healthSummaryStyles.estimatedCaloriesContainer}>
                <LargeText
                  text={`${readOnlyMedication.estimatedCalories}`}
                  color={Colors.black}
                />
                <NormalText text={'calories per day'} marginLeft={5} />
              </View>
            ) : null}
            <View
              style={[
                healthSummaryStyles.medicationDetialContainer,
                { marginBottom: 15 },
              ]}
            >
              {readOnlyMedication.diet.map((diet) => renderDietInfo(diet))}
            </View>
          </Fragment>
        ) : reportCtx.medication.diet.length ? (
          <Fragment>
            {reportCtx.medication.estimatedCalories ? (
              <View style={healthSummaryStyles.estimatedCaloriesContainer}>
                <LargeText
                  text={`${reportCtx.medication.estimatedCalories}`}
                  color={Colors.black}
                />
                <NormalText text={'calories per day'} marginLeft={5} />
              </View>
            ) : null}
            <View
              style={[
                healthSummaryStyles.medicationDetialContainer,
                { marginBottom: 15 },
              ]}
            >
              {reportCtx.medication.diet.map((diet) => renderDietInfo(diet))}
            </View>
          </Fragment>
        ) : (
          <NormalText text={dietText} lineHeight={21} />
        )}
      </View>
    );
  }

  return (
    <ImageBackground
      source={Images['app_background']}
      style={commonReportStyles.bgStyle}
    >
      <ScrollView
        style={healthSummaryStyles.container}
        contentInset={{ bottom: 50 }}
      >
        <TouchableWithoutFeedback onPress={resetEmptyState}>
          <View>
            {renderMedicationSection()}
            {renderDietSection()}
            {renderExerciseSection()}
          </View>
        </TouchableWithoutFeedback>
      </ScrollView>
    </ImageBackground>
  );
}
HealthSummary.navigationOptions = ({ navigation }) => ({
  title: 'Health Summary',
  headerLeft: (
    <TouchableOpacity
      onPress={() =>
        navigation.getParam('readOnly')
          ? navigation.goBack()
          : navigation.navigate('ReportPurpose')
      }
      style={commonReportStyles.backButtonContainer}
    >
      <Icon name='arrow-left' color={Colors.white} size={20} />
      <LargeText
        text={'Back'}
        color={Colors.white}
        fontFamily={Fonts.type.regular}
        marginLeft={6}
      />
    </TouchableOpacity>
  ),
  headerRight: navigation.getParam('readOnly') ? null : (
    <TouchableOpacity
      onPress={navigation.getParam('onNext')}
      style={commonReportStyles.headerRightButton}
    >
      <LargeText
        text={Boolean(navigation.getParam('editing')) ? 'Done' : 'Next'}
        color={Colors.white}
        letterSpacing={0.37}
        fontFamily={Fonts.type.regular}
      />
    </TouchableOpacity>
  ),
});
export default HealthSummary;
