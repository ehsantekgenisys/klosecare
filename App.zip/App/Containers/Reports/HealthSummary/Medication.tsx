import React, { useState, useContext } from 'react';
import {
  View,
  TouchableOpacity,
  ImageBackground,
  ScrollView,
  TextInput,
  Text,
  KeyboardAvoidingView,
  Keyboard,
  Alert,
} from 'react-native';
import { Colors, Images, Fonts } from 'Themes';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import {
  commonReportStyles,
  medicationStyles,
} from 'Containers/Reports/Styles';
import Icon from 'Themes/Icon';
import { ReportContext } from 'Containers/Reports/Context';
import { NormalText } from 'Components/Common/NormalText';
import { LargeText } from 'Components/Common/LargeText';
import { useSetNavParamsDidMount } from 'CustomHooks';
import {
  showNotification,
  allTruthyProps,
  insulinMedicationToSave,
  optionalMedicationToSave,
  optionalMedicationIsValid,
  insulinMedicationIsValid,
} from 'Lib/Utils';
import { last, not } from 'ramda';

/** Generates a unique id every time it's called */
function* generateUniqueId() {
  let uniqueId = 1;
  while (true) {
    yield uniqueId++;
  }
}

const uniqueIdGenerator = generateUniqueId();

interface IMedication {
  navigation: NavigationScreenProp<NavigationState>;
}

function Medication(props: IMedication) {
  const reportCtx = useContext(ReportContext);

  const [otherMedication, setOtherMedication] = useState(
    reportCtx.medication.medicine.other.length
      ? reportCtx.medication.medicine.other
      : [
          {
            id: uniqueIdGenerator.next().value,
            name: '',
            dose: '',
            frequency: '',
          },
        ],
  );

  const [insulinMedication, setInsulinMedication] = useState(
    reportCtx.medication.medicine.insulin.length
      ? reportCtx.medication.medicine.insulin
      : [
          {
            id: uniqueIdGenerator.next().value,
            name: '',
            dose: '',
            frequency: '',
          },
        ],
  );

  useSetNavParamsDidMount({ saveMedication }, props.navigation, [
    otherMedication,
    insulinMedication,
  ]);

  /** Checks the validity of medication data and saves it in the report context accordingly */
  function saveMedication() {
    Keyboard.dismiss();
    const validInsulinData = insulinMedicationIsValid(insulinMedication);
    const validOtherData = optionalMedicationIsValid(otherMedication);

    if (validInsulinData && validOtherData) {
      const insulin = insulinMedicationToSave(insulinMedication);
      const other = optionalMedicationToSave(otherMedication);
      reportCtx.dispatch({
        type: 'SET_INSULIN_MEDICATION',
        insulin,
      });

      reportCtx.dispatch({
        type: 'SET_OTHER_MEDICATION',
        other,
      });
      props.navigation.goBack();
      showNotification('Medication saved successfully', 1500);
    } else if (not(validInsulinData)) {
      Alert.alert('Please complete insulin information to proceed');
    } else if (not(validOtherData)) {
      showNotification(
        'Please complete other medication info to proceed',
        2000,
      );
    }
  }

  /** Updates other input values */
  function updateOtherValues(prop: string, val: string, id: number) {
    setOtherMedication((prevValues) => {
      return prevValues.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            [prop]: val,
          };
        }
        return item;
      });
    });
  }

  /** Updates insulin input values */
  function updateInsulinValues(prop: string, val: string, id: number) {
    setInsulinMedication((prevValues) => {
      return prevValues.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            [prop]: val,
          };
        }
        return item;
      });
    });
  }

  /** Removes a new row in other section */
  function removeOtherRow(id: number) {
    setOtherMedication((prevValues) =>
      prevValues.filter((item) => item.id !== id),
    );
  }

  /** Removes a new row in insulin section */
  function removeInsulinRow(id: number) {
    setInsulinMedication((prevValues) =>
      prevValues.filter((item) => item.id !== id),
    );
  }

  /** Adds a new row in other section */
  function addOtherRow() {
    const latestRow = last(otherMedication);
    const isValidLatestRow = allTruthyProps(latestRow);

    if (isValidLatestRow) {
      setOtherMedication((prevValues) => [
        ...prevValues,
        {
          id: uniqueIdGenerator.next().value,
          name: '',
          dose: '',
          frequency: '',
        },
      ]);
    } else {
      showNotification('Fill all fields of the previous field first', 1500);
    }
  }

  /** Adds a new row in insulin section */
  function addInsulinRow() {
    const latestRow = last(insulinMedication);
    const isValidLatestRow = allTruthyProps(latestRow);

    if (isValidLatestRow) {
      setInsulinMedication((prevValues) => [
        ...prevValues,
        {
          id: uniqueIdGenerator.next().value,
          name: '',
          dose: '',
          frequency: '',
        },
      ]);
    } else {
      showNotification('Fill all fields of the previous field first', 1500);
    }
  }

  return (
    <ImageBackground
      source={Images['app_background']}
      style={commonReportStyles.bgStyle}
    >
      <KeyboardAvoidingView
        style={medicationStyles.container}
        behavior={'padding'}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentInset={{ bottom: 100 }}
        >
          {/* Insulin Section */}
          <View style={medicationStyles.formTopSection}>
            <Text style={medicationStyles.formTopSectionHeader}>
              {'Insulin *'}
            </Text>
            <TouchableOpacity
              style={medicationStyles.addIconStyles}
              onPress={addInsulinRow}
            >
              <Icon name='add' size={14} color={Colors.darkSkyBlue} />
            </TouchableOpacity>
          </View>

          <View style={medicationStyles.infoSectionContainer}>
            <View style={medicationStyles.sectionHeadersView}>
              <NormalText minWidth={105} text={'Type'} color={Colors.white} />
              <NormalText minWidth={105} text={'Dose'} color={Colors.white} />
              <NormalText
                minWidth={105}
                text={'Frequency'}
                color={Colors.white}
              />
            </View>

            {/* Actual Form fields */}
            {insulinMedication.map((val, index) => (
              <View key={index} style={medicationStyles.sectionRowView}>
                <TextInput
                  style={medicationStyles.inputStyles}
                  placeholderTextColor={Colors.placeholder}
                  onChangeText={(text) =>
                    updateInsulinValues('name', text, val.id)
                  }
                  maxLength={20}
                  value={val.name}
                  placeholder={'Name'}
                />
                <TextInput
                  style={medicationStyles.inputStyles}
                  placeholderTextColor={Colors.placeholder}
                  onChangeText={(text) =>
                    updateInsulinValues('dose', text, val.id)
                  }
                  maxLength={10}
                  value={val.dose}
                  placeholder={'Units'}
                />
                <TextInput
                  style={medicationStyles.inputStyles}
                  placeholderTextColor={Colors.placeholder}
                  onChangeText={(text) =>
                    updateInsulinValues('frequency', text, val.id)
                  }
                  maxLength={10}
                  value={val.frequency}
                  placeholder={'daily, weekly'}
                />
                {insulinMedication.length > 1 || index > 0 ? (
                  <TouchableOpacity
                    style={medicationStyles.removeRowButton}
                    onPress={() => removeInsulinRow(val.id)}
                  >
                    <Icon name='remove' size={25} color={Colors.white} />
                  </TouchableOpacity>
                ) : null}
              </View>
            ))}
          </View>

          {/* Other Medication Section */}
          <View style={medicationStyles.formTopSection}>
            <Text style={medicationStyles.formTopSectionHeader}>
              {'Other Medicine'}
            </Text>
            <TouchableOpacity
              style={medicationStyles.addIconStyles}
              onPress={addOtherRow}
            >
              <Icon name='add' size={14} color={Colors.darkSkyBlue} />
            </TouchableOpacity>
          </View>

          <View style={medicationStyles.infoSectionContainer}>
            <View style={medicationStyles.sectionHeadersView}>
              <NormalText
                minWidth={105}
                text={'Medicine'}
                color={Colors.white}
              />
              <NormalText minWidth={105} text={'Dose'} color={Colors.white} />
              <NormalText
                minWidth={105}
                text={'Frequency'}
                color={Colors.white}
              />
            </View>

            {/* Actual Form fields */}
            {otherMedication.map((val, index) => (
              <View key={index} style={medicationStyles.sectionRowView}>
                <TextInput
                  style={medicationStyles.inputStyles}
                  placeholderTextColor={Colors.placeholder}
                  onChangeText={(text) =>
                    updateOtherValues('name', text, val.id)
                  }
                  maxLength={20}
                  value={val.name}
                  placeholder={'Name'}
                />
                <TextInput
                  style={medicationStyles.inputStyles}
                  placeholderTextColor={Colors.placeholder}
                  onChangeText={(text) =>
                    updateOtherValues('dose', text, val.id)
                  }
                  maxLength={10}
                  value={val.dose}
                  placeholder={'mg/ml'}
                />
                <TextInput
                  style={medicationStyles.inputStyles}
                  placeholderTextColor={Colors.placeholder}
                  onChangeText={(text) =>
                    updateOtherValues('frequency', text, val.id)
                  }
                  maxLength={10}
                  value={val.frequency}
                  placeholder={'daily, weekly'}
                />
                {otherMedication.length > 1 || index > 0 ? (
                  <TouchableOpacity
                    style={medicationStyles.removeRowButton}
                    onPress={() => removeOtherRow(val.id)}
                  >
                    <Icon name='remove' size={25} color={Colors.white} />
                  </TouchableOpacity>
                ) : null}
              </View>
            ))}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ImageBackground>
  );
}

Medication.navigationOptions = ({ navigation }) => ({
  title: 'Medication',
  headerRight: (
    <TouchableOpacity
      onPress={navigation.getParam('saveMedication')}
      style={{ marginRight: 10 }}
    >
      {/* If the user is editing info show done  */}
      <LargeText
        text={'Confirm'}
        fontFamily={Fonts.type.regular}
        letterSpacing={0.37}
        color={Colors.white}
      />
    </TouchableOpacity>
  ),
});

export default Medication;
