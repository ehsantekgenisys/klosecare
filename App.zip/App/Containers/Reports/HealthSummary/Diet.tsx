import React, { useState, useContext } from 'react';
import {
  View,
  ImageBackground,
  ScrollView,
  Text,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  Keyboard,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { Colors, Images, Fonts } from 'Themes';
import { commonReportStyles, dietStyles } from 'Containers/Reports/Styles';
import { LargeText } from 'Components/Common/LargeText';
import { useSetNavParamsDidMount, useApiCallOnDidMount } from 'CustomHooks';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { ReportContext } from 'Containers/Reports/Context';
import { showNotification } from 'Lib/Utils';
import Urls from 'Constants/Urls';
import Async from 'Components/Common/Async';
import Connectivity from 'Components/Common/Connectivity';

interface IDiet {
  navigation: NavigationScreenProp<NavigationState>;
}

export default function Diet(props: IDiet) {
  const reportCtx = useContext(ReportContext);

  const [calories, setCalories] = useState(
    reportCtx.medication.estimatedCalories,
  );
  const [diet, selectDiet] = useState(reportCtx.medication.diet);

  useSetNavParamsDidMount({ onSubmit: submitDiet }, props.navigation, [
    calories,
    diet,
  ]);

  const [dietList, loading] = useApiCallOnDidMount(Urls.reports.dietList);

  /**
   * Submits the diet (saves in report context) and takes user back to health screen
   *
   * @method submitDiet
   *
   * @returns {void}
   */
  function submitDiet() {
    Keyboard.dismiss();
    if (Boolean(diet.length)) {
      reportCtx.dispatch({
        type: 'SET_DIET',
        diet,
        estimatedCalories: calories,
      });
      props.navigation.goBack();
      showNotification('Diet saved successfully', 1500);
    } else {
      showNotification(
        'Please enter your dietary information to proceed',
        2000,
      );
    }
  }

  /** Updates calories in state */
  function updateCalories(cal: string) {
    setCalories(Number(cal));
  }

  /** Add diet to list if not in the list otherwise remove it */
  function onSelectDiet(cal: { id: number; name: string }) {
    const alreadySelected = diet.filter((item) => item.id === cal.id);
    if (alreadySelected.length) {
      selectDiet((previousDiet) =>
        previousDiet.filter((diet) => diet.id !== cal.id),
      );
    } else {
      selectDiet((previousDiet) => [...previousDiet, cal]);
    }
  }

  return (
    <Connectivity>
      <Async displayChildren={loading}>
        <ImageBackground
          source={Images['app_background']}
          style={commonReportStyles.bgStyle}
        >
          <KeyboardAvoidingView behavior={'padding'} style={{ flex: 1 }}>
            <ScrollView
              style={dietStyles.scrollContainer}
              contentInset={{ bottom: 100 }}
            >
              <Text style={dietStyles.dietHeading}>Diet</Text>
              {dietList.map((cal) => (
                <TouchableOpacity
                  style={dietStyles.listContainer}
                  onPress={() => onSelectDiet(cal)}
                  key={cal.id}
                >
                  <LargeText text={cal.name} color={Colors.white} />
                  <Icon
                    color={
                      diet.filter((item) => item.id === cal.id).length
                        ? Colors.white
                        : Colors.disabledDietRadio
                    }
                    name='radio-button-checked'
                    size={30}
                  />
                </TouchableOpacity>
              ))}
              <View style={dietStyles.caloriesContainer}>
                <View style={dietStyles.caloriesLeftContainer}>
                  <Text style={dietStyles.caloriesText}>
                    Estimated Calories Per Day{' '}
                  </Text>
                  <Text style={dietStyles.caloriesSubText}>(optional)</Text>
                </View>
                <TextInput
                  style={dietStyles.caloriesInput}
                  placeholder={'0'}
                  value={String(calories)}
                  keyboardType={'numeric'}
                  maxLength={4}
                  onChangeText={updateCalories}
                />
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        </ImageBackground>
      </Async>
    </Connectivity>
  );
}

Diet.navigationOptions = ({ navigation }) => ({
  title: 'Diet',
  headerRight: (
    <TouchableOpacity
      onPress={navigation.getParam('onSubmit')}
      style={commonReportStyles.headerRightButton}
    >
      <LargeText
        text={'Confirm'}
        color={Colors.white}
        letterSpacing={0.37}
        fontFamily={Fonts.type.regular}
      />
    </TouchableOpacity>
  ),
});
