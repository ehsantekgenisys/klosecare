import React, { useContext, useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  ImageBackground,
  Alert,
} from 'react-native';
import {
  NavigationScreenProp,
  NavigationState,
  ScrollView,
} from 'react-navigation';
import Async from 'Components/Common/Async';
import { Colors, Fonts, Images } from 'Themes';
import { ReportContext } from 'Containers/Reports/Context';
import Icon from 'Themes/Icon';
import { useApiCallOnDidMount, useSetNavParamsDidMount } from 'CustomHooks';
import {
  reportDetailsStyles,
  commonReportStyles,
} from 'Containers/Reports/Styles';
import { NormalText } from 'Components/Common/NormalText';
import { LargeText } from 'Components/Common/LargeText';
import { wrapString } from 'Lib/Utils';
import { isNil } from 'ramda';
import { IPurpose } from 'Types';
import Urls from 'Constants/Urls';
import Connectivity from 'Components/Common/Connectivity';
import { SmallText } from 'Components/Common/SmallText';

interface IReportPurposeProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function ReportPurpose(props: IReportPurposeProps) {
  /** State value of the reports context */
  const reportCtx = useContext(ReportContext);
  const [purposes, loading] = useApiCallOnDidMount(Urls.reports.purposes);
  const [commentLength, setCommentLength] = useState(0);

  /** Purposes selected by user - Initialize the value with the value present in report context */
  const [selectedPurposesIds, updateSelectedPurposesIds] = useState(
    reportCtx.purposes.map((item: IPurpose) => item.id),
  );

  const scrollViewRef = useRef(ScrollView);

  /** Sets comments character length on did mount */
  useEffect(() => {
    setCommentLength(reportCtx.comments.length);
  }, []);

  /**
   * Attaches event handler for review and pay in header
   * Updates event handler whenever @param selectedPurposesIds changes
   */
  useSetNavParamsDidMount(
    {
      onPressRightHeader: navigateTo,
      editing: reportCtx.editMode.editing,
    },
    props.navigation,
    [selectedPurposesIds, reportCtx.editMode.editing],
  );

  /**
   * Navigates to the Review and Pay screen
   *
   * @method reviewAndPay
   *
   * @returns {void}
   */
  function navigateTo() {
    if (Boolean(selectedPurposesIds.length)) {
      props.navigation.navigate(
        reportCtx.editMode.editing ? 'ReviewAndPay' : 'HealthSummary',
      );
    } else {
      Alert.alert('Please select a purpose for the report to proceed');
    }
  }

  /**
   * Updates the selectedPurposesIds in the state.
   * Also dispatches the action to update purposes in the report context
   *
   * @method handleSelectPurpose
   *
   * @param {number} purposeId
   *
   * @returns {void}
   */
  function handleSelectPurpose(purpose: IPurpose) {
    if (selectedPurposesIds.includes(purpose.id)) {
      const updatedPurposesIds = selectedPurposesIds.filter(
        (id) => id !== purpose.id,
      );
      const updatedPurposes = reportCtx.purposes.filter(
        (item: IPurpose) => item.id !== purpose.id,
      );
      // const
      updateSelectedPurposesIds(updatedPurposesIds);
      reportCtx.dispatch({ type: 'SET_PURPOSES', purposes: updatedPurposes });
    } else {
      updateSelectedPurposesIds([...selectedPurposesIds, purpose.id]);

      const newPurpose = purposes.filter(
        (item: IPurpose) => item.id === purpose.id,
      );

      reportCtx.dispatch({
        type: 'SET_PURPOSES',
        purposes: [...reportCtx.purposes, ...newPurpose],
      });
    }
  }

  /**
   * Sets the comment text in the report context state
   * Sets the comments character length in state
   *
   * @method handleCommentsTextChange
   *
   * @param {string} comment
   *
   * @returns {void}
   */
  function handleCommentsTextChange(comment: string) {
    setCommentLength(comment.length);
    reportCtx.dispatch({
      type: 'SET_COMMENTS',
      comments: comment ? comment : null,
    });
  }

  return (
    <Connectivity>
      <Async displayChildren={loading}>
        <ImageBackground
          style={commonReportStyles.bgStyle}
          source={Images['app_background']}
        >
          <KeyboardAvoidingView behavior={'padding'} style={{ flex: 1 }}>
            <ScrollView
              ref={scrollViewRef}
              style={reportDetailsStyles.container}
              contentInset={{ bottom: 100 }}
            >
              <View style={reportDetailsStyles.reportPreviewContainer}>
                <View>
                  <View style={reportDetailsStyles.pdfViewContainer}>
                    <Text style={reportDetailsStyles.pdfText}>PDF</Text>
                  </View>
                  <View style={{ alignSelf: 'center' }}>
                    <SmallText
                      fontSize={10}
                      text={wrapString(reportCtx.uploadInfo.fileMeta.file.name)}
                    />
                  </View>
                </View>

                <View style={{ marginLeft: 44 }}>
                  <LargeText
                    text={'Send to'}
                    marginBottom={3}
                    color={Colors.text}
                  />
                  <NormalText
                    text={
                      isNil(reportCtx.doctor)
                        ? 'All Available Doctors'
                        : reportCtx.doctor.name
                    }
                    color={Colors.text}
                  />
                </View>
              </View>

              <Text style={reportDetailsStyles.headingText}>
                Purpose of the consultation
              </Text>

              {/* Purpose Selection Container */}
              <View style={reportDetailsStyles.purposeSelectionContainer}>
                {purposes.map((purpose: IPurpose) => (
                  <TouchableOpacity
                    onPress={() => handleSelectPurpose(purpose)}
                    key={purpose.id}
                    style={reportDetailsStyles.purposeItem}
                  >
                    <View style={reportDetailsStyles.purposeRadio}>
                      {selectedPurposesIds.includes(purpose.id) ? (
                        <Icon
                          name={'circle'}
                          color={Colors.activeBlue}
                          size={16}
                        />
                      ) : null}
                    </View>
                    <NormalText
                      text={purpose.purpose}
                      color={Colors.reportText}
                    />
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={reportDetailsStyles.headingText}>Your Comments</Text>

              {/* Comments Area Container */}
              <View style={[reportDetailsStyles.textArea, { padding: 0 }]}>
                <Text
                  style={[
                    reportDetailsStyles.characterLimitText,
                    {
                      color:
                        commentLength < 280 ? Colors.placeholder : Colors.error,
                    },
                  ]}
                >
                  {commentLength}/280
                </Text>
                <TextInput
                  style={[
                    reportDetailsStyles.textArea,
                    { marginVertical: 0, borderWidth: 0, paddingBottom: 20 },
                  ]}
                  maxLength={280}
                  underlineColorAndroid='transparent'
                  placeholder='Type your comment'
                  placeholderTextColor='grey'
                  numberOfLines={10}
                  multiline={true}
                  onChangeText={handleCommentsTextChange}
                  value={reportCtx.comments}
                  onFocus={() =>
                    scrollViewRef.current.scrollTo({
                      x: 0,
                      y: 750,
                      animated: true,
                    })
                  }
                />
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        </ImageBackground>
      </Async>
    </Connectivity>
  );
}

ReportPurpose.navigationOptions = ({ navigation }) => {
  return {
    title: 'Purpose',
    headerLeft: (
      <TouchableOpacity
        onPress={() => navigation.navigate('UploadedReport')}
        style={commonReportStyles.backButtonContainer}
      >
        <Icon name='arrow-left' color={Colors.white} size={20} />
        <LargeText
          text={'Back'}
          color={Colors.white}
          fontFamily={Fonts.type.regular}
          marginLeft={6}
        />
      </TouchableOpacity>
    ),
    headerRight: (
      <TouchableOpacity
        onPress={navigation.getParam('onPressRightHeader')}
        style={commonReportStyles.headerRightButton}
      >
        {/* If the user is editing info show done  */}
        <LargeText
          text={Boolean(navigation.getParam('editing')) ? 'Done' : 'Next'}
          fontFamily={Fonts.type.regular}
          letterSpacing={0.37}
          color={Colors.white}
        />
      </TouchableOpacity>
    ),
  };
};

export default ReportPurpose;
