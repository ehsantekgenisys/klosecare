import React, { useState, useContext, useEffect } from 'react';
import {
  View,
  FlatList,
  Text,
  Image,
  TouchableOpacity,
  ImageBackground,
} from 'react-native';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { SearchBar } from 'react-native-elements';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Async from 'Components/Common/Async';
import { Colors, Images, Fonts } from 'Themes';
import { ReportContext } from 'Containers/Reports/Context';
import { useApiCallOnDidMount, useSetNavParamsDidMount } from 'CustomHooks';
import {
  doctorListStyles,
  commonReportStyles,
} from 'Containers/Reports/Styles';
import { LargeText } from 'Components/Common/LargeText';
import Urls from 'Constants/Urls';
import Connectivity from 'Components/Common/Connectivity';

interface IDoctorsList {
  navigation: NavigationScreenProp<NavigationState>;
}

function DoctorsList(props: IDoctorsList) {
  const [searchItem, updateSearchItem] = useState('');
  /** Original doctor list from the backend - Will only initialize on mount then stays same */
  const [doctorList, loading, , success] = useApiCallOnDidMount(
    Urls.reports.doctors,
  );

  /** Filtered list of doctors - Keeps changing based on the searched term */
  const [filteredDoctorList, updateFilteredDoctorList] = useState([]);

  /** Adding doctor List in state to filter out on search */
  useEffect(() => {
    if (success) {
      updateFilteredDoctorList(doctorList);
    }
  }, [success]);

  const reportCtx = useContext(ReportContext);

  useSetNavParamsDidMount(
    {
      editing: reportCtx.editMode.editing,
      onPressRightHeader: navigateToReviewAndPay,
    },
    props.navigation,
    [reportCtx.editMode.editing],
  );

  function navigateToReviewAndPay() {
    props.navigation.navigate('ReviewAndPay');
  }

  /**
   *
   *  Updates the searchItem text field and
   *  renders filtered results in FlastList component
   *
   *  @method updateSearchList
   *
   *  @param {string} value
   *
   *  @returns {void}
   */
  function updateSearchList(searchItem) {
    updateSearchItem(searchItem);
    const filteredList = doctorList.filter((item) => {
      return `${item.user.first_name} ${item.user.last_name}`
        .trim()
        .toLowerCase()
        .includes(searchItem.trim().toLowerCase());
    });
    updateFilteredDoctorList(filteredList);
  }
  /**
   *  Selects a doctor and navigates to Detail Screen
   *
   *  @method navigateToDetails
   *
   *  @returns {void}
   */
  function navigateToDetails(doctorId: number, doctorName: string) {
    reportCtx.dispatch({
      type: 'SELECT_DOCTOR',
      doctor: { id: doctorId, name: doctorName },
    });
    /** If user is in editMode, navigate straight to Review and Pay screen */
    if (reportCtx.editMode.editing) {
      props.navigation.navigate('ReviewAndPay');
    } else {
      props.navigation.navigate('ReportPurpose');
    }
  }

  /**
   * Renders single item in a flast list
   *
   * @method renderListItem
   *
   * @param {Object} item
   *
   * @return {JSX}
   */
  function renderListItem({ item }) {
    return (
      <TouchableOpacity
        style={doctorListStyles.itemContainer}
        /** TODO: replace this with item.name once name is avialable in the response */
        onPress={() =>
          navigateToDetails(
            item.id,
            `${item.user.first_name} ${item.user.last_name}`,
          )
        }
      >
        {/* Avatar of the user */}
        <View style={doctorListStyles.avatarContainer}>
          <Image
            style={doctorListStyles.imageBg}
            source={{
              uri: item.picture,
            }}
          />
        </View>
        {/* Middle view between Avatar and Radio Button */}
        <View style={doctorListStyles.itemCenterContainer}>
          <View style={doctorListStyles.titleRatingContainer}>
            {/* TODO: replace this with item.name once name is avialable in the response  */}
            <LargeText
              text={`${item.user.first_name} ${item.user.last_name}`}
            />
            <View style={doctorListStyles.ratingContainer}>
              <Icon color={Colors.activeBlue} name='star' size={15} />
              <Text style={doctorListStyles.rating}>{item.rating}</Text>
            </View>
          </View>

          <Text style={doctorListStyles.subtitle}>{item.bio}</Text>
        </View>
        {/* Radio button */}
        <Icon
          style={doctorListStyles.radioButton}
          color={
            reportCtx.doctor
              ? reportCtx.doctor.id === item.id
                ? Colors.activeBlue
                : Colors.disableRadio
              : Colors.disableRadio
          }
          name='radio-button-checked'
          size={26}
        />
      </TouchableOpacity>
    );
  }

  return (
    <Connectivity>
      <Async displayChildren={loading}>
        <ImageBackground
          source={Images['app_background']}
          style={commonReportStyles.bgStyle}
        >
          <View style={doctorListStyles.container}>
            <SearchBar
              platform={'ios'}
              placeholder='Search'
              onChangeText={updateSearchList}
              value={searchItem}
              cancelButtonProps={{ color: Colors.white }}
              containerStyle={doctorListStyles.searchBarContainer}
              inputContainerStyle={doctorListStyles.searchBar}
            />

            <FlatList
              data={filteredDoctorList}
              renderItem={renderListItem}
              keyExtractor={(item) => item.id}
              contentContainerStyle={doctorListStyles.flatListContainer}
            />
          </View>
        </ImageBackground>
      </Async>
    </Connectivity>
  );
}

DoctorsList.navigationOptions = ({ navigation }) => ({
  title: 'Select a Doctor',
  headerRight: Boolean(navigation.getParam('editing')) ? (
    <TouchableOpacity
      onPress={navigation.getParam('onPressRightHeader')}
      style={commonReportStyles.headerRightButton}
    >
      {/* If the user is editing info show done  */}
      <LargeText
        text={'Next'}
        fontFamily={Fonts.type.regular}
        letterSpacing={0.37}
        color={Colors.white}
      />
    </TouchableOpacity>
  ) : null,
});

export default DoctorsList;
