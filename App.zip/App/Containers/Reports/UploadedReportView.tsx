import React, { useContext, useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, ImageBackground } from 'react-native';
import {
  NavigationScreenProp,
  NavigationState,
  NavigationActions,
} from 'react-navigation';
import { Colors, Fonts, Images } from 'Themes';
import Icon from 'Themes/Icon';
import { AppContext } from 'Contexts/AppContext';
import { ReportContext } from 'Containers/Reports/Context';
import { useSetNavParamsDidMount, useApi } from 'CustomHooks';
import {
  uploadedReportViewStyles,
  commonReportStyles,
} from 'Containers/Reports/Styles';
import { NormalText } from 'Components/Common/NormalText';
import { LargeText } from 'Components/Common/LargeText';
import Connectivity from 'Components/Common/Connectivity';
import { showAlert, formatDate, getCancelToken, wrapString } from 'Lib/Utils';
import Urls from 'Constants/Urls';
import Async from 'Components/Common/Async';
import CircularProgress from 'Components/Common/CircularProgress';
import { not } from 'ramda';

interface IUploadedReportViewProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function UploadedReportView(props: IUploadedReportViewProps) {
  /** State value of the reports context */
  const reportCtx = useContext(ReportContext);
  const appCtx = useContext(AppContext);
  const [reportName, setReportName] = useState('');
  const [cancelUpload, setCancelUpload] = useState(false);
  const [cancelTokenSource] = useState(getCancelToken());

  const [discardReport, , discardReportLoading, , discardSuccess] = useApi(
    props.navigation,
    false,
    'Reports',
  );

  const [
    uploadReport,
    ,
    uploading,
    uploadError,
    uploadSuccess,
    uploadProgress,
  ] = useApi(props.navigation, false, '', cancelTokenSource);

  /**
   *  Uploading the file will render the bottom navigation disabled
   *  while file is uploading a flag is added in the context to
   *  keep check of the uploading process
   */
  useEffect(() => {
    reportCtx.dispatch({
      type: 'SET_IS_UPLOADING',
      isUploading: uploading,
    });
  }, [uploading]);

  /**
   * Attaches event handler for review and pay in header
   * Check for @param editing in the navigation and set the edit mode accordingly
   */
  useSetNavParamsDidMount(
    {
      onDiscard,
      onPressReviewAndPay: reviewAndPay,
      editing: reportCtx.editMode.editing,
    },
    props.navigation,
    [reportCtx.editMode.editing, uploading],
  );

  /** Cancels upload request for report */
  useEffect(() => {
    if (cancelUpload) {
      cancelTokenSource.cancel();
      props.navigation.reset(
        [NavigationActions.navigate({ routeName: 'Reports' })],
        0,
      );
    }

    return () => {
      setCancelUpload(false);
    };
  }, [cancelUpload]);

  /**
   * Shows upload failure Alert asking the user to try again or discard
   */
  useEffect(() => {
    if (uploadError) {
      onUploadFailure();
    }
  }, [uploadError]);

  /**
   * Calls the api to upload report
   *
   * @method makeUploadApiCall
   *
   * @returns {void}
   */
  function makeUploadApiCall() {
    const method =
      reportCtx.editMode.editing || reportCtx.editMode.isReuploading
        ? 'PATCH'
        : 'POST';
    const url =
      reportCtx.editMode.editing || reportCtx.editMode.isReuploading
        ? Urls.reports.reuploadReport(reportCtx.uploadInfo.fileMeta.id)
        : Urls.reports.uploadReport;

    uploadReport(
      method,
      url,
      reportCtx.uploadInfo.reportFormData,
      false,
      false,
      true,
      'File uploaded successfully',
    );
  }

  /**
   * Makes the api call for report upload on did mount. Also makes the call if
   * @param reuploadReport changes
   */
  useEffect(() => {
    setReportName(reportCtx.uploadInfo.uploadedReportName);
    makeUploadApiCall();
  }, [reportCtx.uploadInfo.reuploadReport]);

  /**
   * Navigates to Reports screen if reported is discarded successfully.
   * Resets the report and app state
   */
  useEffect(() => {
    if (discardSuccess) {
      reportCtx.dispatch({ type: 'RESET_STATE' });
      appCtx.dispatch({ type: 'RESET_STATE' });
      props.navigation.navigate('Reports');
    }
  }, [discardSuccess]);

  /**
   * Deletes the report
   *
   * @method deleteReport
   *
   * @returns {void}
   */
  function deleteReport() {
    discardReport(
      'DELETE',
      Urls.reports.deleteReport(reportCtx.uploadInfo.fileMeta.id),
    );
  }

  /**
   * Alerts the user if report upload fails
   *
   * @method onUploadFailure
   *
   * @returns {void}
   */
  function onUploadFailure() {
    showAlert(
      'Upload Error!',
      'Do you want to try again?',
      makeUploadApiCall,
      () => {
        reportCtx.dispatch({ type: 'RESET_STATE' });
        props.navigation.reset(
          [NavigationActions.navigate({ routeName: 'Reports' })],
          0,
        );
      },
      'Try Again',
      'Discard',
    );
  }

  /**
   * Shows alert for confirmation to discard report
   *
   * @method onDiscard
   *
   * @returns {void}
   */
  function onDiscard() {
    if (uploading) {
      setCancelUpload(true);
    } else {
      showAlert(
        'Are you sure?',
        'Do you want to discard this report?',
        deleteReport,
        () => {},
        'Yes',
        'Cancel',
      );
    }
  }

  /**
   * Navigates to the Review and Pay screen
   *
   * @method reviewAndPay
   *
   * @returns {void}
   */
  function reviewAndPay() {
    props.navigation.navigate('ReviewAndPay');
  }

  /**
   * Navigates to the select doctor screen, to select the doctor from the list
   *
   * @method selectDoctor
   *
   * @returns {void}
   */
  function selectDoctor() {
    props.navigation.navigate('DoctorsList');
  }

  /**
   * Auto-Selects the doctor for the patient and skips the select doctor screen
   *
   * @method autoSelectDoctor
   *
   * @returns {void}
   */
  function autoSelectDoctor() {
    /** Sets doctor to null in report context to determine auto selection */
    reportCtx.dispatch({ type: 'SELECT_DOCTOR', doctor: null });
    /** If user is in editMode, navigate straight to Review and Pay screen */
    if (reportCtx.editMode.editing) {
      props.navigation.navigate('ReviewAndPay');
    } else {
      props.navigation.navigate('ReportPurpose');
    }
  }

  /**
   * Navigates to Upload report screen to ask the user to reupload file
   *
   * @method reuploadFile
   *
   * @param reportId
   *
   * @returns {void}
   */
  function reuploadFile() {
    reportCtx.dispatch({
      type: 'SET_EDITING_MODE',
      editMode: { isReuploading: true },
    });
    reportCtx.dispatch({ type: 'SET_REUPLOADING', reuploading: true });
    reportCtx.dispatch({ type: 'UPLOAD_REPORT', upload: true });
    appCtx.dispatch({
      type: 'SHOW_DIALOG',
      show: false,
      content: 'report',
    });
  }

  return (
    <Connectivity>
      <Async displayChildren={discardReportLoading}>
        <ImageBackground
          source={Images['app_background']}
          style={commonReportStyles.bgStyle}
        >
          <View style={uploadedReportViewStyles.container}>
            <NormalText
              text={'Uploaded Report'}
              marginTop={19}
              color={Colors.white}
              marginBottom={10}
            />
            <View style={uploadedReportViewStyles.reportPreviewContainer}>
              <View>
                <View style={uploadedReportViewStyles.reportNameContainer}>
                  <LargeText
                    text={wrapString(reportName, 10)}
                    fontFamily={Fonts.type.medium}
                  />
                  <TouchableOpacity
                    disabled={uploading}
                    onPress={reuploadFile}
                    style={uploadedReportViewStyles.reportRemoveIcon}
                  >
                    <Icon name='remove' size={20} color={Colors.cancelIcon} />
                  </TouchableOpacity>
                </View>
                <Text style={uploadedReportViewStyles.reportDateText}>
                  {formatDate(new Date())}
                </Text>
              </View>
              {uploadSuccess && !uploading ? (
                <View style={uploadedReportViewStyles.pdfViewContainer}>
                  <Text style={uploadedReportViewStyles.pdfText}>{'PDF'}</Text>
                </View>
              ) : (
                <CircularProgress uploadProgress={uploadProgress} />
              )}
            </View>

            <NormalText
              text={'Select doctor'}
              marginTop={19}
              marginBottom={10}
              color={Colors.white}
            />
            {/* Select Doctor */}
            <TouchableOpacity
              disabled={not(uploadSuccess) || uploading}
              onPress={selectDoctor}
              style={[
                uploadedReportViewStyles.selectDoctorContainer,
                { opacity: not(uploadSuccess) || uploading ? 0.7 : 1 },
              ]}
            >
              <View style={uploadedReportViewStyles.selectDoctorLeftContainer}>
                <View
                  style={uploadedReportViewStyles.selectDoctorIconContainer}
                >
                  <Icon name={'single-doctor'} color={Colors.white} size={15} />
                </View>
                <View
                  style={uploadedReportViewStyles.selectDoctorTextContainer}
                >
                  <LargeText
                    text={'Select a Specific Doctor'}
                    fontFamily={Fonts.type.bold}
                  />
                  <NormalText
                    color={Colors.text}
                    text={'Send Report to your preferred doctor'}
                    letterSpacing={-0.26}
                  />
                </View>
              </View>
              <Icon name='arrow-right' color={Colors.chevronRight} size={15} />
            </TouchableOpacity>

            {/* Auto-Select Doctor */}
            <TouchableOpacity
              disabled={not(uploadSuccess) || uploading}
              onPress={autoSelectDoctor}
              style={[
                uploadedReportViewStyles.selectDoctorContainer,
                {
                  borderTopWidth: 0,
                  opacity: not(uploadSuccess) || uploading ? 0.7 : 1,
                },
              ]}
            >
              <View style={uploadedReportViewStyles.selectDoctorLeftContainer}>
                <View
                  style={[
                    uploadedReportViewStyles.selectDoctorIconContainer,
                    { backgroundColor: Colors.darkSkyBlue },
                  ]}
                >
                  <Icon
                    name={'multiple-doctors'}
                    color={Colors.white}
                    size={15}
                  />
                </View>
                <View
                  style={uploadedReportViewStyles.selectDoctorTextContainer}
                >
                  <LargeText
                    text={'Auto Select'}
                    fontFamily={Fonts.type.bold}
                  />
                  <NormalText
                    color={Colors.text}
                    text={'Report will be available to all doctors'}
                    letterSpacing={-0.26}
                  />
                </View>
              </View>
              <Icon name='arrow-right' color={Colors.chevronRight} size={15} />
            </TouchableOpacity>
          </View>
        </ImageBackground>
      </Async>
    </Connectivity>
  );
}

UploadedReportView.navigationOptions = ({ navigation }) => ({
  title: 'Select A Doctor',
  headerLeft: (
    <TouchableOpacity
      style={uploadedReportViewStyles.headerLeftButton}
      onPress={navigation.getParam('onDiscard')}
    >
      <Text style={uploadedReportViewStyles.headerRightText}>Discard</Text>
    </TouchableOpacity>
  ),
  headerRight: Boolean(navigation.getParam('editing')) ? (
    <TouchableOpacity
      style={commonReportStyles.headerRightButton}
      onPress={navigation.getParam('onPressReviewAndPay')}
    >
      <Text style={uploadedReportViewStyles.headerRightText}>Done</Text>
    </TouchableOpacity>
  ) : null,
});

export default UploadedReportView;
