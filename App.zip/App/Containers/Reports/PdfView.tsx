import React, { useState, useEffect } from 'react';
import { View, Alert } from 'react-native';
import { Colors } from 'Themes';
import Pdf from 'react-native-pdf';
import Orientation from 'react-native-orientation-locker';
import { NavigationScreenProp, NavigationState } from 'react-navigation';

interface IPdfViewProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function PdfView(props: IPdfViewProps) {
  const [source, setSource] = useState(null);
  const [errorLoadingPdf, setErrorLoadingPdf] = useState(false);

  /** Get report source for pdf view from navigation params on mount */
  useEffect(() => {
    /** Unlocks app's orientation lock */
    Orientation.unlockAllOrientations();
    setSource(props.navigation.getParam('source'));

    return () => {
      /** Locks app in portrait mode */
      Orientation.lockToPortrait();
    };
  }, []);

  /** If report fails to load - Show alert and navigate back to previous page */
  useEffect(() => {
    if (errorLoadingPdf) {
      Alert.alert('Error Viewing Pdf', 'Unable to view pdf', [
        { text: 'OK', onPress: () => props.navigation.goBack() },
      ]);
    }

    return () => {
      setErrorLoadingPdf(false);
    };
  }, [errorLoadingPdf]);

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      {source ? (
        <Pdf
          source={source}
          onError={() => setErrorLoadingPdf(true)}
          style={{
            flex: 1,
            backgroundColor: Colors.background,
            width: '100%',
            height: '100%',
          }}
        />
      ) : null}
    </View>
  );
}

PdfView.navigationOptions = ({ navigation }) => ({
  title: 'Report View',
});

export default PdfView;
