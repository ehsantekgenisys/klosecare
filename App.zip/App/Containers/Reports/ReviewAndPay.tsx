import React, { useContext, useEffect, useReducer } from 'react';
import { View, Text, TouchableOpacity, ImageBackground } from 'react-native';
import {
  NavigationScreenProp,
  NavigationState,
  ScrollView,
  NavigationActions,
} from 'react-navigation';
import { Colors, Fonts, Images } from 'Themes';
import { ReportContext } from 'Containers/Reports/Context';
import { AppContext } from 'Contexts/AppContext';
import { useSetNavParamsDidMount, useApi } from 'CustomHooks';
import {
  reviewAndPayStyles,
  commonReportStyles,
} from 'Containers/Reports/Styles';
import { NormalText } from 'Components/Common/NormalText';
import { LargeText } from 'Components/Common/LargeText';
import { SmallText } from 'Components/Common/SmallText';
import { isNil } from 'ramda';
import Api from 'Services/Api';
import { IPurpose } from 'Types';
import { Overlay } from 'react-native-elements';
import stripe from 'tipsi-stripe';
import Icon from 'Themes/Icon';
import { Button } from 'Components/Common/Button';
import { showNotification, formatDate, showAlert, wrapString } from 'Lib/Utils';
import Urls from 'Constants/Urls';
import Connectivity from 'Components/Common/Connectivity';
import Async from 'Components/Common/Async';

const noop = () => {};

interface IReviewAndPayProps {
  navigation: NavigationScreenProp<NavigationState>;
}

/** Stripe configuration with stripe publishable key */
stripe.setOptions({
  publishableKey: 'pk_test_1RxrNWyJpAeOv7p0Fs05xH2P00FICPrSex',
});

interface IReviewAndPayState {
  isVisible: boolean;
  title: string;
  message: string;
  paymentSuccessful: boolean;
  repay: boolean;
}

/**
 *  Action types to control flow of payment
 */
export type ReviewAndPayActions =
  | { type: 'PAYMENT_SUCCESS' }
  | { type: 'PAYMENT_FAILED' }
  | { type: 'PAYMENT_INTERRUPTED' }
  | { type: 'PROCEED_TO_REPORTS_AFTER_SUCCESS' }
  | { type: 'REPAY' }
  | { type: 'RESET' };

const reducer = (state: IReviewAndPayState, action: ReviewAndPayActions) => {
  switch (action.type) {
    case 'PAYMENT_SUCCESS':
      return {
        ...state,
        isVisible: true,
        title: 'Payment approved',
        message:
          'A report has been sent to your preferred doctor. Doctor will respond to your report with-in 72-hours.',
        paymentSuccessful: true,
        repay: false,
      };
    case 'PAYMENT_FAILED':
      return {
        ...state,
        isVisible: true,
        title: 'Payment declined',
        message:
          'Something went wrong, Please try again. If you still encounter the same error, try with another payment method or contact Stripe support.',
        paymentSuccessful: false,
        repay: false,
      };
    case 'PAYMENT_INTERRUPTED':
      return {
        ...state,
        isVisible: true,
        title: 'Payment Interupted',
        message:
          'Something went wrong, Please try again. If you still encounter the same error, try with another payment method or contact Stripe support.',
        paymentSuccessful: false,
        repay: false,
      };
    case 'PROCEED_TO_REPORTS_AFTER_SUCCESS':
      return {
        ...state,
        isVisible: false,
        title: '',
        message: '',
        paymentSuccessful: false,
        repay: false,
      };
    case 'REPAY':
      return {
        ...state,
        repay: true,
      };
    case 'RESET':
      return state;
    default:
      return state;
  }
};

function ReviewAndPay(props: IReviewAndPayProps) {
  /** State value of the reports context */
  const reportCtx = useContext(ReportContext);
  /** Global app state from app context */
  const appCtx = useContext(AppContext);

  /**
   *  useReducer hook to control payment flow
   *  takes in reducer as argument and initial state
   *  of the reducer
   */
  const [reviewAndPayState, dispatch] = useReducer(reducer, {
    isVisible: false,
    paymentSuccessful: false,
    title: '',
    message: '',
    repay: false,
  });

  useSetNavParamsDidMount({ onPressPay: handlePayment }, props.navigation);
  const [
    makePayment,
    ,
    isPaymentProcessing,
    paymentFailed,
    paymentSuccess,
  ] = useApi();
  const [cancelReport, , isDeleting, , deleteSuccess] = useApi(
    props.navigation,
    false,
    'Reports',
  );

  /**
   *  handle repay if the repay flag
   *  has been set call the handlepayment
   *  function
   */
  useEffect(() => {
    if (reviewAndPayState.repay) {
      // resetOverlayControls();
      handlePayment();
    }
  }, [reviewAndPayState.repay]);
  /**
   * Mocks ComponentDidMount
   * Sets editing mode to false in reprot context and updates report meta data whenever this components mount.
   * After editing report meta data, all user will finally navigate to this component, so
   * whenever this component mounts report meta data will be updated in the backend.
   */
  useEffect(() => {
    reportCtx.dispatch({
      type: 'SET_EDITING_MODE',
      editMode: { editing: false, isReuploading: false },
    });
    const {
      doctor,
      comments,
      purposes,
      uploadInfo: { fileMeta },
      medication,
    } = reportCtx;
    const patchBody = {
      doctor: doctor ? doctor.id : null,
      comments,
      purposes: purposes.map((purpose) => purpose.id),
      diet: medication.diet.map((diet) => diet.id),
      medicine: {
        other: medication.medicine.other.map((other) => {
          return {
            name: other.name,
            dose: other.dose,
            frequency: other.frequency,
          };
        }),
        insulin: medication.medicine.insulin.map((insulin) => {
          return {
            name: insulin.name,
            dose: insulin.dose,
            frequency: insulin.frequency,
          };
        }),
      },
      exercise: medication.exercise.map((exercise) => {
        return {
          type: exercise.name,
          days_per_week: exercise.frequency,
          duration: exercise.hours,
        };
      }),
      estimated_calories: medication.estimatedCalories,
    };
    Api({
      method: 'PATCH',
      url: Urls.reports.reportMeta(fileMeta.id),
      data: patchBody,
    })
      .then(noop)
      .catch(() => {
        showNotification('Failed to update report data');
        // console.tron.warn('Report Patch failed ' + err);
      });
  }, []);

  /**
   * If deletion or payment is successful, then reset the report context state.
   * Also refetch the reports as a result of delete by dispatching UPDATE_DID_MOUNT_DEPS for reports
   */
  useEffect(() => {
    if (deleteSuccess) {
      reportCtx.dispatch({ type: 'RESET_STATE' });
    }
  }, [deleteSuccess, paymentSuccess]);

  /**
   * For payment integration, monitoring the paymentResponse , if its success
   * we show success overlay using overlay control state if there is any api error (paymentFailed)
   * we show error overlay in case of stripe errors
   */
  useEffect(() => {
    if (paymentSuccess) {
      /** In case of success show over lay with success controls */
      dispatch({ type: 'PAYMENT_SUCCESS' });
    }

    if (paymentFailed) {
      /** In case of error show over lay with error controls */
      dispatch({ type: 'PAYMENT_FAILED' });

      showNotification('Unable to process payment');
    }

    if (deleteSuccess) {
      /**
       * Reset overlay controls and navigate to reports after
       * delete report success
       */
      dispatch({ type: 'RESET' });
      props.navigation.reset(
        [NavigationActions.navigate({ routeName: 'Reports' })],
        0,
      );
    }
  }, [paymentSuccess, paymentFailed, deleteSuccess]);

  /**
   * TODO: Handles Payment
   *
   * @method handlePayment
   *
   * @returns {void}
   */
  function handlePayment() {
    return stripe
      .paymentRequestWithCardForm()
      .then((stripeToken) => {
        makePayment(
          'POST',
          Urls.reports.payment(reportCtx.uploadInfo.fileMeta.id),
          {
            stripe_token: stripeToken.tokenId,
          },
        );
      })
      .catch((error) => {
        /** In case of error show over lay with error controls */
        // console.tron.log('ERROR', error);
        if (error.code === 'cancelled') {
          showNotification(`${error}`);
        } else {
          dispatch({ type: 'PAYMENT_INTERRUPTED' });
          showNotification(`Error: ${error}`);
        }
      });
  }

  /**
   * Deletes the report and resets the state of report context
   * and overlay controls
   */
  function confirmDeleteReport() {
    cancelReport(
      'DELETE',
      Urls.reports.deleteReport(reportCtx.uploadInfo.fileMeta.id),
    );
  }

  /**
   * Navigates the user to the appropriate screen to edit the report meta data
   * Also sets the @param editing to true in the navigation so we can keep track if the
   * user is editing information
   *
   * @method navigateAndEdit
   *
   * @param {string} screenName
   *
   * @returns {void}
   */
  function navigateAndEdit(screenName: string) {
    props.navigation.navigate(screenName);
    reportCtx.dispatch({
      type: 'SET_EDITING_MODE',
      editMode: { editing: true },
    });
  }

  return (
    <Async displayChildren={isPaymentProcessing || isDeleting}>
      <ImageBackground
        source={Images['app_background']}
        style={commonReportStyles.bgStyle}
      >
        <Connectivity>
          <ScrollView
            contentInset={{ bottom: 50 }}
            style={reviewAndPayStyles.container}
          >
            <Overlay
              isVisible={reviewAndPayState.isVisible && !deleteSuccess}
              windowBackgroundColor='rgba(255, 255, 255, .5)'
              overlayBackgroundColor={Colors.mildLightGray}
              width={270}
              height={270}
              overlayStyle={reviewAndPayStyles.overlayStyle}
            >
              <View
                style={[
                  reviewAndPayStyles.iconStyle,
                  reviewAndPayState.paymentSuccessful
                    ? reviewAndPayStyles.iconStyleSuccess
                    : reviewAndPayStyles.iconStyleError,
                ]}
              >
                <Icon
                  name={
                    reviewAndPayState.paymentSuccessful
                      ? 'card-success'
                      : 'card-error'
                  }
                  size={20}
                  color={Colors.white}
                />
              </View>

              <LargeText
                marginTop={20}
                textAlign={'center'}
                text={reviewAndPayState.title}
                fontFamily={Fonts.type.bold}
              />
              <SmallText
                marginTop={5}
                textAlign={'center'}
                text={reviewAndPayState.message}
              />
              <View
                style={{
                  alignSelf: 'stretch',
                  height: 0.5,
                  width: '100%',
                  backgroundColor: Colors.black,
                  marginTop: 26,
                  marginBottom: 12,
                }}
              />

              {reviewAndPayState.paymentSuccessful ? (
                <Button
                  onPress={() => {
                    dispatch({ type: 'PROCEED_TO_REPORTS_AFTER_SUCCESS' });
                    reportCtx.dispatch({ type: 'RESET_STATE' });
                    props.navigation.reset(
                      [NavigationActions.navigate({ routeName: 'Reports' })],
                      0,
                    );
                  }}
                  textColor={Colors.darkSkyBlue}
                  buttonText={'Proceed To Report'}
                />
              ) : (
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                  }}
                >
                  <Button
                    onPress={() =>
                      showAlert(
                        'Delete Report ?',
                        'Are you sure you want to delete this report ?',
                        confirmDeleteReport,
                        () => {},
                        'OK',
                        'Cancel',
                      )
                    }
                    textColor={Colors.error}
                    buttonText={'Cancel'}
                  />
                  <Button
                    onPress={() => dispatch({ type: 'REPAY' })}
                    textColor={Colors.darkSkyBlue}
                    buttonText={'Repay'}
                  />
                </View>
              )}
            </Overlay>

            {/* Report Info */}
            <TouchableOpacity
              onPress={() => navigateAndEdit('UploadedReport')}
              style={reviewAndPayStyles.sectionContainer}
            >
              <Text style={reviewAndPayStyles.sectionHeading}>Report</Text>
              <View style={reviewAndPayStyles.reportViewContainer}>
                <View>
                  <LargeText
                    text={wrapString(reportCtx.uploadInfo.fileMeta.file.name)}
                  />
                  <Text style={reviewAndPayStyles.reportDateText}>
                    {formatDate(reportCtx.uploadInfo.fileMeta.created_at)}
                  </Text>
                </View>
                <View style={reviewAndPayStyles.pdfViewContainer}>
                  <Text style={reviewAndPayStyles.pdfText}>PDF</Text>
                </View>
              </View>
            </TouchableOpacity>

            {/* Health Summary */}
            <TouchableOpacity
              onPress={() => navigateAndEdit('HealthSummary')}
              style={reviewAndPayStyles.sectionContainer}
            >
              <Text style={reviewAndPayStyles.sectionHeading}>
                Health Summary
              </Text>
              <NormalText
                text={`Check your medication, exercise and calories in detail`}
                color={Colors.reportText}
                marginTop={5}
                marginBottom={5}
              />
            </TouchableOpacity>

            {/* Doctor Info */}
            <TouchableOpacity
              onPress={() => navigateAndEdit('UploadedReport')}
              style={reviewAndPayStyles.sectionContainer}
            >
              <Text style={reviewAndPayStyles.sectionHeading}>Doctor</Text>
              <NormalText
                text={
                  isNil(reportCtx.doctor)
                    ? 'All Available Doctors'
                    : reportCtx.doctor.name
                }
                color={Colors.reportText}
                marginTop={5}
                marginBottom={5}
              />
            </TouchableOpacity>

            {/* Report Purpose */}
            <TouchableOpacity
              onPress={() => navigateAndEdit('ReportPurpose')}
              style={reviewAndPayStyles.sectionContainer}
            >
              <Text style={reviewAndPayStyles.sectionHeading}>Purpose</Text>
              {reportCtx.purposes.map((purpose: IPurpose) => (
                <NormalText
                  key={purpose.id}
                  text={purpose.purpose}
                  color={Colors.reportText}
                  marginTop={5}
                  marginBottom={5}
                />
              ))}
            </TouchableOpacity>

            {/* Report Comments */}
            <TouchableOpacity
              onPress={() => navigateAndEdit('ReportPurpose')}
              style={reviewAndPayStyles.sectionContainer}
            >
              <Text style={reviewAndPayStyles.sectionHeading}>Comments</Text>
              <NormalText
                text={
                  Boolean(reportCtx.comments)
                    ? reportCtx.comments
                    : 'No comments added'
                }
                color={
                  Boolean(reportCtx.comments) ? Colors.reportText : Colors.error
                }
                marginTop={5}
                marginBottom={5}
              />
            </TouchableOpacity>

            {/* Report Fee */}
            <View style={reviewAndPayStyles.sectionContainer}>
              <Text style={reviewAndPayStyles.sectionHeading}>Fee</Text>
              <NormalText
                text={'$50 for report review'}
                color={Colors.reportText}
                marginTop={5}
                marginBottom={5}
              />
            </View>
          </ScrollView>
        </Connectivity>
      </ImageBackground>
    </Async>
  );
}

ReviewAndPay.navigationOptions = ({ navigation }) => ({
  title: 'Review and Pay',
  headerLeft: (
    <TouchableOpacity
      onPress={() => navigation.navigate('HealthSummary')}
      style={commonReportStyles.backButtonContainer}
    >
      <Icon name='arrow-left' color={Colors.white} size={20} />
      <LargeText
        text={'Back'}
        color={Colors.white}
        fontFamily={Fonts.type.regular}
        marginLeft={6}
      />
    </TouchableOpacity>
  ),
  headerRight: (
    <TouchableOpacity
      onPress={navigation.getParam('onPressPay')}
      style={commonReportStyles.headerRightButton}
    >
      <LargeText
        text={'Pay'}
        color={Colors.white}
        letterSpacing={0.37}
        fontFamily={Fonts.type.regular}
      />
    </TouchableOpacity>
  ),
});

export default ReviewAndPay;
