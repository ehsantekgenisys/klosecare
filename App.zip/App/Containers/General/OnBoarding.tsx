import React, { useState, useRef, useEffect, useContext } from 'react';
import { View, StyleSheet } from 'react-native';
import Carousel from 'react-native-snap-carousel';
import OnBoardingSlide from 'Components/General/OnBoardingSlide';
import { PositionBottom } from 'Components/Common/PositionBottom';
import { Dot } from 'Components/General/DotIndicator';
import { SCREEN_WIDTH } from 'Constants';
import { IOnboardingSlideData } from 'Types';
import { NavigationState, NavigationScreenProp } from 'react-navigation';
import SplashScreen from 'react-native-splash-screen';
import AsyncStorage from '@react-native-community/async-storage';
import { not, isNil } from 'ramda';
import AuthenticationManager from 'Lib/Keychain/AuthenticationManager';
import { AppContext } from 'Contexts/AppContext';

const noop = () => {};

const onBoardingSlidesData: IOnboardingSlideData[] = [
  {
    title: 'Personal Diabetes Management',
    text:
      'Healthcare should always be simple and fast. Manage your diabetes with actionable insights using Klosecare',
    buttonText: 'Skip',
    lastSlide: false,
    imageSrc: 'onBoarding1',
  },
  {
    title: 'Live consultation with doctors',
    text:
      'Talking to doctor is just a click away using our on-demand telemedicine platform',
    buttonText: 'Skip',
    lastSlide: false,
    imageSrc: 'onBoarding2',
  },
  {
    title: 'Devices Interpretation',
    text:
      'Klosecare provider will assist you with CGMs and Insulin pump data interpretation.',
    buttonText: 'Skip',
    lastSlide: false,
    imageSrc: 'onBoarding3',
  },
  {
    title: 'Diabetes e-learning',
    text:
      'Empower yourself with the diabetes knowledge using our library of educational videos. ',
    buttonText: 'Get Started',
    lastSlide: true,
    imageSrc: 'onBoarding4',
  },
];

const styles = StyleSheet.create({
  dotIndicatorContainer: {
    flexDirection: 'row',
    alignSelf: 'center',
  },
});

interface IOnBoardingProps {
  navigation: NavigationScreenProp<NavigationState>;
}
function OnBoarding(props: IOnBoardingProps) {
  const [activeSlideNumber, setActiveSlideNumber] = useState(0);
  const appCtx = useContext(AppContext);

  /**
   * Checks if the user's onboarding flow has been completed, based on that it navigates
   * the user to appropriate Navigation stack. Hides the splash screen after navigating
   */
  useEffect(() => {
    /** Set transparency of status bar to true */
    appCtx.dispatch({ type: 'SET_STATUS_BAR_TRANSPARENCY', transparent: true });
    const authManager = new AuthenticationManager();
    const fromAuth = props.navigation.getParam('fromAuth');

    /** If onboarding is accessesed from auth screens then don't do anything */
    if (fromAuth) {
      return;
    }

    /**
     * Removes the auth token from the keychain.
     * Ideally this should be removed as soon as the app is killed but there is no proper way
     * to handle app termination on JS side.
     * @source https://github.com/facebook/react-native/issues/9348
     * Handling this on native side will cause an overhead
     *
     * That's why I opted to remove auth token from keychain on startup
     */
    authManager
      .remove()
      .then(noop)
      .catch(noop);

    /** Gets the lastLoggedEmail from async storage and saves it in app context */
    AsyncStorage.getItem('lastLoggedEmail')
      .then((email) => {
        if (email) {
          appCtx.dispatch({ type: 'SET_LAST_LOGGED_EMAIL', email });
        }
      })
      .catch(noop);

    AsyncStorage.getItem('onboarding')
      .then((val) => {
        if (not(isNil(val))) {
          props.navigation.navigate('AuthNav');
          SplashScreen.hide();
        } else {
          props.navigation.navigate('IntroNav');
          AsyncStorage.setItem('onboarding', 'true')
            .then(noop)
            .catch(noop);
          SplashScreen.hide();
        }
      })
      .catch(() => {
        props.navigation.navigate('IntroNav');
        SplashScreen.hide();
      });

    return () => {
      appCtx.dispatch({
        type: 'SET_STATUS_BAR_TRANSPARENCY',
        transparent: false,
      });
    };
  }, []);

  /**
   * Sets the active slide number in state when user slides
   *
   * @method onSlide
   *
   * @param {number} slideIndex
   *
   * @returns {void}
   */
  function onSlide(slideIndex) {
    setActiveSlideNumber(slideIndex);
  }

  /**
   * Navigates to login screen
   *
   * @method navigateToLogin
   *
   * @returns {void}
   */
  function skipOnboarding() {
    props.navigation.navigate('Signup');
    /** Set transparency of the status bar to false after navigating to Signup */
    appCtx.dispatch({
      type: 'SET_STATUS_BAR_TRANSPARENCY',
      transparent: false,
    });
  }

  /**
   * Renders Onboarding slide
   *
   * @method renderOnboardingSlide
   *
   * @param {item: IOnboardingSlideData; index: number} data
   *
   * @returns {void}
   */
  function renderOnboardingSlide(data: {
    item: IOnboardingSlideData;
    index: number;
  }) {
    return <OnBoardingSlide item={data.item} skipOnboarding={skipOnboarding} />;
  }

  return (
    <React.Fragment>
      <Carousel
        data={onBoardingSlidesData}
        renderItem={renderOnboardingSlide}
        sliderWidth={SCREEN_WIDTH}
        itemWidth={SCREEN_WIDTH}
        removeClippedSubviews={false}
        inactiveSlideScale={1.0}
        inactiveSlideOpacity={1.0}
        slideStyle={{ alignSelf: 'center' }}
        onSnapToItem={onSlide}
      />

      {PositionBottom(
        <View style={styles.dotIndicatorContainer}>
          {onBoardingSlidesData.map((item, index) => (
            <Dot key={index} selected={index === activeSlideNumber} />
          ))}
        </View>,
      )}
    </React.Fragment>
  );
}

export default OnBoarding;
