import { StyleSheet } from 'react-native';
import { Colors, Fonts } from 'Themes';

export const commonMoreStyles = StyleSheet.create({
  bgStyle: { width: '100%', height: '100%' },
  listItemContainer: {
    flexDirection: 'row',
    alignSelf: 'stretch',
    height: 35,
    marginBottom: 20,
  },
  listItemRightContainer: {
    alignSelf: 'stretch',
    flex: 1,
  },
  listItemTitleIconContainer: {
    flexDirection: 'row',
    alignSelf: 'stretch',
    justifyContent: 'space-between',
    flex: 1,
    paddingRight: 15,
  },
  separatorLine: {
    alignSelf: 'stretch',
    height: 1,
    backgroundColor: Colors.moreListSeparator,
  },
  listInnerContainer: {
    flexDirection: 'row',
    alignSelf: 'stretch',
    marginBottom: 15,
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingRight: 10,
  },
  backButtonContainer: {
    flexDirection: 'row',
    marginLeft: 9,
    paddingRight: 25,
  },
  headerRightButton: {
    marginRight: 10,
    paddingLeft: 20,
  },
});

export const moreScreenStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.transparent,
  },
  innerContainer: {
    flex: 1,
    paddingLeft: 15,
  },
  bottomButtonContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    alignSelf: 'stretch',
  },
  logoutButton: {
    marginHorizontal: 30,
    alignSelf: 'stretch',
    height: 50,
    borderRadius: 10,
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
});

export const settingStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.transparent,
    paddingVertical: 30,
    paddingLeft: 15,
  },
  innerContainer: {
    flex: 1,
    paddingLeft: 15,
  },
});

export const changePasswordStyles = StyleSheet.create({
  header: {
    backgroundColor: Colors.headerPrimary,
    elevation: 0,
    borderBottomWidth: 0.3,
    borderBottomColor: Colors.headerBorder,
    height: 44,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerLeft: {
    flexDirection: 'row',
    marginLeft: 9,
    paddingRight: 25,
  },
  headerTitle: {
    color: Colors.white,
    textAlign: 'center',
    flex: 1,
    alignSelf: 'center',
    fontFamily: Fonts.type.medium,
    fontSize: 17,
    lineHeight: 22,
    marginLeft: -25,
  },
});
