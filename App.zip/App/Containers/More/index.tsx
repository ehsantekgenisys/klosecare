import React, { useEffect } from 'react';
import { View, ImageBackground, TouchableOpacity } from 'react-native';
import { Colors, Images } from 'Themes';
import TopSecionIOS from 'Components/Common/TopSectionIOS';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { LargeText } from 'Components/Common/LargeText';
import { useApi } from 'CustomHooks';
import Urls from 'Constants/Urls';
import Async from 'Components/Common/Async';
import AuthenticationManager from 'Lib/Keychain/AuthenticationManager';
import { showNotification } from 'Lib/Utils';
import { moreScreenStyles, commonMoreStyles } from 'Containers/More/Styles';
import MoreListItem from 'Containers/More/Shared/MoreListItem';

const noop = () => {};

interface IMoreProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function More(props: IMoreProps) {
  const [logoutUser, , loggingOut, logoutError, logoutSuccess] = useApi(
    props.navigation,
  );

  /** Remove auth token and navigate to login screen */
  useEffect(() => {
    if (logoutError) {
      showNotification('Unable to logout. Please try again!');
    }
    if (logoutSuccess) {
      // Remove authentication token from keychain
      const authManager = new AuthenticationManager();
      authManager
        .remove()
        .then(noop)
        .catch(noop);
      props.navigation.navigate('AuthNav');
    }
  }, [logoutError, logoutSuccess]);

  /** Logouts user from the app */
  function logout() {
    logoutUser('GET', Urls.auth.logout, null, true);
  }

  return (
    <Async displayChildren={loggingOut}>
      <ImageBackground
        source={Images.app_background}
        style={commonMoreStyles.bgStyle}
      >
        <View style={moreScreenStyles.container}>
          <TopSecionIOS headerText={'More'} hideButton={true} />
          <View style={moreScreenStyles.innerContainer}>
            <MoreListItem
              iconName={'settings'}
              title={'Settings'}
              navigateTo={'Settings'}
              navigation={props.navigation}
            />
          </View>
          {/* Logout Button */}
          <View style={moreScreenStyles.bottomButtonContainer}>
            <TouchableOpacity
              onPress={logout}
              style={moreScreenStyles.logoutButton}
            >
              <LargeText text={'Logout'} color={Colors.logoutText} />
            </TouchableOpacity>
          </View>
        </View>
      </ImageBackground>
    </Async>
  );
}

More.navigationOptions = ({ navigation }) => ({
  header: null,
});

export default More;
