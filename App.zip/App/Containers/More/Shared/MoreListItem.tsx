import React from 'react';
import { TouchableOpacity, View } from 'react-native';
import { LargeText } from 'Components/Common/LargeText';
import Icon from 'Themes/Icon';
import { Colors, Fonts } from 'Themes';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { commonMoreStyles } from 'Containers/More/Styles';

interface IMoreListItemProps {
  iconName: string;
  title: string;
  navigateTo: string;
  navigation: NavigationScreenProp<NavigationState>;
  iconSize?: number;
  iconPaddingTop?: number;
}

export default function MoreListItem({
  iconName,
  title,
  navigateTo,
  navigation,
  iconSize,
  iconPaddingTop,
}: IMoreListItemProps) {
  return (
    <TouchableOpacity
      style={commonMoreStyles.listItemContainer}
      onPress={() => navigation.navigate(navigateTo)}
    >
      <View
        style={{
          width: 40,
          alignItems: 'center',
          paddingTop: iconPaddingTop ? iconPaddingTop : 0,
        }}
      >
        <Icon
          name={iconName}
          size={iconSize ? iconSize : 20}
          color={Colors.white}
        />
      </View>

      <View style={commonMoreStyles.listItemRightContainer}>
        <View style={commonMoreStyles.listItemTitleIconContainer}>
          <LargeText
            text={title}
            color={Colors.white}
            fontFamily={Fonts.type.regular}
          />
          <Icon
            name={'arrow-right'}
            size={15}
            color={Colors.white}
            style={{ marginTop: 5 }}
          />
        </View>
        {/* Separator */}
        <View style={commonMoreStyles.separatorLine} />
      </View>
    </TouchableOpacity>
  );
}
