import React, { useEffect } from 'react';
import { View, Alert, TouchableOpacity, Text } from 'react-native';
import Async from 'Components/Common/Async';
import {
  NavigationScreenProp,
  NavigationState,
  NavigationActions,
} from 'react-navigation';
import { FieldType, IChangePasswordFormValues } from 'Types';
import { Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import { InputField } from 'Components/Common/InputField';
import { useApi } from 'CustomHooks';
import Urls from 'Constants/Urls';
import { showNotification } from 'Lib/Utils';
import { Colors, Fonts } from 'Themes';
import { equals, not } from 'ramda';
import { changePasswordStyles } from 'Containers/More/Styles';
import Icon from 'Themes/Icon';
import { LargeText } from 'Components/Common/LargeText';

interface IChangePasswordProps {
  navigation: NavigationScreenProp<NavigationState>;
}

const ChangePasswordSchema = Yup.object().shape({
  password: Yup.string().required(''),
  newPassword: Yup.string().required(''),
  confirmPassword: Yup.string().required(''),
});

function ChangePassword(props: IChangePasswordProps) {
  const [changePassword, , isLoading, , isSuccess] = useApi();

  useEffect(() => {
    if (isSuccess) {
      props.navigation.reset(
        [NavigationActions.navigate({ routeName: 'More' })],
        0,
      );
      showNotification('Password updated successfully!');
    }
  }, [isSuccess]);

  function updatePassword(values: IChangePasswordFormValues) {
    if (!values.password || !values.newPassword || !values.confirmPassword) {
      Alert.alert('Empty Fields', 'All fields are required');
      return;
    }
    if (
      !values.newPassword.match(
        /^(?=.*\d)(?=.*[!@#\$%\^\&*\)\(+=._-])(?=.*[a-z])(?=.*[A-Z]).{8,}$/,
      ) ||
      !values.confirmPassword.match(
        /^(?=.*\d)(?=.*[!@#\$%\^\&*\)\(+=._-])(?=.*[a-z])(?=.*[A-Z]).{8,}$/,
      )
    ) {
      Alert.alert(
        'Password Rule Violation',
        'Password length must be atleast 8 characters including 1 capital letter, 1 lower case letter, 1 number and a special character',
      );
      return;
    }

    /** Notify the user about password mismatch */
    if (not(equals(values.newPassword, values.confirmPassword))) {
      Alert.alert(
        'Password Mismatch',
        'New and Confirm Password should be the same',
      );
      return;
    }

    if (equals(values.password, values.newPassword)) {
      Alert.alert('Same Password', 'Old and New Password cannot be the same');
      return;
    }

    changePassword('PATCH', Urls.auth.changePassword, {
      old_password: values.password,
      new_password: values.newPassword,
    });
  }

  return (
    <Async displayChildren={isLoading}>
      <Formik
        initialValues={{
          password: '',
          newPassword: '',
          confirmPassword: '',
        }}
        onSubmit={updatePassword}
        validationSchema={ChangePasswordSchema}
      >
        {(formProps: FormikProps<IChangePasswordFormValues>) => {
          return (
            <View style={{ flex: 1 }}>
              {/* Header */}
              <View style={changePasswordStyles.header}>
                <TouchableOpacity
                  onPress={() => props.navigation.goBack()}
                  style={changePasswordStyles.headerLeft}
                >
                  <Icon name='arrow-left' color={Colors.white} size={20} />
                  <LargeText
                    text={'Back'}
                    color={Colors.white}
                    fontFamily={Fonts.type.regular}
                    marginLeft={6}
                  />
                </TouchableOpacity>
                <Text style={changePasswordStyles.headerTitle}>
                  Change Password
                </Text>

                <TouchableOpacity
                  onPress={formProps.handleSubmit}
                  style={{ marginRight: 10 }}
                >
                  {/* If the user is editing info show done  */}
                  <LargeText
                    text={'Submit'}
                    fontFamily={Fonts.type.regular}
                    letterSpacing={0.37}
                    color={Colors.white}
                  />
                </TouchableOpacity>
              </View>

              {/* Body */}
              <View style={{ paddingHorizontal: 18, paddingVertical: 18 }}>
                <InputField
                  placeholder={'Old Password'}
                  fieldName='password'
                  fieldType={FieldType.password}
                  returnKeyType={'next'}
                  {...formProps}
                />
                <InputField
                  placeholder={'New Password'}
                  fieldName='newPassword'
                  fieldType={FieldType.password}
                  returnKeyType={'next'}
                  {...formProps}
                />
                <InputField
                  placeholder={'Confirm Password'}
                  fieldName='confirmPassword'
                  fieldType={FieldType.password}
                  returnKeyType={'done'}
                  {...formProps}
                />
              </View>
            </View>
          );
        }}
      </Formik>
    </Async>
  );
}

ChangePassword.navigationOptions = ({ navigation }) => ({
  header: null,
});

export default ChangePassword;
