import React from 'react';
import { View, ImageBackground } from 'react-native';
import { Images } from 'Themes';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { commonMoreStyles, settingStyles } from 'Containers/More/Styles';
import MoreListItem from 'Containers/More/Shared/MoreListItem';

interface ISettingsProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function Settings(props: ISettingsProps) {
  return (
    <ImageBackground
      source={Images.app_background}
      style={commonMoreStyles.bgStyle}
    >
      <View style={settingStyles.container}>
        {/* <MoreListItem
          iconName={'card-success'}
          title={'Payments'}
          navigateTo={'Payments'}
          navigation={props.navigation}
          iconSize={15}
          iconPaddingTop={5}
        /> */}
        <MoreListItem
          iconName={'lock'}
          title={'Change Password'}
          navigateTo={'ChangePassword'}
          navigation={props.navigation}
        />
      </View>
    </ImageBackground>
  );
}

Settings.navigationOptions = ({ navigation }) => ({
  title: 'Settings',
});

export default Settings;
