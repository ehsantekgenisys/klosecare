import React from 'react';
import { View, ImageBackground } from 'react-native';
import { Images } from 'Themes';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { commonMoreStyles, settingStyles } from 'Containers/More/Styles';
import MoreListItem from 'Containers/More/Shared/MoreListItem';

interface IPaymentsProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function Payments(props: IPaymentsProps) {
  return (
    <ImageBackground
      source={Images.app_background}
      style={commonMoreStyles.bgStyle}
    >
      <View style={settingStyles.container}>
        <MoreListItem
          iconName={'card-success'}
          title={'Dummy payment screen'}
          navigateTo={'Dummy'}
          navigation={props.navigation}
          iconSize={15}
          iconPaddingTop={5}
        />
      </View>
    </ImageBackground>
  );
}

Payments.navigationOptions = ({ navigation }) => ({
  title: 'Payments',
});

export default Payments;
