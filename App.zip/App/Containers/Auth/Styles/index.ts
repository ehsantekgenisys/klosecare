import { StyleSheet } from 'react-native';
import { Colors, Fonts } from 'Themes';

export const commonAuthStyles = StyleSheet.create({
  bgStyle: { width: '100%', height: '100%' },
  questionIcon: {
    position: 'absolute',
    bottom: 40,
    right: 15,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10,
  },
});

export const loginStyles = StyleSheet.create({
  formikContainer: {
    flex: 1,
  },
  loginContainer: { paddingHorizontal: 18 },
  bottomBannerStyling: {
    marginTop: 40,
  },
  facebookButton: {
    alignSelf: 'center',
    marginTop: 17,
    marginBottom: 30,
    paddingHorizontal: 8,
  },
});

export const signupStyles = StyleSheet.create({
  formikContainer: {
    flex: 1,
  },
  signUpContainer: { paddingHorizontal: 18 },
  termsAndConditionsView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 18,
    marginBottom: 54,
  },
  facebookButton: {
    alignSelf: 'center',
    marginTop: 17,
    marginBottom: 30,
  },
  checkCircleIcon: {
    marginRight: 10,
  },
});

export const forgotPasswordStyles = StyleSheet.create({
  formikContainer: {
    flex: 1,
  },
  forgotPasswordContainer: { paddingHorizontal: 18 },
  header: {
    backgroundColor: Colors.headerPrimary,
    elevation: 0,
    borderBottomWidth: 0.3,
    borderBottomColor: Colors.headerBorder,
    height: 44,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerLeft: {
    flexDirection: 'row',
    marginLeft: 9,
    paddingRight: 25,
  },
  headerTitle: {
    color: Colors.white,
    textAlign: 'center',
    flex: 1,
    alignSelf: 'center',
    fontFamily: Fonts.type.medium,
    fontSize: 17,
    lineHeight: 22,
  },
});
