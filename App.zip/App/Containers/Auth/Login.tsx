import React, { useEffect, useContext } from 'react';
import {
  ScrollView,
  View,
  TouchableOpacity,
  Linking,
  ImageBackground,
} from 'react-native';
import Async from 'Components/Common/Async';
import TopSecionIOS from 'Components/Common/TopSectionIOS';
import { LoginManager, AccessToken } from 'react-native-fbsdk';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { Button } from 'Components/Common/Button';
import Icon from 'Themes/Icon';
import { Colors, Images } from 'Themes';
import { ILoginFormValues, FieldType } from 'Types';
import { Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import { InputField } from 'Components/Common/InputField';
import { showNotification } from 'Lib/Utils';
import { loginStyles, commonAuthStyles } from 'Containers/Auth/Styles';
import { NormalText } from 'Components/Common/NormalText';
import { useApi } from 'CustomHooks';
import Urls from 'Constants/Urls';
import AsyncStorage from '@react-native-community/async-storage';
import { AppContext } from 'Contexts/AppContext';

const noop = () => {};

const LoginSchema = Yup.object().shape({
  email: Yup.string()
    .email()
    .required(' '),
  password: Yup.string().required(' '),
});

interface ILogingProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function Login(props: ILogingProps) {
  const [facebookLogin, , facebookLoading] = useApi(props.navigation, true);
  const [emailLogin, , emailLoading] = useApi(props.navigation, true);

  const appCtx = useContext(AppContext);

  /**
   * Handles deep linking for our app.
   * @source https://facebook.github.io/react-native/docs/linking
   * For now we are handling only reset password. If the url contains reset password in it,
   * we will navigate the user to reset password screen
   */
  useEffect(() => {
    function handleOpenURL(event) {
      if (event.url.includes('resetpassword')) {
        const [appUrl, routeName, userId, authKey] = event.url
          .split('/')
          .filter(Boolean);
        props.navigation.navigate('ResetPassword', { userId, authKey });
      }
    }
    Linking.addEventListener('url', handleOpenURL);

    return () => {
      Linking.removeEventListener('url', handleOpenURL);
    };
  }, []);

  /**
   * Authenticates user through facebook
   *
   * @method onFacebookLogin
   *
   * @returns {void}
   */
  function onFacebookLogin() {
    /** Generates a token from LoginManager of facebook to be used as authentication */
    LoginManager.logInWithPermissions(['public_profile', 'email']).then(
      (result) => {
        try {
          if (result.isCancelled) {
            showNotification('Facebook Authorization Interrupted');
          } else {
            AccessToken.getCurrentAccessToken().then((data) => {
              facebookLogin(
                'POST',
                Urls.auth.facebook,
                { access_token: data.accessToken.toString(), user_type: 2 },
                true,
              );
            });
          }
        } catch (error) {
          showNotification('Facebook Authorization Failed');
        }
      },
    );
  }

  /**
   * Navigates to signup screen
   *
   * @method navigateToSignup
   *
   * @returns {void}
   */
  function navigateToSignup() {
    props.navigation.navigate('Signup', { transition: 'scaleYWithOpacity' });
  }

  /**
   * Navigates to forgot password screen
   *
   * @method navigateToForgotPassword
   *
   * @returns {void}
   */
  function navigateToForgotPassword() {
    props.navigation.navigate('ForgotPassword', { transition: 'zoomIn' });
  }

  /**
   * Calls the login api to log user in
   *
   * @method loginUser
   *
   * @param {ILoginFormValues} values
   *
   * @returns {void}
   */
  function loginUser(values: ILoginFormValues) {
    emailLogin('POST', Urls.auth.login, values);
    AsyncStorage.setItem('lastLoggedEmail', values.email)
      .then(noop)
      .catch(noop);
    appCtx.dispatch({ type: 'SET_LAST_LOGGED_EMAIL', email: values.email });
  }

  /**
   * Takes user to onboarding flow
   *
   * @method navigateToOnboardingFlow
   *
   * @returns {void}
   */
  function navigateToOnboardingFlow() {
    props.navigation.navigate('OnBoarding', { fromAuth: true });
  }

  return (
    <Async displayChildren={emailLoading || facebookLoading}>
      <ImageBackground
        source={Images['app_background']}
        style={commonAuthStyles.bgStyle}
      >
        <TouchableOpacity
          onPress={navigateToOnboardingFlow}
          style={commonAuthStyles.questionIcon}
        >
          <Icon name={'question'} color={'white'} size={30} />
        </TouchableOpacity>
        <Formik
          initialValues={{
            email: appCtx.lastLoggedEmail,
            password: '',
          }}
          onSubmit={loginUser}
          validationSchema={LoginSchema}
        >
          {(formProps: FormikProps<ILoginFormValues>) => {
            return (
              <View style={loginStyles.formikContainer}>
                <TopSecionIOS
                  isIcon={false}
                  buttonText={'Login'}
                  headerText={'Login'}
                  iconName={'add'}
                  onPress={formProps.handleSubmit}
                  buttonDisabled={!formProps.isValid}
                />
                <ScrollView>
                  <View style={loginStyles.loginContainer}>
                    <InputField
                      placeholder={'Enter Your Email'}
                      fieldName='email'
                      fieldType={FieldType.text}
                      keyboardType={'email-address'}
                      returnKeyType={'next'}
                      {...formProps}
                    />
                    <InputField
                      placeholder={'Password'}
                      fieldName='password'
                      fieldType={FieldType.password}
                      returnKeyType={'done'}
                      {...formProps}
                    />
                    <Button
                      alignSelf={'flex-end'}
                      textColor={Colors.button}
                      buttonText={'Forgot Password?'}
                      onPress={navigateToForgotPassword}
                      isLink={true}
                    />
                    <NormalText
                      text={'─────── OR Login With ───────'}
                      textAlign={'center'}
                      marginTop={48}
                      color={Colors.white}
                    />

                    {/* TODO : Replace the below icons with svgs using fontello icons */}
                    <View
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'center',
                      }}
                    >
                      <TouchableOpacity
                        onPress={onFacebookLogin}
                        style={loginStyles.facebookButton}
                      >
                        <Icon name='facebook' color={Colors.white} size={37} />
                      </TouchableOpacity>
                      {/* TODO: For future references for gmail login */}
                      {/* <TouchableOpacity
                        onPress={onFacebookLogin}
                        style={loginStyles.facebookButton}
                      >
                        <Icon name='google' color={Colors.white} size={37} />
                      </TouchableOpacity> */}
                    </View>

                    <NormalText
                      text={"Don't have an account ?"}
                      textAlign={'center'}
                      letterSpacing={0.35}
                      lineHeight={25}
                      color={Colors.white}
                    />
                    <Button
                      buttonText={'Create New Account'}
                      onPress={navigateToSignup}
                      textColor={Colors.button}
                      isLink={true}
                      decoration={true}
                    />
                  </View>
                </ScrollView>
              </View>
            );
          }}
        </Formik>
      </ImageBackground>
    </Async>
  );
}

export default Login;
