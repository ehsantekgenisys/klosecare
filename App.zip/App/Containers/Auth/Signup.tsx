import React, { useState, useContext } from 'react';
import {
  ScrollView,
  View,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  ImageBackground,
} from 'react-native';
import Async from 'Components/Common/Async';
import TopSecionIOS from 'Components/Common/TopSectionIOS';
import { Button } from 'Components/Common/Button';
import { Colors, Images } from 'Themes';
import { LoginManager, AccessToken } from 'react-native-fbsdk';
import CheckCircle from 'react-native-vector-icons/FontAwesome';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import Icon from 'Themes/Icon';
import { ISignupFormValues, FieldType } from 'Types';
import { Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import { InputField } from 'Components/Common/InputField';
import { showNotification } from 'Lib/Utils';
import { signupStyles, commonAuthStyles } from 'Containers/Auth/Styles';
import { NormalText } from 'Components/Common/NormalText';
import { useApi } from 'CustomHooks';
import Urls from 'Constants/Urls';
import { equals, not } from 'ramda';
import AsyncStorage from '@react-native-community/async-storage';
import { AppContext } from 'Contexts/AppContext';

const noop = () => {};

const SignupSchema = Yup.object().shape({
  firstName: Yup.string().required(' '),
  lastName: Yup.string().required(' '),
  email: Yup.string()
    .email(' ')
    .required(' '),
  password: Yup.string().required(' '),
  confirmPassword: Yup.string().required(' '),
});

interface IOnBoardingProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function Signup(props: IOnBoardingProps) {
  const [termsAccepted, toggleTermsAcceptance] = useState(false);
  const appCtx = useContext(AppContext);

  const [facebookSignupCaller, , facebookLoading] = useApi(
    props.navigation,
    true,
  );
  const [emailSignupCaller, , emailLoading] = useApi(props.navigation, true);

  /**
   * Navigates to login screen
   *
   * @method navigateToLogin
   *
   * @returns {void}
   */
  function navigateToLogin() {
    props.navigation.navigate('Login');
  }

  /**
   * Authenticates user through facebook
   *
   * @method onFacebookSignup
   *
   * @returns {void}
   */
  function onFacebookSignup() {
    /** Generates a token from LoginManager of facebook to be used as authentication */
    LoginManager.logInWithPermissions(['public_profile', 'email']).then(
      (result) => {
        try {
          if (result.isCancelled) {
            showNotification('Facebook Authorization Interrupted');
          } else {
            AccessToken.getCurrentAccessToken().then((data) => {
              facebookSignupCaller(
                'POST',
                Urls.auth.facebook,
                { access_token: data.accessToken.toString(), user_type: 2 },
                true,
              );
            });
          }
        } catch (error) {
          showNotification('Facebook Authorization Failed');
        }
      },
    );
  }

  /**
   * Creates a new account for new user
   *
   * @method createAccount
   *
   * @returns {void}
   */
  function createAccount(values: ISignupFormValues) {
    const userCredentials = {
      first_name: values.firstName,
      last_name: values.lastName,
      email: values.email,
      password: values.password,
      user_type: 2,
    };

    if (
      !values.password.match(
        /^(?=.*\d)(?=.*[!@#\$%\^\&*\)\(+=._-])(?=.*[a-z])(?=.*[A-Z]).{8,}$/,
      ) ||
      !values.confirmPassword.match(
        /^(?=.*\d)(?=.*[!@#\$%\^\&*\)\(+=._-])(?=.*[a-z])(?=.*[A-Z]).{8,}$/,
      )
    ) {
      return Alert.alert(
        'Password Rule Violation',
        'Password length must be atleast 8 characters including 1 capital letter, 1 lower case letter, 1 number and a special character',
      );
    }

    /** Notify the user about password mismatch */
    if (not(equals(values.password, values.confirmPassword))) {
      Alert.alert('Password Mismatch', 'Both Passwords should be the same');
      return;
    }

    // Registers new user and logs in the user directly
    emailSignupCaller('POST', Urls.auth.signup, userCredentials);

    AsyncStorage.setItem('lastLoggedEmail', values.email)
      .then(noop)
      .catch(noop);
    appCtx.dispatch({ type: 'SET_LAST_LOGGED_EMAIL', email: values.email });
    toggleTermsAcceptance(false);
  }

  /**
   * Takes user to onboarding flow
   *
   * @method navigateToOnboardingFlow
   *
   * @returns {void}
   */
  function navigateToOnboardingFlow() {
    props.navigation.navigate('OnBoarding', { fromAuth: true });
  }

  return (
    <Async displayChildren={facebookLoading || emailLoading}>
      <ImageBackground
        source={Images['app_background']}
        style={commonAuthStyles.bgStyle}
      >
        <TouchableOpacity
          onPress={navigateToOnboardingFlow}
          style={commonAuthStyles.questionIcon}
        >
          <Icon name={'question'} color={'white'} size={30} />
        </TouchableOpacity>
        <Formik
          initialValues={{
            firstName: '',
            lastName: '',
            email: '',
            password: '',
            confirmPassword: '',
          }}
          onSubmit={createAccount}
          validationSchema={SignupSchema}
        >
          {(formProps: FormikProps<ISignupFormValues>) => {
            return (
              <View style={signupStyles.formikContainer}>
                <TopSecionIOS
                  isIcon={false}
                  buttonText={'Create'}
                  headerText={'Create Account'}
                  iconName={'add'}
                  onPress={formProps.handleSubmit}
                  buttonDisabled={!formProps.isValid || !termsAccepted}
                />
                <KeyboardAvoidingView behavior='padding'>
                  <ScrollView contentInset={{ bottom: 150 }}>
                    <View style={signupStyles.signUpContainer}>
                      <InputField
                        placeholder={'First Name'}
                        fieldName='firstName'
                        fieldType={FieldType.text}
                        returnKeyType={'next'}
                        maxLength={30}
                        {...formProps}
                      />
                      <InputField
                        placeholder={'Last Name'}
                        fieldName='lastName'
                        fieldType={FieldType.text}
                        returnKeyType={'next'}
                        maxLength={130}
                        {...formProps}
                      />
                      <InputField
                        placeholder={'Email'}
                        fieldName='email'
                        fieldType={FieldType.text}
                        keyboardType={'email-address'}
                        returnKeyType={'next'}
                        {...formProps}
                      />
                      <InputField
                        placeholder={'Password'}
                        fieldName='password'
                        fieldType={FieldType.password}
                        returnKeyType={'next'}
                        {...formProps}
                      />
                      <InputField
                        placeholder={'Confirm Password'}
                        fieldName='confirmPassword'
                        fieldType={FieldType.password}
                        returnKeyType={'done'}
                        {...formProps}
                      />

                      {/* Terms and Conditions View */}
                      <TouchableOpacity
                        onPress={() => toggleTermsAcceptance(!termsAccepted)}
                        style={signupStyles.termsAndConditionsView}
                      >
                        <CheckCircle
                          style={signupStyles.checkCircleIcon}
                          size={25}
                          name={termsAccepted ? 'check-circle' : 'circle-o'}
                          color={termsAccepted ? Colors.white : Colors.white}
                        />
                        <NormalText
                          text={
                            'I agree to Klosecare Terms of Use and Privacy Policy'
                          }
                          flex={1}
                          lineHeight={25}
                          textAlign={'left'}
                          letterSpacing={0.35}
                          flexWrap={'wrap'}
                          color={Colors.white}
                        />
                      </TouchableOpacity>

                      <NormalText
                        text={'──── OR Create Account With ────'}
                        textAlign={'center'}
                        color={Colors.white}
                      />

                      <TouchableOpacity
                        onPress={onFacebookSignup}
                        style={signupStyles.facebookButton}
                      >
                        <Icon name='facebook' color={Colors.white} size={37} />
                      </TouchableOpacity>
                      <NormalText
                        text={'Already have an account ?'}
                        textAlign={'center'}
                        letterSpacing={0.35}
                        lineHeight={25}
                        color={Colors.white}
                      />
                      <Button
                        buttonText={'Login'}
                        onPress={navigateToLogin}
                        textColor={Colors.button}
                        decoration={true}
                      />
                    </View>
                  </ScrollView>
                </KeyboardAvoidingView>
              </View>
            );
          }}
        </Formik>
      </ImageBackground>
    </Async>
  );
}

export default Signup;
