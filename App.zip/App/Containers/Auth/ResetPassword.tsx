import React, { useState, useEffect } from 'react';
import { ScrollView, View, Alert } from 'react-native';
import Async from 'Components/Common/Async';
import TopSecionIOS from 'Components/Common/TopSectionIOS';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { FieldType, IResetPasswordFormValues } from 'Types';
import { Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import { InputField } from 'Components/Common/InputField';
import { loginStyles } from 'Containers/Auth/Styles';
import { useApi } from 'CustomHooks';
import Urls from 'Constants/Urls';
import { showNotification } from 'Lib/Utils';
import { equals, not } from 'ramda';

interface IResetPasswordProps {
  navigation: NavigationScreenProp<NavigationState>;
}

const ResetPasswordSchema = Yup.object().shape({
  password: Yup.string()
    .matches(
      /^(?=.*\d)(?=.*[!@#\$%\^\&*\)\(+=._-])(?=.*[a-z])(?=.*[A-Z]).{8,}$/,
      'Password length must be atleast 8 characters including 1 capital letter, 1 lower case letter, 1 number and a special character',
    )
    .required('Password is Required'),
  confirmPassword: Yup.string()
    .matches(
      /^(?=.*\d)(?=.*[!@#\$%\^\&*\)\(+=._-])(?=.*[a-z])(?=.*[A-Z]).{8,}$/,
      'Password length must be atleast 8 characters including 1 capital letter, 1 lower case letter, 1 number and a special character',
    )
    .required('Confirm Password is Required'),
});

function ResetPassword(props: IResetPasswordProps) {
  const [userId, setUserId] = useState(0);
  const [authKey, setAuthKey] = useState('');

  const [resetPassword, , isLoading, , resetSuccess] = useApi(
    props.navigation,
    false,
    'Login',
  );

  useEffect(() => {
    if (resetSuccess) {
      showNotification('Password Reset Successfully');
    }
  }, [resetSuccess]);

  useEffect(() => {
    const userId = props.navigation.getParam('userId');
    const authKey = props.navigation.getParam('authKey');
    setUserId(userId);
    setAuthKey(authKey);
  }, []);

  /**
   * Resets the users password
   *
   * @method updatePassword
   *
   * @param {IResetPasswordFormValues} values
   *
   * @returns {void}
   */
  function updatePassword(values: IResetPasswordFormValues) {
    /** Notify the user about password mismatch */
    if (not(equals(values.password, values.confirmPassword))) {
      Alert.alert('Password Mismatch', 'Both Passwords should be the same');
      return;
    }

    /** Make the password reset call */
    resetPassword(
      'PATCH',
      Urls.auth.resetPassword(userId),
      {
        password: values.password,
      },
      false,
      { Authorization: `token ${authKey}` },
    );
  }

  return (
    <Async displayChildren={isLoading}>
      <Formik
        initialValues={{
          password: '',
          confirmPassword: '',
        }}
        onSubmit={updatePassword}
        validationSchema={ResetPasswordSchema}
      >
        {(formProps: FormikProps<IResetPasswordFormValues>) => {
          return (
            <View style={loginStyles.formikContainer}>
              <TopSecionIOS
                isIcon={false}
                buttonText={'Reset'}
                headerText={'Reset Password'}
                onPress={formProps.handleSubmit}
                buttonDisabled={!formProps.isValid}
              />
              <ScrollView>
                <View style={loginStyles.loginContainer}>
                  <InputField
                    placeholder={'New Password'}
                    fieldName='password'
                    fieldType={FieldType.password}
                    returnKeyType={'next'}
                    {...formProps}
                  />
                  <InputField
                    placeholder={'Confirm Password'}
                    fieldName='confirmPassword'
                    fieldType={FieldType.password}
                    returnKeyType={'done'}
                    {...formProps}
                  />
                </View>
              </ScrollView>
            </View>
          );
        }}
      </Formik>
    </Async>
  );
}

export default ResetPassword;
