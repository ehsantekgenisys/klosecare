import React, { useEffect } from 'react';
import { ScrollView, View, TouchableOpacity, Text } from 'react-native';
import Async from 'Components/Common/Async';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { FieldType, IForgotPasswordFormValues } from 'Types';
import { Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import { InputField } from 'Components/Common/InputField';
import { forgotPasswordStyles } from 'Containers/Auth/Styles';
import { useApi } from 'CustomHooks';
import Urls from 'Constants/Urls';
import { showNotification } from 'Lib/Utils';
import { LargeText } from 'Components/Common/LargeText';
import { Fonts, Colors } from 'Themes';
import Icon from 'Themes/Icon';

const ForgotPasswordSchema = Yup.object().shape({
  email: Yup.string()
    .email()
    .required('Email is Required'),
});

interface IForgotPasswordProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function ForgotPassword(props: IForgotPasswordProps) {
  const [forgotPassword, , loading, , success] = useApi(
    props.navigation,
    false,
    'Login',
  );

  /**
   * Navigates to login while showing the notification when
   * forgot password api call is successful
   */
  useEffect(() => {
    if (success) {
      showNotification('Please check your email');
    }
  }, [success]);

  /**
   * Makes the forgot password api call
   *
   * @method submitForgotPasswordRequest
   *
   * @param {IForgotPasswordFormValues} values
   *
   * @returns {void}
   */
  function submitForgotPasswordRequest(values: IForgotPasswordFormValues) {
    forgotPassword('POST', Urls.auth.forgotPassword, {
      email: values.email,
    });
  }

  return (
    <Async displayChildren={loading}>
      <Formik
        initialValues={{
          email: '',
        }}
        onSubmit={submitForgotPasswordRequest}
        validationSchema={ForgotPasswordSchema}
      >
        {(formProps: FormikProps<IForgotPasswordFormValues>) => {
          return (
            <View style={forgotPasswordStyles.formikContainer}>
              <View style={forgotPasswordStyles.header}>
                <TouchableOpacity
                  onPress={() => props.navigation.goBack()}
                  style={forgotPasswordStyles.headerLeft}
                >
                  <Icon name='arrow-left' color={Colors.white} size={20} />
                  <LargeText
                    text={'Back'}
                    color={Colors.white}
                    fontFamily={Fonts.type.regular}
                    marginLeft={6}
                  />
                </TouchableOpacity>
                <Text style={forgotPasswordStyles.headerTitle}>
                  Forgot Password
                </Text>

                <TouchableOpacity
                  onPress={formProps.handleSubmit}
                  style={{ marginRight: 10 }}
                >
                  {/* If the user is editing info show done  */}
                  <LargeText
                    text={'Submit'}
                    fontFamily={Fonts.type.regular}
                    letterSpacing={0.37}
                    color={Colors.white}
                  />
                </TouchableOpacity>
              </View>
              <ScrollView>
                <View
                  style={[
                    forgotPasswordStyles.forgotPasswordContainer,
                    { paddingVertical: 20 },
                  ]}
                >
                  <InputField
                    placeholder={'Enter Your Email'}
                    fieldName='email'
                    fieldType={FieldType.text}
                    keyboardType={'email-address'}
                    returnKeyType={'done'}
                    {...formProps}
                  />
                </View>
              </ScrollView>
            </View>
          );
        }}
      </Formik>
    </Async>
  );
}

export default ForgotPassword;
