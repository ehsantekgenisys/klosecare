import React from 'react';
import { View, Text } from 'react-native';
import Icon from 'Themes/Icon';
import { Colors, Fonts } from 'Themes';
import TopSecionIOS from 'Components/Common/TopSectionIOS';

function ELearning(props: {}) {
  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <TopSecionIOS headerText={'E-Learing'} hideButton={true} />
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          paddingBottom: 100,
        }}
      >
        <Icon name='elearning' size={60} color={Colors.white} />

        <Text
          style={{
            marginTop: 20,
            color: Colors.white,
            fontFamily: Fonts.type.regular,
            letterSpacing: 0.35,
          }}
        >
          Page is under construction
        </Text>
      </View>
    </View>
  );
}

ELearning.navigationOptions = ({ navigation }) => ({
  header: null,
});

export default ELearning;
