export default {
  auth: {
    facebook: '/auth/v1/login/facebook/',
    login: '/auth/v1/login/',
    logout: '/auth/v1/logout/',
    signup: '/auth/v1/signup/',
    resetPassword: (userId: number) => `/auth/v1/pass-reset/confirm/${userId}`,
    forgotPassword: '/auth/v1/forgot-password/',
    changePassword: `/auth/v1/change-password/`,
  },

  reports: {
    uploadReport: '/api/v1/cgms/reports/file/',
    reuploadReport: (reportId: number) =>
      `/api/v1/cgms/reports/${reportId}/file/`,
    reportMeta: (reportId: number) => `/api/v1/cgms/reports/${reportId}/`,
    doctors: '/api/v1/doctors/',
    purposes: '/api/v1/cgms/reports/consultation-purpose/',
    reports: '/api/v1/cgms/reports/',
    deleteReport: (reportId: number) => `/api/v1/cgms/reports/${reportId}/`,
    payment: (reportId: number) => `/api/v1/cgms/reports/${reportId}/pay/`,
    dietList: '/api/v1/cgms/reports/diet/',
  },
};
