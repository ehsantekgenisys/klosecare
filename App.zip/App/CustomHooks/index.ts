import { useEffect, useState, useContext } from 'react';
import Api from 'Services/Api';
import Axios, { AxiosResponse, AxiosError } from 'axios';
import { NavigationScreenProp, NavigationState } from 'react-navigation';
import { showNotification } from 'Lib/Utils';
import { AppContext } from 'Contexts/AppContext';
import { ReportContext } from 'Containers/Reports/Context';
import AuthenticationManager from 'Lib/Keychain/AuthenticationManager';

/**
 * Calls the api for the given url once - Mocks ComponentDidMount
 *
 * @method useApiCallOnDidMount
 *
 * @param {string} url
 * @param {boolean} hideError
 *
 * @returns {void}
 */
export function useApiCallOnDidMount(
  url: string,
  optionalDeps?: any,
  hideError?: boolean,
) {
  const [state, setState] = useState<any>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [success, setSuccess] = useState(false);

  const appCtx = useContext(AppContext);

  useEffect(() => {
    if (appCtx.isConnected) {
      setLoading(true);
      setError(false);
      setSuccess(false);
      Api({
        method: 'GET',
        url,
      })
        .then((reponse: AxiosResponse) => {
          setState(reponse.data);
          setSuccess(true);
          setError(false);
          setLoading(false);
        })
        .catch((error: AxiosError) => {
          setLoading(false);
          setError(true);
          setSuccess(false);
          if (hideError) {
            return;
          }
          if (
            error.response &&
            error.response.data &&
            error.response.data.errors
          ) {
            showNotification(
              `Error: ${error.response.data.errors[0].split(':')[1]}`,
            );
          } else {
            showNotification(`Error: ${error.message}`);
          }
        });
    }
    /** Make the api call as soon as the internet comes back up */
  }, [appCtx.isConnected, optionalDeps ? optionalDeps : null]);

  return [state, loading, error, success];
}

/**
 * Sets the nav params once the component mounts - Mocks ComponentDidMount
 *
 * @method useSetNavParamsDidMount
 *
 * @param {{[key: string]: string}} params
 * @param {navigation: NavigationScreenProp<NavigationState>} navigation
 *
 * @returns {void}
 */
export function useSetNavParamsDidMount(
  params: { [key: string]: any },
  navigation: NavigationScreenProp<NavigationState>,
  deps?: any[],
) {
  useEffect(
    () => {
      navigation.setParams(params);
    },
    deps ? [...deps] : [],
  );
}

/**
 * Use this hook to show loader in your app
 *
 * @method useLoader
 *
 * @param loading
 *
 * @returns [state, setState]
 */
export function useLoader(loading: boolean) {
  const [state, setState] = useState<any>(loading);

  return [state, setState];
}

/**
 * This hook returns a apiCaller to call the api, response of the api call.
 *
 * @method useApi
 *
 * @param {NavigationScreenProp<NavigationState>} navigation - To navigate to any desired screen
 * @param {boolean} isAuth - To determine if the api call is auth (login, signup)
 * @param {string} navigateTo - Determines the screen to navigate to
 *
 * @returns {[apiCaller, response:AxiosResponse,isLoading:boolean]}
 */
export function useApi(
  navigation?: NavigationScreenProp<NavigationState>,
  isAuth?: boolean,
  navigateTo?: string,
  source?: any,
) {
  const appCtx = useContext(AppContext);
  const reportCtx = useContext(ReportContext);

  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<any>([]);
  const [error, setError] = useState(false);
  const [success, setSuccess] = useState(false);
  /** To keep track of the upload progress */
  const [uploadProgress, setProgress] = useState(0);

  const apiCaller = <T>(
    method,
    url: string,
    payload?: T,
    hideError?: boolean,
    headers?: any,
    returnProgress?: boolean,
    successNotification?: string,
  ) => {
    setLoading(true);
    setError(false);
    setSuccess(false);

    Api({
      method,
      url,
      data: payload,
      /** For upload report Api call */
      onUploadProgress: returnProgress
        ? (progressEvent) => {
            const percentCompleted = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total,
            );
            setProgress(percentCompleted);
          }
        : () => {},
      headers: Boolean(headers) ? headers : undefined,
      cancelToken: Boolean(source) ? source.token : null,
    })
      .then((result: AxiosResponse) => {
        setError(false);
        setResponse(result.data);
        setSuccess(true);

        /** If Api call is for upload report then set file meta data in report context */
        if (Boolean(returnProgress)) {
          reportCtx.dispatch({ type: 'UPLOAD_REPORT', upload: false });
          appCtx.dispatch({
            type: 'SHOW_DIALOG',
            show: false,
            content: 'report',
          });
          reportCtx.dispatch({
            type: 'SET_FILE_META_DATA',
            fileMeta: result.data,
          });
        }

        /**  If api call is related to auth then store the key in keychain manager and navigate to main app */
        if (isAuth) {
          const authManager = new AuthenticationManager();
          authManager
            .set(result.data.key)
            .then(() => {
              navigation.navigate('MainApp');
              setLoading(false);
            })
            .catch(() => {
              setLoading(false);
              showNotification('Unable to login something went wrong');
            });
          return;
        }

        if (Boolean(successNotification)) {
          showNotification(successNotification);
        }

        /** If user wants to navigate to a specific screen then navigate to that screen */
        if (Boolean(navigateTo)) {
          navigation.navigate(navigateTo);
          setLoading(false);
          return;
        }
        setLoading(false);
      })
      .catch((error: AxiosError) => {
        if (Axios.isCancel(error)) {
          showNotification('Report discarded');
        } else {
          // handle error
          setSuccess(false);
          setLoading(false);
          /** In case of error handling in calling component */
          setError(true);
          if (!hideError) {
            if (
              error.response &&
              error.response.data &&
              error.response.data.errors
            ) {
              showNotification(`Error: ${error.response.data.errors[0]}`);
            } else {
              showNotification(`Error: ${error.message}`);
            }
          }
        }
      });
  };
  return [apiCaller, response, loading, error, success, uploadProgress];
}
