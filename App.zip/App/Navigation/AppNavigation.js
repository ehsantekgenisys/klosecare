import React from 'react';
import { TouchableOpacity, Text } from 'react-native';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createStackNavigator, Header } from 'react-navigation-stack';
/** General */
import TabBar from 'Components/General/TabBar';
import OnBoarding from 'Containers/General/OnBoarding';
import Dashboard from 'Containers/Home/Dashboard';

/** Auth  */
import Login from 'Containers/Auth/Login';
import Signup from 'Containers/Auth/Signup';
import ForgotPassword from 'Containers/Auth/ForgotPassword';
import ResetPassword from 'Containers/Auth/ResetPassword';

/** Reports */
import Reports from 'Containers/Reports/Reports';
import DoctorsList from 'Containers/Reports/DoctorsList';
import HealthSummary from 'Containers/Reports/HealthSummary';
import Medication from 'Containers/Reports/HealthSummary/Medication';
import Exercise from 'Containers/Reports/HealthSummary/Exercise';
import Diet from 'Containers/Reports/HealthSummary/Diet';
import UploadedReportView from 'Containers/Reports/UploadedReportView';
import ReportPurpose from 'Containers/Reports/ReportPurpose';
import ReviewAndPay from 'Containers/Reports/ReviewAndPay';
import ReportSummary from 'Containers/Reports/ReportSummary';
import PdfView from 'Containers/Reports/PdfView';

/** Appointments */
import Appointments from 'Containers/Appointments/Appointments';

/** E-Learning */
import ELearning from 'Containers/ELearning/ELearning';

/** More (Settings) */
import More from 'Containers/More';
import Settings from 'Containers/More/Settings';
import Payments from 'Containers/More/Settings/Payments';
import ChangePassword from 'Containers/More/Settings/ChangePassword';

/** Custom transitions config */
import NavigationTransition from 'Navigation/NavigationTransitions';
import { LargeText } from 'Components/Common/LargeText';
import { Colors, Fonts } from 'Themes';
import Icon from 'Themes/Icon';
import styles from 'Navigation/Styles';
import { last } from 'ramda';

/** Default header config for stack navigation */
const headerDefaultConfig = {
  header: (props) => <Header {...props} />,
  headerStyle: {
    backgroundColor: Colors.headerPrimary,
    elevation: 0,
    borderBottomWidth: 0.3,
    borderBottomColor: Colors.headerBorder,
    height: 44,
  },
  headerForceInset: { top: 'never', bottom: 'never' },
  headerTitleContainerStyle: {
    flex: 1,
    justifyContent: 'center',
    alignSelf: 'center',
    left: 0,
    right: 0,
    position: 'relative',
  },
  headerTitleStyle: {
    fontWeight: undefined, // React Navigation bug https://github.com/react-navigation/rieact-navigation/issues/542
    color: Colors.white,
    textAlign: 'center',
    flex: 1,
    alignSelf: 'center',
    fontFamily: Fonts.type.medium,
    fontSize: 17,
    lineHeight: 22,
  },
  headerLeft: (navigation) => {
    /** If it's the first screen of the stack, don't show the back button */
    if (navigation.scene.index === 0) return null;
    return (
      <TouchableOpacity
        onPress={navigation.onPress}
        style={styles.backButtonContainer}
      >
        <Icon name='arrow-left' color={Colors.white} size={20} />
        <LargeText
          text={'Back'}
          color={Colors.white}
          fontFamily={Fonts.type.regular}
          marginLeft={6}
        />
      </TouchableOpacity>
    );
  },
  headerTintColor: Colors.transparent,
  gesturesEnabled: false,
};

/** Navigation stack for more tab */
const MoreNav = createStackNavigator(
  {
    More: { screen: More },
    Settings: { screen: Settings },
    Payments: { screen: Payments },
    ChangePassword: { screen: ChangePassword },
  },
  {
    initialRouteName: 'More',
    defaultNavigationOptions: { ...headerDefaultConfig },
    transitionConfig: NavigationTransition,
  },
);

/** Navigation stack for E-Learning tab */
const ELearningNav = createStackNavigator(
  {
    ELearning: { screen: ELearning },
  },
  {
    initialRouteName: 'ELearning',
    defaultNavigationOptions: { ...headerDefaultConfig },
    transitionConfig: NavigationTransition,
  },
);

/** Navigation stack for Appointments tab */
const AppointmentNav = createStackNavigator(
  {
    Appointments: { screen: Appointments },
  },
  {
    initialRouteName: 'Appointments',
    defaultNavigationOptions: { ...headerDefaultConfig },
    transitionConfig: NavigationTransition,
  },
);

/** Navigation stack for Reports tab */
const CGMSNav = createStackNavigator(
  {
    Reports: { screen: Reports },
    UploadedReport: { screen: UploadedReportView },
    DoctorsList: { screen: DoctorsList },
    HealthSummary: { screen: HealthSummary },
    Medication: { screen: Medication },
    Diet: { screen: Diet },
    Exercise: { screen: Exercise },
    ReportPurpose: { screen: ReportPurpose },
    ReviewAndPay: { screen: ReviewAndPay },
    ReportSummary: { screen: ReportSummary },
    PdfView: { screen: PdfView },
  },
  {
    initialRouteName: 'Reports',
    defaultNavigationOptions: { ...headerDefaultConfig },
    transitionConfig: NavigationTransition,
  },
);

/** Navigation stack for home tab */
const HomeNav = createStackNavigator(
  {
    Dashboard: { screen: Dashboard },
  },
  {
    initialRouteName: 'Dashboard',
    defaultNavigationOptions: { ...headerDefaultConfig },
    transitionConfig: NavigationTransition,
  },
);

/** Tab Navigation Stack - Each tab will have it's own navigation stack */
const MainApp = createBottomTabNavigator(
  {
    HomeNav: {
      screen: HomeNav,
      params: {
        label: 'Dashboard',
        iconName: 'dashboard',
      },
    },
    CGMSNav: {
      screen: CGMSNav,
      params: {
        label: 'Reports',
        iconName: 'reports',
      },
      /** Hide tab bar if route is PdfView */
      navigationOptions: ({ navigation }) => {
        const lastRoute = last(navigation.state.routes);
        const tabBarVisible = lastRoute.routeName !== 'PdfView';
        return {
          tabBarVisible,
        };
      },
    },
    AppointmentNav: {
      screen: AppointmentNav,
      params: {
        label: 'Appointments',
        iconName: 'appointments',
      },
    },
    ELearningNav: {
      screen: ELearningNav,
      params: {
        label: 'E-Learning',
        iconName: 'elearning',
      },
    },
    MoreNav: {
      screen: MoreNav,
      params: {
        label: 'More',
        iconName: 'dots',
      },
    },
  },
  {
    initialRouteName: 'CGMSNav',
    lazy: true,
    animationEnabled: false,
    swipeEnabled: false,
    tabBarComponent: ({ navigation }) => <TabBar navigation={navigation} />,
  },
);

/** AuthNav contains the authentication screens */
const AuthNav = createStackNavigator(
  {
    Signup: { screen: Signup },
    Login: { screen: Login },
    ForgotPassword: { screen: ForgotPassword },
    ResetPassword: { screen: ResetPassword },
  },
  {
    initialRouteName: 'Login',
    /** determines if the stack has header or not*/
    headerMode: 'none',
    transitionConfig: NavigationTransition,
  },
);

/** IntronNav contains the onboarding screens - Only to be displayed first time users installs the app */
const IntroNav = createStackNavigator(
  {
    OnBoarding: { screen: OnBoarding },
  },
  {
    initialRouteName: 'OnBoarding',
    /** determines if the stack has header or not*/
    headerMode: 'none',
  },
);

/**
 * Three main stacks of the app.
 *
 * IntroNav - Contains the onboarding screen to be shown the first time the user installs app
 * AuthNav - Contains authentication screens
 * MainApp - Main screens of the app
 */
const RootStack = createSwitchNavigator(
  {
    IntroNav: { screen: IntroNav },
    AuthNav: { screen: AuthNav },
    MainApp: { screen: MainApp },
  },
  {
    initialRouteName: 'IntroNav',
  },
);

export default createAppContainer(RootStack);
