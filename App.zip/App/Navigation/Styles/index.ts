import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  backButtonContainer: {
    flexDirection: 'row',
    marginLeft: 9,
    paddingRight: 25,
  },
});
