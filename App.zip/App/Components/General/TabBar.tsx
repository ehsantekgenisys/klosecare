import React, { useContext } from 'react';
import { View, StyleSheet, TouchableWithoutFeedback, Text } from 'react-native';
import DeviceInfo from 'react-native-device-info';
import { Colors } from 'Themes';
import Icon from 'Themes/Icon';
import { NavigationState, NavigationScreenProp } from 'react-navigation';
import { ReportContext } from 'Containers/Reports/Context';

const styles = StyleSheet.create({
  tabView: {
    height: DeviceInfo.hasNotchSync() ? 66 : 56,
    flexDirection: 'row',
    backgroundColor: Colors.tabViewBg,
    borderWidth: 0.3,
    paddingTop: 7,
    borderColor: Colors.tabViewBorder,
  },
  label: {
    fontSize: 10,
    letterSpacing: 0.16,
    color: Colors.text,
    alignSelf: 'center',
    marginTop: 7,
  },
});

interface ITabBarProps {
  navigation: NavigationScreenProp<NavigationState>;
}

function TabBar(props: ITabBarProps) {
  const { navigation } = props;
  const { routes, index } = navigation.state;
  const reportCtx = useContext(ReportContext);

  return (
    <View style={styles.tabView}>
      {routes.map((route, i) => (
        <TabItem
          navigation={navigation}
          key={route.routeName}
          {...route}
          isActive={index === i}
          isUploading={reportCtx.uploadInfo.isUploading}
        />
      ))}
    </View>
  );
}

function TabItem(props) {
  const { isActive, params, isUploading } = props;

  /**
   * Navigates to the selected tab
   *
   * @method handlePress
   *
   * @returns {void}
   */
  function handlePress() {
    props.navigation.navigate(props.routeName);
  }

  return (
    <TouchableWithoutFeedback onPress={handlePress} disabled={isUploading}>
      <View style={{ flex: 1, alignItems: 'center' }}>
        <Icon
          name={params.iconName}
          size={16}
          color={isActive ? Colors.activeBlue : Colors.text}
        />
        <Text
          style={[
            styles.label,
            { color: isActive ? Colors.activeBlue : Colors.text },
          ]}
        >
          {params.label}
        </Text>
      </View>
    </TouchableWithoutFeedback>
  );
}

export default TabBar;
