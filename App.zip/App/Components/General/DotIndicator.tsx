import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Colors } from 'Themes';

const styles = StyleSheet.create({
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginHorizontal: 3,
  },
});

interface IDotIndicatorProps {
  selected: boolean;
}

export function Dot(props: IDotIndicatorProps) {
  const backgroundColor = props.selected
    ? Colors.activeDot
    : Colors.inactiveDot;
  return (
    <View
      style={{
        ...styles.dot,
        backgroundColor,
      }}
    />
  );
}
