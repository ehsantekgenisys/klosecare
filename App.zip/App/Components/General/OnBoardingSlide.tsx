import React from 'react';
import { View, Text, StyleSheet, ImageBackground } from 'react-native';
import { SCREEN_WIDTH, SCREEN_HEIGHT } from 'Constants';
import { Colors, Fonts, Images } from 'Themes';
import { Button } from 'Components/Common/Button';
import { IOnboardingSlideData } from 'Types';

const styles = StyleSheet.create({
  slideContainer: {
    height: SCREEN_HEIGHT,
    width: SCREEN_WIDTH,
    backgroundColor: Colors.transparent,
    paddingHorizontal: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageBg: {
    width: '100%',
    height: '100%',
  },
  slideTitle: {
    color: Colors.heading,
    fontFamily: Fonts.type.bold,
    marginTop: 250,
    fontSize: Fonts.size.heading,
    marginBottom: 35,
    letterSpacing: 0.56,
  },
  slideText: {
    color: Colors.text,
    fontSize: Fonts.size.regular,
    textAlign: 'center',
    lineHeight: 25,
    marginBottom: 30,
  },
});

interface IOnboardingSlideProps {
  item: IOnboardingSlideData;
  skipOnboarding: () => void;
}

const OnBoardingSlide = (props: IOnboardingSlideProps) => {
  /**
   * Navigates to login screen
   *
   * @method onPressSkipOrGetStarted
   *
   * @returns {void}
   */
  function onPressSkipOrGetStarted() {
    props.skipOnboarding();
  }

  return (
    <ImageBackground
      source={Images[props.item.imageSrc]}
      style={styles.imageBg}
    >
      <View style={styles.slideContainer}>
        <Text style={styles.slideTitle}>{props.item.title}</Text>
        <Text style={styles.slideText}>{props.item.text}</Text>
        <Button
          buttonText={props.item.buttonText}
          onPress={onPressSkipOrGetStarted}
          textColor={Colors.darkSkyBlue}
          isLink={true}
        />
      </View>
    </ImageBackground>
  );
};

export default OnBoardingSlide;
