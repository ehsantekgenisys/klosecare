import React, { Component } from 'react';
import { Text, ImageBackground, View } from 'react-native';
import { Images, Colors, Fonts } from 'Themes';
import TopSecionIOS from 'Components/Common/TopSectionIOS';
import Icon from 'Themes/Icon';
import { Button } from 'Components/Common/Button';
import RNRestart from 'react-native-restart';

class ErrorBoundary extends Component {
  state = {
    hasError: false,
  };

  componentDidCatch(error, errorInfo) {
    // You can also log the error to an error reporting service
    // TODO:   logErrorToMyService(error, errorInfo);
    // console.tron.warn(error);
    this.setState({ hasError: true });
  }

  /**
   * Restarts JS bundle of app
   *
   * @method restartApp
   *
   * @returns {void}
   */
  restartApp = () => {
    RNRestart.Restart();
  };

  render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return (
        <View style={{ flex: 1, backgroundColor: Colors.background }}>
          <ImageBackground
            source={Images.app_background}
            style={{ width: '100%', height: '100%' }}
          >
            <TopSecionIOS headerText={'App not responding'} hideButton={true} />
            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
                paddingBottom: 100,
              }}
            >
              <Icon name='appointments' size={60} color={Colors.white} />

              <Text
                style={{
                  fontSize: 15,
                  width: '70%',
                  textAlign: 'center',
                  lineHeight: 20,
                  marginTop: 20,
                  color: Colors.white,
                  fontFamily: Fonts.type.regular,
                  letterSpacing: 0.35,
                }}
              >
                Looks like something went wrong, please try again
              </Text>
              <Button
                isLink={true}
                textColor={Colors.white}
                buttonText={'Reload'}
                onPress={this.restartApp}
                decoration={true}
              />
            </View>
          </ImageBackground>
        </View>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
