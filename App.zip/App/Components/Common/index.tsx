import React from 'react';
import { View } from 'react-native';
import { SCREEN_WIDTH } from 'Constants';

export const Screen = (props) => (
  <View
    style={{
      height: SCREEN_WIDTH,
      width: SCREEN_WIDTH,
      justifyContent: 'center',
      alignItems: 'center',
    }}
  >
    {props.children}
  </View>
);
