import React from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { Button } from 'Components/Common/Button';
import { Colors, Fonts } from 'Themes';
import Icon from 'Themes/Icon';
import { TouchableOpacity } from 'react-native-gesture-handler';

const styles = StyleSheet.create({
  container: {
    height: 100,
    backgroundColor: Colors.headerPrimary,
    marginBottom: 25,
    justifyContent: 'space-between',
    alignSelf: 'stretch',
    paddingVertical: 10,
  },
  button: {
    paddingHorizontal: 10,
    height: 40,
    alignSelf: 'flex-end',
  },
  icon: {
    paddingRight: 15,
    paddingLeft: 30,
    paddingBottom: 15,
  },
  headerText: {
    fontSize: 34,
    paddingHorizontal: 10,
    fontFamily: Fonts.type.bold,
    color: Colors.white,
  },
});

interface ITopSecionIOSProps {
  onPress?: () => void;
  headerText: string;
  isIcon?: boolean;
  buttonText?: string;
  iconName?: string;
  hideButton?: boolean;
  buttonDisabled?: boolean;
  containerStyle?: { [key: string]: string | number };
}

function TopSecionIOS(props: ITopSecionIOSProps) {
  return (
    <View style={[styles.container, props.containerStyle]}>
      {props.hideButton ? (
        <View style={styles.button} />
      ) : (
        <View
          style={[styles.button, { paddingHorizontal: props.isIcon ? 0 : 10 }]}
        >
          {props.isIcon ? (
            <TouchableOpacity
              onPress={props.onPress}
              style={[styles.icon, { opacity: props.buttonDisabled ? 0.5 : 1 }]}
              disabled={props.buttonDisabled}
            >
              <Icon color={Colors.white} name={props.iconName} size={22} />
            </TouchableOpacity>
          ) : (
            <Button
              buttonText={props.buttonText}
              textColor={Colors.white}
              onPress={props.onPress}
              isLink={true}
              disabled={props.buttonDisabled}
            />
          )}
        </View>
      )}

      <Text style={styles.headerText}>{props.headerText}</Text>
    </View>
  );
}

export default TopSecionIOS;
