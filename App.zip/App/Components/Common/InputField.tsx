import React, { useState } from 'react';
import {
  TextInput,
  StyleSheet,
  View,
  TouchableOpacity,
  KeyboardType,
  ReturnKeyType,
} from 'react-native';
import { Colors, Fonts } from 'Themes';
import { FormikProps } from 'formik';
import {
  FieldType,
  ISignupFormValues,
  ILoginFormValues,
  IResetPasswordFormValues,
  IForgotPasswordFormValues,
  IChangePasswordFormValues,
} from 'Types';
import Icon from 'Themes/Icon';

interface ITextInputProps
  extends FormikProps<
    | ISignupFormValues
    | ILoginFormValues
    | IResetPasswordFormValues
    | IForgotPasswordFormValues
    | IChangePasswordFormValues
  > {
  placeholder: string;
  /** determines if the text in the field is visible or not */
  fieldName: string;
  /** determines the field type of the input field i.e. text or password */
  fieldType: FieldType;
  keyboardType?: KeyboardType;
  returnKeyType: ReturnKeyType;
  maxLength?: number;
}

const styles = StyleSheet.create({
  inputContainer: {
    borderWidth: 1.5,
    borderColor: Colors.border,
    flexDirection: 'row',
    height: 50,
    borderRadius: 5,
    marginVertical: 8,
    alignItems: 'center',
    backgroundColor: Colors.white,
  },
  input: {
    flex: 1,
    paddingVertical: 5,
    paddingHorizontal: 8,
    fontFamily: Fonts.type.regular,
    letterSpacing: 0.35,
    color: Colors.black,
  },
  errorText: {
    color: Colors.white,
    height: 17,
    fontFamily: Fonts.type.light,
  },
  tooltipText: {
    color: Colors.white,
    fontFamily: Fonts.type.regular,
  },
  inputIcon: {
    height: '100%',
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
});

export function InputField(props: ITextInputProps) {
  /** Current state of the input field */
  const [active, setActive] = useState(false);
  /** Visibility status of the input text - Initialized based on the field type of input */
  const [isSecured, secureText] = useState(
    props.fieldType === FieldType.password,
  );

  const {
    handleChange,
    handleBlur,
    values,
    fieldName,
    setFieldTouched,
    placeholder,
    errors,
    touched,
    fieldType,
    keyboardType,
    returnKeyType,
    maxLength,
  } = props;

  /**
   * Sets touched value of the field to true
   * Sets the active status of the field to true
   *
   * @method handleFieldFocus
   *
   * @returns {void}
   */
  function handleFieldFocus() {
    setFieldTouched(fieldName, true);
    setActive(true);
  }

  /**
   * Calls handleBlur of the formik with the field name
   * Sets the active status of the field to false
   *
   * @method handleFieldBlur
   *
   * @returns {void}
   */
  function handleFieldBlur() {
    handleBlur(fieldName);
    setActive(false);
  }

  /**
   * Toggles the visibility  of text in the input field
   *
   * @method toggleTextVisibility
   *
   * @returns {void}
   */
  function toggleTextVisibility() {
    secureText(!isSecured);
  }

  return (
    <View style={{ borderColor: Colors.fieldErrorBorder, borderWidth: 0 }}>
      <View
        style={[
          styles.inputContainer,
          {
            borderColor: active
              ? Colors.fieldActiveBorder
              : errors[fieldName] && touched[fieldName]
              ? Colors.fieldErrorBorder
              : Colors.border,
          },
        ]}
      >
        <TextInput
          style={styles.input}
          placeholderTextColor={Colors.placeholder}
          placeholder={placeholder}
          onChangeText={handleChange(fieldName)}
          onFocus={handleFieldFocus}
          onBlur={handleFieldBlur}
          value={values[fieldName]}
          secureTextEntry={isSecured}
          keyboardType={keyboardType ? keyboardType : 'default'}
          returnKeyType={returnKeyType}
          maxLength={maxLength ? maxLength : 200}
        />
        {/* If field type is password then show an icon to show or hide the text inside the input field */}
        {fieldType === FieldType.password ? (
          <TouchableOpacity
            onPress={toggleTextVisibility}
            style={styles.inputIcon}
          >
            <Icon
              name={isSecured ? 'eye-closed' : 'eye-open'}
              size={20}
              color={Colors.inputIconColor}
            />
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}
