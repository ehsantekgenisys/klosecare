import React, { useContext } from 'react';
import { View, StyleSheet, ImageBackground } from 'react-native';
import { Images, Colors } from 'Themes';
import Icon from 'Themes/Icon';
import { NormalText } from 'Components/Common/NormalText';
import { AppContext } from 'Contexts/AppContext';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  childrenContainer: {
    flex: 1,
  },
  bgImage: {
    width: '100%',
    height: '100%',
  },
});

interface IConnectivityProps {
  displayChildrenContainer?: {};
  children: any;
}

function Connectivity(props: IConnectivityProps) {
  const { displayChildrenContainer } = props;
  /** App Context */
  const appCtx = useContext(AppContext);

  /** If internet connectivity is available then show the children */
  if (appCtx.isConnected) {
    return (
      <View
        style={
          displayChildrenContainer
            ? displayChildrenContainer
            : styles.childrenContainer
        }
      >
        {props.children}
      </View>
    );
  }

  return (
    <ImageBackground source={Images.app_background} style={styles.bgImage}>
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Icon name='wifi' size={60} color={Colors.white} />

        <NormalText
          text={'No internet connection'}
          color={Colors.white}
          marginTop={20}
        />
      </View>
    </ImageBackground>
  );
}

export default Connectivity;
