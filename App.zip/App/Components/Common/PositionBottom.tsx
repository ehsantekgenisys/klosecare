import React from 'react';
import { StyleSheet, View } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-end',
    marginBottom: 35,
  },
});

export function PositionBottom(component) {
  return <View style={styles.container}>{component}</View>;
}
