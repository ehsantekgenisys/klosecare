import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Colors, Fonts } from 'Themes';

const styles = StyleSheet.create({
  container: {
    width: 54,
    height: 54,
    borderWidth: 6,
    borderRadius: 27,
    borderColor: Colors.lightGray,
    backgroundColor: Colors.transparent,
    justifyContent: 'center',
    alignItems: 'center',
  },
  firstProgressLayer: {
    width: 54,
    height: 54,
    borderWidth: 6,
    borderRadius: 27,
    position: 'absolute',
    borderLeftColor: 'transparent',
    borderBottomColor: 'transparent',
    borderRightColor: '#3498db',
    borderTopColor: '#3498db',
    transform: [{ rotateZ: '-135deg' }],
  },
  secondProgressLayer: {
    width: 54,
    height: 54,
    position: 'absolute',
    borderWidth: 6,
    borderRadius: 27,
    borderLeftColor: 'transparent',
    borderBottomColor: 'transparent',
    borderRightColor: '#3498db',
    borderTopColor: '#3498db',
    transform: [{ rotateZ: '45deg' }],
  },
  offsetLayer: {
    width: 54,
    height: 54,
    position: 'absolute',
    borderWidth: 6,
    borderRadius: 27,
    borderLeftColor: 'transparent',
    borderBottomColor: 'transparent',
    borderRightColor: 'grey',
    borderTopColor: 'grey',
    transform: [{ rotateZ: '-135deg' }],
  },
  text: {
    position: 'absolute',
    fontSize: 14,
    fontFamily: Fonts.type.bold,
    color: Colors.placeholder,
    lineHeight: 25,
    letterSpacing: 0.31,
  },
});

interface ICircularProgressProps {
  uploadProgress: number;
}

function CircularProgress(props: ICircularProgressProps) {
  function propStyle(percent, base_degrees) {
    const rotateBy = base_degrees + percent * 3.6;
    return {
      transform: [{ rotateZ: `${rotateBy}deg` }],
    };
  }

  let firstProgressLayerStyle;
  if (props.uploadProgress > 50) {
    firstProgressLayerStyle = propStyle(50, -135);
  } else {
    firstProgressLayerStyle = propStyle(props.uploadProgress, -135);
  }

  function renderThirdLayer(percent) {
    if (percent > 50) {
      /**
       * Third layer circle default is 45 degrees, so by default it occupies the right half semicircle.
       * Since first 50 percent is already taken care  by second layer circle, hence we subtract it
       * before passing to the propStyle function
       */
      return (
        <View
          style={[styles.secondProgressLayer, propStyle(percent - 50, 45)]}
        />
      );
    } else {
      return <View style={styles.offsetLayer} />;
    }
  }

  return (
    <View style={styles.container}>
      <View style={[styles.firstProgressLayer, firstProgressLayerStyle]} />
      {renderThirdLayer(props.uploadProgress)}
      <Text style={styles.text}>{`${props.uploadProgress}%`}</Text>
    </View>
  );
}

export default CircularProgress;
