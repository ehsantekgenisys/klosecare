import React, { useContext, useState, useEffect } from 'react';
import { Animated, Keyboard } from 'react-native';
import { SCREEN_HEIGHT } from 'Constants';
import { AppContext } from 'Contexts/AppContext';
import { dialogStyles } from 'Components/Common/AppDialog/DialogStyles';
import ReportUploadContent from 'Components/Common/AppDialog/ReportUploadContent';

const heightMap = new Map([
  ['report', SCREEN_HEIGHT * 0.25],
  ['medication', SCREEN_HEIGHT * 0.9],
  ['exercise', SCREEN_HEIGHT * 0.35],
  ['calories', SCREEN_HEIGHT * 0.55],
]);

function Dialog() {
  const appCtx = useContext(AppContext);

  const [translateY] = useState(new Animated.Value(SCREEN_HEIGHT / 4));
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  const [keyboardIsActive, setKeyboardActive] = useState(false);

  /** Adds event listners for keyboard - Gets keyboard height */
  useEffect(() => {
    function keyboardDidShow(e) {
      setKeyboardHeight(e.endCoordinates.height);
      setKeyboardActive(true);
    }

    function keyboardDidHide() {
      setKeyboardActive(false);
    }

    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      keyboardDidShow,
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      keyboardDidHide,
    );
    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  /**
   * Animates the dialog box up or down depending upon the visibility of the dialog box
   */
  useEffect(() => {
    if (appCtx.dialog.show) {
      Animated.timing(translateY, {
        toValue: 0 - Number(keyboardIsActive ? keyboardHeight : 0),
        duration: 300,
        useNativeDriver: true,
      }).start();
    } else {
      Animated.timing(translateY, {
        toValue: heightMap.get(appCtx.dialog.content),
        duration: 200,
        useNativeDriver: true,
      }).start();
    }
  }, [appCtx.dialog.show, keyboardHeight, keyboardIsActive]);

  /**
   * Dismisses the dialog box
   *
   * @method dismissDialog
   *
   * @returns {void}
   */
  function dismissDialog() {
    appCtx.dispatch({
      type: 'SHOW_DIALOG',
      show: false,
      content: appCtx.dialog.content,
    });
    Keyboard.dismiss();
  }

  return (
    <Animated.View
      style={[
        dialogStyles.dialogContainer,
        {
          transform: [{ translateY }],
          height: heightMap.get(appCtx.dialog.content),
        },
      ]}
    >
      {appCtx.dialog.content === 'report' ? (
        <ReportUploadContent dismissDialog={dismissDialog} />
      ) : null}
    </Animated.View>
  );
}

export default Dialog;
