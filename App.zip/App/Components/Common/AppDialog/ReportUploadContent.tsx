import React, { Fragment, useContext } from 'react';
import { TouchableOpacity, Text, View } from 'react-native';
import Icon from 'Themes/Icon';
import { dialogStyles } from 'Components/Common/AppDialog/DialogStyles';
import { Colors } from 'Themes';
import { AppContext } from 'Contexts/AppContext';
import { ReportContext } from 'Containers/Reports/Context';

interface IReportUploadContent {
  dismissDialog: () => void;
}

export default function ReportUploadContent(props: IReportUploadContent) {
  const appCtx = useContext(AppContext);
  const reportCtx = useContext(ReportContext);

  return (
    <Fragment>
      <TouchableOpacity
        onPress={props.dismissDialog}
        style={dialogStyles.closeDialogIcon}
      >
        <Icon name='remove' color={'rgba(255,255,255,0.5)'} size={25} />
      </TouchableOpacity>
      <Text style={dialogStyles.dialogHeading}>Upload Report</Text>
      <View style={dialogStyles.dialogContentContainer}>
        <View>
          <TouchableOpacity
            style={[dialogStyles.dialogButtonContainer, { opacity: 0.5 }]}
            disabled={true}
          >
            <Icon name='device' color={Colors.white} size={20} />
          </TouchableOpacity>
          <Text style={dialogStyles.dialogButtonText}>Latest From Device</Text>
        </View>
        <View>
          <TouchableOpacity
            onPress={() => {
              reportCtx.dispatch({ type: 'UPLOAD_REPORT', upload: true });
              appCtx.dispatch({
                type: 'SHOW_DIALOG',
                show: false,
                content: 'report',
              });
            }}
            style={dialogStyles.dialogButtonContainer}
          >
            <Icon name='upload' color={Colors.white} size={25} />
          </TouchableOpacity>
          <Text style={dialogStyles.dialogButtonText}>Upload</Text>
        </View>
      </View>
    </Fragment>
  );
}
