export default {
  showDevScreens: __DEV__,
  // useFixtures: false,
  ezLogin: false,
  yellowBox: false,
  reduxLogging: __DEV__,
  includeExamples: __DEV__,
  useReactotron: __DEV__,
  enableCrashlytics: !__DEV__,
};
