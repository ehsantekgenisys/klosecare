import Snackbar from 'react-native-snackbar';
import { Colors } from 'Themes';
import Moment from 'moment';
import { Alert } from 'react-native';
import Axios from 'axios';
import { values, all, any, pick, last, length, equals, not, head } from 'ramda';

/**
 * Shows notification in a SnackBar
 *
 * @method showNotification
 *
 * @param {string} message
 *
 * @returns {void}
 */
export const showNotification = (message: string, duration?: number) => {
  Snackbar.show({
    title: message,
    duration: duration ? duration : 4000,
    action: {
      title: 'OK',
      color: Colors.white,
      onPress: () => {},
    },
  });
};

/** Formats date according to the given format
 *  @method formatDate
 *
 *  @param {string} date
 *
 *  @param {string} format
 *
 *  @returns {string}
 */

export const formatDate = (date: string | Date, format?: string) => {
  if (format) {
    return Moment(date).format(format);
  }
  return Moment(date).format('MMM DD YYYY');
};

/**
 * Shows the alert as a snackbar at the bottom of the screen
 *
 * @method showAlert
 *
 * @param {string} title
 * @param {string} message
 * @param {() => void} onPressOkay
 * @param {() => void} onPressCancel
 * @param {string} confirmBtnText
 * @param {string} cancelBtnText
 * @param {boolean} cancelable
 *
 * @returns {Alert}
 */
export function showAlert(
  title: string,
  message: string,
  onPressOkay: () => void,
  onPressCancel: () => void,
  confirmBtnText: string,
  cancelBtnText: string,
  cancelable?: boolean,
) {
  return Alert.alert(
    title,
    message,
    [
      {
        text: confirmBtnText,
        onPress: onPressOkay,
      },
      {
        text: cancelBtnText,
        onPress: onPressCancel,
        style: 'cancel',
      },
    ],
    { cancelable: cancelable ? true : false },
  );
}

/**
 *
 *  Wraps the text if the string is greater than 16 in length
 *  @method wrapString
 *  @param string
 *  @returns {string}
 */
export function wrapString(text: string, framentLength?: number) {
  const textLength = text.length;
  if (Boolean(framentLength)) {
    if (text.length <= framentLength * 2 + 1) {
      return text;
    } else {
      const preString = text.slice(0, framentLength);
      const postString = text.slice(textLength - framentLength, textLength);
      return `${preString}...${postString}`;
    }
  }
  if (text.length <= 16) {
    return text;
  }
  const preString = text.slice(0, 7);
  const postString = text.slice(textLength - 7, textLength);
  return `${preString}...${postString}`;
}

/**
 * Generates a unique cancel token for axios api call
 *
 * @method generateCanceToken
 *
 * @yields {Axios.CancelToken}
 */
function* generateCanceToken() {
  while (true) {
    yield Axios.CancelToken.source();
  }
}

/**
 * Gives a cancel token source
 *
 * @method getCancelToken
 *
 * @returns {void}
 */
export function getCancelToken() {
  const tokenSource = generateCanceToken();
  return tokenSource.next().value;
}

/**
 * Calculates the difference and
 * returns hours remaining
 *
 * @method renderTimeRemaining
 *
 * @param createdAt
 *
 * @returns {void}
 */
export function renderTimeRemaining(createdAt: string) {
  const date = Moment(new Date());
  const diff = date.diff(createdAt, 'day');
  switch (diff) {
    case 0:
      return '72';
    case 1:
      return '48';
    case 2:
      return '24';
    default:
      return '';
  }
}

/**
 * Checks if an object has all props truthy
 *
 * @method allTruthyProps
 *
 * @param {[key:string]: string} object
 *
 * @returns {boolean}
 */
export function allTruthyProps(object) {
  const keyValues = values(object);
  return all(Boolean)(keyValues);
}

/**
 * Checks if an object has any prop that is truthy
 *
 * @method anyTruthyProps
 *
 * @param {[key:string]: string} object
 *
 * @returns {boolean}
 */
export function anyTruthyProps(object) {
  const keyValues = values(object);
  return any(Boolean)(keyValues);
}

/**
 * Checks if all props of object in array of objects are truthy
 *
 * @method allTruthyPropsInArray
 *
 * @param {{[key:string]: string}[]} array
 *
 * @returns {boolean}
 */
export function allTruthyPropsInArray(array) {
  return all(allTruthyProps, array);
}

/**
 * Checks if last object in array contains any props that are truthy
 *
 * @method lastObjectInArrayHasAnyTruthyProps
 *
 * @param {[]} array
 * @param {string[]} propstoPick
 *
 * @returns {boolean}
 */
export function lastObjectInArrayHasAnyTruthyProps(
  array,
  propstoPick?: string[],
) {
  const requiredObjectWithProps = pick(
    propstoPick ? propstoPick : ['name', 'dose', 'frequency'],
    last(array),
  );
  return anyTruthyProps(requiredObjectWithProps);
}

/**
 * Returns an array to be saved in report context for insulin medication.
 * @since insulin is mandatory, so, array must have atleast one valid object in it.
 * If array contains more than one object then check if the last object is truthy(all props are truthy).
 * - If last object is truthy then save
 * - If last object is completely falsy(all props are false) - Do not save the last object in array
 * - If last object is partially truthy(some props are truthy) - Do not save the array
 *
 * @method insulinMedicationToSave
 *
 * @example
 * Input - [{name: 'aspirin', dose: 'daily'}, {name: 'humalog', dose: 'weekly'}]
 * Output - [{name: 'aspirin', dose: 'daily'}, {name: 'humalog', dose: 'weekly'}]
 *
 * Input - [{name: 'aspirin', dose: 'daily'}, {name: '', dose: ''}]
 * Output - [{name: 'aspirin', dose: 'daily'}]
 *
 * @param {[]} array
 *
 * @returns {[]}
 */
export function insulinMedicationToSave(array) {
  const size = length(array);
  if (equals(size, 1)) {
    return array;
  }
  if (allTruthyPropsInArray(array)) {
    return array;
  }

  const includeLast = lastObjectInArrayHasAnyTruthyProps(array);
  if (includeLast) {
    return array;
  }
  return array.filter((_, index) => index !== size - 1);
}

/**
 * Returns an array to be saved in report context for other medication.
 * @since other medication is optional, so, array can be empty.
 * If array contains more than one object then check if the last object is truthy(all props are truthy).
 * - If last object is truthy then save
 * - If last object is completely falsy(all props are false) - Do not save the last object in array
 * - If last object is partially truthy(some props are truthy) - Do not save the array
 *
 * @method optionalMedicationToSave
 *
 * @example
 * Input - [{name: '', dose: ''}]
 * Output - []
 *
 * Input - [{name: 'aspirin', dose: 'daily'}, {name: 'humalog', dose: 'weekly'}]
 * Output - [{name: 'aspirin', dose: 'daily'}, {name: 'humalog', dose: 'weekly'}]
 *
 * Input - [{name: 'aspirin', dose: 'daily'}, {name: '', dose: ''}]
 * Output - [{name: 'aspirin', dose: 'daily'}]
 *
 * @param {[]} array
 *
 * @returns {[]}
 */
export function optionalMedicationToSave(array) {
  const size = length(array);
  if (equals(size, 1)) {
    const firstRowEmpty = not(allTruthyProps(head(array)));
    if (firstRowEmpty) {
      return [];
    }
    return array;
  }

  const includeLast = lastObjectInArrayHasAnyTruthyProps(array);
  if (includeLast) {
    return array;
  }
  return array.filter((_, index) => index !== size - 1);
}

/**
 * Checks if optional medication is valid to be saved in report context.
 * @since other medication is optional, so, empty state is valid.
 * If array contains more than one object then check if the last object is truthy(all props are truthy).
 * - All objects must be truthy(all props are truthy) - true
 * - Last object is completly truthy or falsy - true
 * - Last object is partially truthy(some props are truthy) - false
 *
 * @method optionalMedicationIsValid
 *
 * @example
 * Input - [{name: '', hours: '' }]
 * Output - true
 *
 * Input - [{name: 'oneTruthy', hours: ''}]
 * Output - false
 *
 * Input - [{name: 'oneTruthy', hours: 'oneTruthy'}, {name: '', hours: ''}]
 * Output - true
 *
 * Input - [{name: 'oneTruthy', hours: 'oneTruthy'}, {name: 'onetruthy', hours: ''}]
 * Output - false
 *
 * Input - [{name: 'oneTruthy', hours: 'oneTruthy'}, {name: 'value', hours: 'value'}]
 * Output - true
 *
 * @param {[]} array
 *
 * @returns {boolean}
 */
export function optionalMedicationIsValid(array, propstoPick?: string[]) {
  const size = length(array);
  if (equals(size, 1)) {
    return (
      allTruthyProps(head(array)) ||
      not(
        anyTruthyProps(
          pick(
            propstoPick ? propstoPick : ['name', 'dose', 'frequency'],
            head(array),
          ),
        ),
      )
    );
  }

  if (not(anyTruthyProps(pick(['name', 'dose', 'frequency'], last(array))))) {
    return allTruthyPropsInArray(
      array.filter((_, index) => index !== size - 1),
    );
  }
  return allTruthyPropsInArray(array);
}

/**
 * Checks if insulin medication is valid to be saved in report context.
 * @since insulin medication is mandatory, so, empty state is invalid.
 * If array contains more than one object then check if the last object is truthy(all props are truthy).
 * - All objects must be truthy(all props are truthy) - true
 * - Last object is completly truthy or falsy - true
 * - Last object is partially truthy(some props are truthy) - false
 *
 * @method insulinMedicationIsValid
 *
 * @example
 * Input - [{name: '', hours: '' }]
 * Output - false
 *
 * Input - [{name: 'oneTruthy', hours: ''}]
 * Output - false
 *
 * Input - [{name: 'oneTruthy', hours: 'oneTruthy'}, {name: '', hours: ''}]
 * Output - true
 *
 * Input - [{name: 'oneTruthy', hours: 'oneTruthy'}, {name: 'onetruthy', hours: ''}]
 * Output - false
 *
 * Input - [{name: 'oneTruthy', hours: 'oneTruthy'}, {name: 'value', hours: 'value'}]
 * Output - true
 *
 * @param {[]} array
 *
 * @returns {boolean}
 */
export function insulinMedicationIsValid(array) {
  const size = length(array);

  if (equals(size, 1)) {
    return allTruthyProps(head(array));
  }

  if (not(anyTruthyProps(pick(['name', 'dose', 'frequency'], last(array))))) {
    return allTruthyPropsInArray(
      array.filter((_, index) => index !== size - 1),
    );
  }
  return allTruthyPropsInArray(array);
}
