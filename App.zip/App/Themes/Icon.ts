import { createIconSetFromFontello } from 'react-native-vector-icons';
import config from 'Themes/config.json';

export default createIconSetFromFontello(config);
