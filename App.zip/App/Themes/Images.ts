// leave off @2x/@3x
const Images = {
  onBoarding1: require('Images/Onboarding1.png'),
  onBoarding2: require('Images/Onboarding2.png'),
  onBoarding3: require('Images/Onboarding3.png'),
  onBoarding4: require('Images/Onboarding4.png'),
  app_background: require('Images/app_background.png'),
};

export default Images;
