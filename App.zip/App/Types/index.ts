/**
 * Onboarding slide data interface
 */
export interface IOnboardingSlideData {
  title: string;
  text: string;
  buttonText: string;
  lastSlide: boolean;
  imageSrc: string;
}

/**
 * Signup form values interface
 */
export interface ISignupFormValues {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmPassword: string;
}

/**
 * Login form values interface
 */
export interface ILoginFormValues {
  email: string;
  password: string;
}

/**
 * Reset Password form values interface
 */
export interface IResetPasswordFormValues {
  password: string;
  confirmPassword: string;
}

/**
 * Forgot Password form values interface
 */
export interface IForgotPasswordFormValues {
  email: string;
}

/**
 * Enum type for input field type
 */
export enum FieldType {
  text = 'text',
  password = 'password',
}

/**
 * User Signup Credentials Data
 */
export interface IUserSignupData {
  first_name: string;
  last_name: string;
  email: string;
  password: string;
}

/**
 * User Signup Credentials Data
 */
export interface IUserLoginData {
  email: string;
  password: string;
}

/**
 * User data received from back-end
 */
export interface IUser {
  id: number;
  password: string;
  last_login: string;
  is_superuser: false;
  first_name: string;
  last_name: string;
  is_active: boolean;
  date_joined: string;
  signup_type: string;
  email: string;
  groups: [];
  user_permissions: [];
}

/**
 *  Patient data , includes IUser's object
 */
export interface IPatient {
  id: number;
  date_of_birth: string;
  gender: string;
  mobile: string;
  address: string;
  user: IUser;
}

/**
 * Doctor data includes IUser's object
 */
export interface IDocotor {
  id: number;
  rating: number;
  bio: string;
  picture: string;
  specialization: string;
  user: IUser;
}

/** Report purpose data */
export interface IPurpose {
  id: number;
  purpose: string;
}

/** Exercise Info for report */
export interface IExercise {
  id: number;
  type: string;
  days_per_week: string;
  duration: string;
}

export interface IMedicationInfo {
  id: number;
  name: string;
  frequency: string;
  dose: string;
}

export interface IDietInfo {
  id: string;
  name: string;
}

/**
 *  Report data including information
 *  about Doctor and Patient and Purpose of
 *  Report with comments
 */
export interface IReportResponse {
  id: number;
  waiting_time: string;
  can_cancel: boolean;
  range: string;
  comments: string;
  doctor_recommendation: string;
  device_type: string;
  file: {
    url: string;
    size: number;
    name: string;
  };
  is_completed: boolean;
  created_at: string;
  completed_at: string;
  patient: IPatient;
  doctor: IDocotor;
  purposes: IPurpose[];
  exercise: IExercise[];
  medicine: {
    insulin: IMedicationInfo[];
    other: IMedicationInfo[];
  };
  diet: IDietInfo[];
  estimated_calories: number;
}

/** Change password data */

export interface IChangePasswordFormValues {
  password: string;
  newPassword: string;
  confirmPassword: string;
}

/**
 * Report details slide data interface
 */
export interface IReportDetailSlide {
  title: string;
  text: string;
  purposes?: [];
}
